# Security Specification & Payload-First TDD

## 1. Data Invariants
1. **Verified Account Gate**: All Firestore reads and writes require `request.auth != null && request.auth.token.email_verified == true`.
2. **PII Isolation**: `/users/{userId}` contains `email` and is readable/writable ONLY by `request.auth.uid == userId` (or bootstrapped admin). Public NetPlay tags live in `/playerProfiles/{userId}` with zero email/PII fields.
3. **Immutable Ownership & Timestamps**: `uid`, `hostUid`, `roomCode`, `biosMode`, and `createdAt` are immutable after creation; `createdAt` and `updatedAt` must equal `request.time`.
4. **P1 Room Authority**: Only `hostUid` can approve (`p2AccessStatus = 'approved'`), deny, revoke, toggle `p2CanSelectCharacter`, change `gameId`/`gameTitle`, or close a room. P2 (`p2Uid`) may only request entry (`p2AccessStatus = 'pending'`), leave, or update `p2Character` when `p2AccessStatus == 'approved' && p2CanSelectCharacter == true`.
5. **Terminal State Lock**: Once `rooms/{roomId}.status == 'closed'`, no further updates are permitted.
6. **Strict Schema & Bounds**: Every string enforces `size()` limits and regex ID checks (`^[a-zA-Z0-9_\-]+$`); `hasOnly()` blocks ghost fields.

## 2. The "Dirty Dozen" Adversarial Payloads (Expected: PERMISSION_DENIED)
1. **Unverified Email Write**: Creating `/users/u1` when `request.auth.token.email_verified == false`.
2. **Identity Spoofing on User**: Creating `/users/u2` while signed in as `u1` or setting `uid: "u2"`.
3. **PII Cross-Read**: User `u2` reading `/users/u1` (contains `email`).
4. **Ghost Field Injection**: Creating `/rooms/PSX101` with extra key `isAdmin: true`.
5. **ID Poisoning**: Creating `/rooms/invalid$id!` or a 256-char room ID.
6. **Timestamp Forgery**: Creating `/rooms/PSX101` with client-supplied past timestamp instead of `request.time`.
7. **P2 Self-Approval**: Guest `u2` updating `/rooms/PSX101` with `p2AccessStatus: "approved"`.
8. **P2 Unauthorized Character Change**: Guest `u2` updating `p2Character` when `p2CanSelectCharacter == false` or `p2AccessStatus != "approved"`.
9. **Host Hijack**: Guest `u2` updating `hostUid` or `p1Character` on `/rooms/PSX101`.
10. **Closed Room Resurrection**: Host updating `/rooms/PSX101` after `status == "closed"`.
11. **Oversized Memory Card Exhaustion**: Writing `/saveStates/s1` with 200KB `memoryCardData` exceeding `16384` chars.
12. **Blanket Save Listing Spoof**: Querying `/saveStates` without filtering `uid == request.auth.uid`.
