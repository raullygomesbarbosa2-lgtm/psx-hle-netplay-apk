/**
 * Global WebAudio tap + PCM fallback encoder/player for PS1 Host -> P2 Guest audio mirroring.
 * Captures both EmulatorJS OpenAL output and PsxSpu chimes without modifying third-party WASM cores.
 */

export interface PcmChunkPayload {
  sr: number;
  pcm: string; // base64 Int16 mono
}

type AudioTrackListener = (track: MediaStreamTrack) => void;
type PcmChunkListener = (chunk: PcmChunkPayload) => void;

interface ContextTapEntry {
  streamDest: MediaStreamAudioDestinationNode;
  processor: ScriptProcessorNode | null;
}

declare global {
  interface Window {
    __psxAudioTapPatched?: boolean;
  }
}

const tappedContexts = new Map<AudioContext, ContextTapEntry>();
const trackListeners = new Set<AudioTrackListener>();
const pcmListeners = new Set<PcmChunkListener>();
let latestAudioTrack: MediaStreamTrack | null = null;

function int16ToBase64(samples: Int16Array): string {
  const bytes = new Uint8Array(samples.buffer, samples.byteOffset, samples.byteLength);
  let bin = '';
  for (let i = 0; i < bytes.length; i++) {
    bin += String.fromCharCode(bytes[i]);
  }
  return btoa(bin);
}

function base64ToInt16(b64: string): Int16Array {
  const bin = atob(b64);
  const bytes = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) {
    bytes[i] = bin.charCodeAt(i);
  }
  return new Int16Array(bytes.buffer);
}

function ensurePcmProcessor(ctx: AudioContext, entry: ContextTapEntry): void {
  if (entry.processor || pcmListeners.size === 0) return;

  try {
    const processor = ctx.createScriptProcessor(2048, 2, 1);
    const silentGain = ctx.createGain();
    silentGain.gain.value = 0;

    processor.onaudioprocess = (ev) => {
      if (pcmListeners.size === 0) return;
      const ch0 = ev.inputBuffer.getChannelData(0);
      const ch1 = ev.inputBuffer.numberOfChannels > 1 ? ev.inputBuffer.getChannelData(1) : ch0;

      // Downsample by 2 when sampleRate >= 40000 to keep WebSocket payload compact (~22kHz)
      const step = ctx.sampleRate >= 40000 ? 2 : 1;
      const outLen = Math.floor(ch0.length / step);
      const pcm16 = new Int16Array(outLen);
      let hasSignal = false;

      for (let i = 0, j = 0; j < outLen; i += step, j++) {
        const mono = (ch0[i] + ch1[i]) * 0.5;
        if (Math.abs(mono) > 0.0008) hasSignal = true;
        const clamped = Math.max(-1, Math.min(1, mono));
        pcm16[j] = clamped < 0 ? clamped * 0x8000 : clamped * 0x7fff;
      }

      if (!hasSignal) return;

      const payload: PcmChunkPayload = {
        sr: Math.round(ctx.sampleRate / step),
        pcm: int16ToBase64(pcm16),
      };
      pcmListeners.forEach((cb) => cb(payload));
    };

    entry.streamDest.stream.getAudioTracks();
    // Tap via a MediaStreamAudioSourceNode or directly from an intermediate gain connected to streamDest
    const sourceNode = ctx.createMediaStreamSource(entry.streamDest.stream);
    sourceNode.connect(processor);
    processor.connect(silentGain);
    silentGain.connect(ctx.destination);
    entry.processor = processor;
  } catch {
    // Ignore environments that disallow MediaStreamSource loopback
  }
}

export function installGlobalAudioTap(): void {
  if (typeof window === 'undefined' || window.__psxAudioTapPatched) return;
  if (typeof AudioNode === 'undefined') return;
  window.__psxAudioTapPatched = true;

  const origConnect = AudioNode.prototype.connect as (
    this: AudioNode,
    destination: AudioNode | AudioParam,
    outputIndex?: number,
    inputIndex?: number,
  ) => AudioNode | void;

  AudioNode.prototype.connect = function (
    this: AudioNode,
    destination: AudioNode | AudioParam,
    outputIndex?: number,
    inputIndex?: number,
  ) {
    const result = origConnect.apply(this, [
      destination as AudioNode,
      outputIndex as number,
      inputIndex as number,
    ]);

    try {
      const ctx = this.context;
      if (ctx instanceof AudioContext && destination === ctx.destination) {
        let entry = tappedContexts.get(ctx);
        if (!entry) {
          const streamDest = ctx.createMediaStreamDestination();
          entry = { streamDest, processor: null };
          tappedContexts.set(ctx, entry);

          const track = streamDest.stream.getAudioTracks()[0] ?? null;
          if (track) {
            latestAudioTrack = track;
            trackListeners.forEach((cb) => cb(track));
          }
        }
        origConnect.call(this, entry.streamDest);
        ensurePcmProcessor(ctx, entry);
      }
    } catch {
      // Never interfere with primary audio output
    }

    return result;
  } as typeof AudioNode.prototype.connect;
}

export function getLatestCapturedAudioTrack(): MediaStreamTrack | null {
  if (latestAudioTrack && latestAudioTrack.readyState === 'live') {
    return latestAudioTrack;
  }
  for (const [, entry] of tappedContexts) {
    const t = entry.streamDest.stream.getAudioTracks()[0];
    if (t && t.readyState === 'live') {
      latestAudioTrack = t;
      return t;
    }
  }
  return null;
}

export function subscribeCapturedAudioTrack(cb: AudioTrackListener): () => void {
  trackListeners.add(cb);
  const existing = getLatestCapturedAudioTrack();
  if (existing) {
    cb(existing);
  }
  return () => {
    trackListeners.delete(cb);
  };
}

export function subscribeHostPcmAudio(cb: PcmChunkListener): () => void {
  pcmListeners.add(cb);
  tappedContexts.forEach((entry, ctx) => {
    ensurePcmProcessor(ctx, entry);
  });
  return () => {
    pcmListeners.delete(cb);
  };
}

export class PsxRemoteAudioPlayer {
  private ctx: AudioContext | null = null;
  private gainNode: GainNode | null = null;
  private nextPlayTime = 0;
  private muted = false;

  unlock(): void {
    if (typeof window === 'undefined') return;
    if (!this.ctx) {
      const AudioCtx =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
      if (!AudioCtx) return;
      this.ctx = new AudioCtx();
      this.gainNode = this.ctx.createGain();
      this.gainNode.gain.value = this.muted ? 0 : 0.85;
      this.gainNode.connect(this.ctx.destination);
    }
    if (this.ctx.state === 'suspended') {
      void this.ctx.resume();
    }
  }

  setMuted(muted: boolean): void {
    this.muted = muted;
    if (this.gainNode) {
      this.gainNode.gain.value = muted ? 0 : 0.85;
    }
  }

  enqueuePcm(sampleRate: number, pcmBase64: string): void {
    if (this.muted) return;
    if (!this.ctx || !this.gainNode) {
      this.unlock();
    }
    if (!this.ctx || !this.gainNode || this.ctx.state !== 'running') return;

    try {
      const pcm16 = base64ToInt16(pcmBase64);
      if (pcm16.length === 0) return;

      const safeRate = Math.max(8000, Math.min(96000, sampleRate || 22050));
      const buffer = this.ctx.createBuffer(1, pcm16.length, safeRate);
      const floatData = buffer.getChannelData(0);
      for (let i = 0; i < pcm16.length; i++) {
        floatData[i] = pcm16[i] / 32768;
      }

      const src = this.ctx.createBufferSource();
      src.buffer = buffer;
      src.connect(this.gainNode);

      const now = this.ctx.currentTime;
      if (this.nextPlayTime < now || this.nextPlayTime > now + 0.25) {
        this.nextPlayTime = now + 0.03;
      }
      src.start(this.nextPlayTime);
      this.nextPlayTime += buffer.duration;
    } catch {
      // Ignore transient decode errors
    }
  }

  destroy(): void {
    if (this.ctx) {
      void this.ctx.close().catch(() => {});
      this.ctx = null;
      this.gainNode = null;
    }
  }
}
