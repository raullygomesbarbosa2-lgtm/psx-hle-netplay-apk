import { PsxMemory } from './psxMemory';
import { PsxSpu, SfxKind } from './psxSpu';
import { StreamingIsoReader } from './streamingIsoReader';

export interface HleCharacterConfig {
  p1Name: string;
  p1PrimaryRgb: number;
  p1AccentRgb: number;
  p1Speed: number;
  p1Power: number;
  p2Name: string;
  p2PrimaryRgb: number;
  p2AccentRgb: number;
  p2Speed: number;
  p2Power: number;
}

export class PsxHleBios {
  private mem: PsxMemory;
  private spu: PsxSpu;
  private isoReader: StreamingIsoReader | null = null;

  heapPtr = 0x80100000;
  frameRequestedYield = false;
  vsyncCount = 0;
  bootLog: string[] = [];
  rngState = 0x12345678;

  charConfig: HleCharacterConfig = {
    p1Name: 'PLAYER 1',
    p1PrimaryRgb: 0x3b82f6,
    p1AccentRgb: 0xf8fafc,
    p1Speed: 88,
    p1Power: 85,
    p2Name: 'PLAYER 2',
    p2PrimaryRgb: 0xef4444,
    p2AccentRgb: 0xf59e0b,
    p2Speed: 88,
    p2Power: 85,
  };

  private events = new Map<number, { enabled: boolean; triggered: boolean }>();
  private nextEventId = 0xf1000001;

  constructor(mem: PsxMemory, spu: PsxSpu) {
    this.mem = mem;
    this.spu = spu;
  }

  setIsoReader(reader: StreamingIsoReader | null): void {
    this.isoReader = reader;
  }

  reset(): void {
    this.heapPtr = 0x80100000;
    this.frameRequestedYield = false;
    this.vsyncCount = 0;
    this.bootLog = ['[HLE] Kernel PS1 inicializado (Sem BIOS externa)'];
    this.events.clear();
    this.nextEventId = 0xf1000001;
  }

  private log(msg: string): void {
    this.bootLog.push(msg);
    if (this.bootLog.length > 40) this.bootLog.shift();
  }

  private nextRand(): number {
    this.rngState = (Math.imul(this.rngState, 1664525) + 1013904223) >>> 0;
    return (this.rngState >>> 16) & 0x7fff;
  }

  /**
   * Dispatches standard PS1 A0/B0/C0 BIOS calls when PC reaches 0xA0, 0xB0, or 0xC0.
   */
  dispatchVector(vector: number, regs: Int32Array): void {
    const fn = regs[9] & 0xff; // $t1
    const a0 = regs[4] >>> 0;
    const a1 = regs[5] >>> 0;
    const a2 = regs[6] >>> 0;
    const a3 = regs[7] >>> 0;

    if (vector === 0xa0) {
      switch (fn) {
        case 0x17: // strcmp
          regs[2] = this.mem.readCString(a0) === this.mem.readCString(a1) ? 0 : 1;
          break;
        case 0x19: { // strcpy
          const s = this.mem.readCString(a1);
          this.mem.writeString(a0, s);
          regs[2] = a0 | 0;
          break;
        }
        case 0x1b: // strlen
          regs[2] = this.mem.readCString(a0).length;
          break;
        case 0x2a: // memcpy
          for (let i = 0; i < (a2 & 0xfffff); i++) {
            this.mem.write8(a0 + i, this.mem.read8(a1 + i));
          }
          regs[2] = a0 | 0;
          break;
        case 0x2b: // memset
          for (let i = 0; i < (a2 & 0xfffff); i++) {
            this.mem.write8(a0 + i, a1 & 0xff);
          }
          regs[2] = a0 | 0;
          break;
        case 0x2f: // rand
          regs[2] = this.nextRand();
          break;
        case 0x30: // srand
          this.rngState = a0 || 1;
          break;
        case 0x33: { // malloc
          const size = (a0 + 7) & ~7;
          const ptr = this.heapPtr;
          this.heapPtr += size;
          regs[2] = ptr | 0;
          break;
        }
        case 0x39: // InitHeap
          this.heapPtr = a0 ? a0 : 0x80100000;
          break;
        case 0x3f: // printf
          this.log(`[TTY] ${this.mem.readCString(a0, 80)}`);
          regs[2] = 0;
          break;
        case 0x44: // FlushCache
          regs[2] = 0;
          break;
        case 0x49: // GPU_cw
          this.mem.gpu.writeGp0(a0);
          regs[2] = 0;
          break;
        case 0x4a: // GPU_cwp
          for (let i = 0; i < (a1 & 0xfff); i++) {
            this.mem.gpu.writeGp0(this.mem.read32(a0 + i * 4));
          }
          regs[2] = 0;
          break;
        case 0x4d: // GPU_GetGPUStatus
          regs[2] = this.mem.gpu.gpuStat | 0;
          break;
        case 0x54: // CdInit
          this.log('[HLE CD] CdInit() OK');
          regs[2] = 1;
          break;
        case 0x70: // _bu_init
          regs[2] = 1;
          break;
        case 0x9f: // SetMem
          regs[2] = 2; // 2MB
          break;
        default:
          regs[2] = 0;
          break;
      }
      return;
    }

    if (vector === 0xb0) {
      switch (fn) {
        case 0x07: // DeliverEvent
          regs[2] = 1;
          break;
        case 0x08: { // OpenEvent
          const id = this.nextEventId++;
          this.events.set(id, { enabled: false, triggered: true });
          regs[2] = id | 0;
          break;
        }
        case 0x0a: // WaitEvent
        case 0x0b: { // TestEvent
          this.frameRequestedYield = true;
          regs[2] = 1;
          break;
        }
        case 0x0c: // EnableEvent
          if (this.events.has(a0)) this.events.get(a0)!.enabled = true;
          regs[2] = 1;
          break;
        case 0x12: // InitPAD
          this.log('[HLE PAD] InitPAD() Porta 1 e Porta 2 prontas');
          regs[2] = 1;
          break;
        case 0x13: // StartPAD
          regs[2] = 1;
          break;
        case 0x15: // PAD_init
          regs[2] = 1;
          break;
        case 0x16: // PAD_dr
          regs[2] = (this.mem.pad1.buttons & 0xffff) | ((this.mem.pad2.buttons & 0xffff) << 16);
          break;
        case 0x3d: // std_out_putchar
          regs[2] = a0 | 0;
          break;
        case 0x4a: // InitCARD
        case 0x4b: // StartCARD
          regs[2] = 1;
          break;
        case 0x5b: // ChangeClearPAD
          regs[2] = 0;
          break;
        default:
          regs[2] = 1;
          break;
      }
      return;
    }

    if (vector === 0xc0) {
      regs[2] = 1;
    }
  }

  /**
   * Dispatches MIPS SYSCALL instruction (`code` field in instruction bits 6..25).
   */
  dispatchSyscall(code: number, regs: Int32Array): void {
    const a0 = regs[4] | 0;
    const a1 = regs[5] | 0;
    const a2 = regs[6] | 0;
    const a3 = regs[7] | 0;
    const t0 = regs[8] >>> 0;

    switch (code) {
      case 0x01: // EnterCriticalSection
      case 0x02: // ExitCriticalSection
        break;
      case 0x10: // HLE_VSYNC_AND_PRESENT
        this.vsyncCount++;
        this.frameRequestedYield = true;
        regs[2] = this.vsyncCount;
        break;
      case 0x11: { // HLE_GET_PAD (a0 = 1 or 2) -> returns active-high 16-bit mask in $v0
        const pad = a0 === 2 ? this.mem.pad2 : this.mem.pad1;
        regs[2] = (~pad.buttons) & 0xffff;
        break;
      }
      case 0x12: // HLE_FILL_RECT(x, y, w, h, $t0=rgb)
        this.mem.gpu.drawRect(a0, a1, a2, a3, t0);
        break;
      case 0x13: // HLE_DRAW_TRI(x0,y0,x1,y1, t0=x2, t1=y2, t2=rgb)
        this.mem.gpu.drawTriangleShaded(
          a0, a1, regs[10] >>> 0,
          a2, a3, regs[10] >>> 0,
          regs[8] | 0, regs[9] | 0, regs[10] >>> 0,
        );
        break;
      case 0x14: { // HLE_DRAW_TEXT(x, y, strPtr, rgb)
        const text = this.mem.readCString(a2 >>> 0, 64);
        this.mem.gpu.drawText(a0, a1, text, a3 >>> 0, Math.max(1, t0 || 1));
        break;
      }
      case 0x15: { // HLE_PLAY_SFX(kindIndex)
        const kinds: SfxKind[] = ['boot', 'hit', 'laser', 'drift', 'score', 'menu'];
        this.spu.playSfx(kinds[a0] ?? 'menu');
        break;
      }
      case 0x16: // HLE_GET_P1_COLOR / HLE_GET_P2_COLOR
        regs[2] = this.charConfig.p1PrimaryRgb | 0;
        regs[3] = this.charConfig.p2PrimaryRgb | 0;
        break;
      case 0x17: { // HLE_DRAW_NUM(x, y, val, rgb, $t0=scale)
        const scale = Math.max(1, t0 || 1);
        this.mem.gpu.drawText(a0, a1, String(a2), a3 >>> 0, scale);
        break;
      }
      case 0x18: // HLE_RAND(max)
        regs[2] = a0 > 0 ? this.nextRand() % a0 : this.nextRand();
        break;
      case 0x19: { // HLE_DRAW_CHAR_NAMES(y, scale)
        this.mem.gpu.drawText(12, a0, `P1:${this.charConfig.p1Name.slice(0, 12)}`, this.charConfig.p1PrimaryRgb, 1);
        this.mem.gpu.drawText(172, a0, `P2:${this.charConfig.p2Name.slice(0, 12)}`, this.charConfig.p2PrimaryRgb, 1);
        break;
      }
      default:
        break;
    }
  }

  hasIsoReader(): boolean {
    return this.isoReader !== null;
  }
}
