export interface RecognizedPs1Title {
  serial: string;
  title: string;
  region: 'NTSC-U' | 'PAL' | 'NTSC-J' | 'Homebrew';
  genre: string;
  maxPlayers: 1 | 2;
}

const PS1_SERIAL_MAP: Record<string, Omit<RecognizedPs1Title, 'serial'>> = {
  'SCUS-94900': { title: 'Crash Bandicoot', region: 'NTSC-U', genre: 'Plataforma 3D', maxPlayers: 1 },
  'SCUS-94154': { title: 'Crash Bandicoot 2: Cortex Strikes Back', region: 'NTSC-U', genre: 'Plataforma 3D', maxPlayers: 1 },
  'SCUS-94244': { title: 'Crash Bandicoot: Warped', region: 'NTSC-U', genre: 'Plataforma 3D', maxPlayers: 1 },
  'SCUS-94426': { title: 'Crash Team Racing', region: 'NTSC-U', genre: 'Corrida Kart', maxPlayers: 2 },
  'SCUS-94422': { title: 'Crash Bash', region: 'NTSC-U', genre: 'Party / Arena', maxPlayers: 2 },
  'SCUS-94163': { title: 'Gran Turismo', region: 'NTSC-U', genre: 'Corrida Simulador', maxPlayers: 2 },
  'SCUS-94455': { title: 'Gran Turismo 2 (Arcade)', region: 'NTSC-U', genre: 'Corrida Simulador', maxPlayers: 2 },
  'SCUS-94488': { title: 'Gran Turismo 2 (Simulation)', region: 'NTSC-U', genre: 'Corrida Simulador', maxPlayers: 2 },
  'SLUS-00707': { title: 'Tekken 3', region: 'NTSC-U', genre: 'Luta 3D', maxPlayers: 2 },
  'SLUS-00213': { title: 'Tekken 2', region: 'NTSC-U', genre: 'Luta 3D', maxPlayers: 2 },
  'SLUS-00006': { title: 'Tekken', region: 'NTSC-U', genre: 'Luta 3D', maxPlayers: 2 },
  'SLUS-00594': { title: 'Resident Evil 2 (Leon)', region: 'NTSC-U', genre: 'Survival Horror', maxPlayers: 1 },
  'SLUS-00748': { title: 'Resident Evil 2 (Claire)', region: 'NTSC-U', genre: 'Survival Horror', maxPlayers: 1 },
  'SLUS-00170': { title: 'Resident Evil', region: 'NTSC-U', genre: 'Survival Horror', maxPlayers: 1 },
  'SLUS-00756': { title: "Resident Evil: Director's Cut", region: 'NTSC-U', genre: 'Survival Horror', maxPlayers: 1 },
  'SLUS-00923': { title: 'Resident Evil 3: Nemesis', region: 'NTSC-U', genre: 'Survival Horror', maxPlayers: 1 },
  'SLUS-00704': { title: 'Silent Hill', region: 'NTSC-U', genre: 'Survival Horror', maxPlayers: 1 },
  'SLUS-00594D': { title: 'Resident Evil 2 DualShock', region: 'NTSC-U', genre: 'Survival Horror', maxPlayers: 1 },
  'SLUS-00402': { title: 'Castlevania: Symphony of the Night', region: 'NTSC-U', genre: 'Ação RPG', maxPlayers: 1 },
  'SLUS-00594X': { title: 'Metal Gear Solid', region: 'NTSC-U', genre: 'Stealth Action', maxPlayers: 1 },
  'SLUS-00594M': { title: 'Metal Gear Solid (Disc 1)', region: 'NTSC-U', genre: 'Stealth Action', maxPlayers: 1 },
  'SLUS-00776': { title: 'Metal Gear Solid (Disc 1)', region: 'NTSC-U', genre: 'Stealth Action', maxPlayers: 1 },
  'SLUS-00957': { title: 'Metal Gear Solid (Disc 2)', region: 'NTSC-U', genre: 'Stealth Action', maxPlayers: 1 },
  'SCUS-94163G': { title: 'God of War PSX', region: 'NTSC-U', genre: 'Ação', maxPlayers: 1 },
  'SLUS-00879': { title: 'Driver: You Are the Wheelman', region: 'NTSC-U', genre: 'Ação / Corrida', maxPlayers: 1 },
  'SLUS-01161': { title: 'Driver 2 (Disc 1)', region: 'NTSC-U', genre: 'Ação / Corrida', maxPlayers: 2 },
  'SLUS-01318': { title: 'Driver 2 (Disc 2)', region: 'NTSC-U', genre: 'Ação / Corrida', maxPlayers: 2 },
  'SLUS-00106': { title: 'Grand Theft Auto', region: 'NTSC-U', genre: 'Ação Mundo Aberto', maxPlayers: 1 },
  'SLUS-00789': { title: 'Grand Theft Auto 2', region: 'NTSC-U', genre: 'Ação Mundo Aberto', maxPlayers: 1 },
  'SLUS-00846': { title: 'Grand Theft Auto: London 1969', region: 'NTSC-U', genre: 'Ação Mundo Aberto', maxPlayers: 1 },
  'SLPM-86600': { title: 'World Soccer Winning Eleven 2000', region: 'NTSC-J', genre: 'Futebol', maxPlayers: 2 },
  'SLPM-87056': { title: 'World Soccer Winning Eleven 2002', region: 'NTSC-J', genre: 'Futebol', maxPlayers: 2 },
  'SLUS-01264': { title: 'Tony Hawk Pro Skater 2', region: 'NTSC-U', genre: 'Esporte / Skate', maxPlayers: 2 },
  'SLUS-00860': { title: "Tony Hawk's Pro Skater", region: 'NTSC-U', genre: 'Esporte / Skate', maxPlayers: 2 },
  'SLUS-01419': { title: "Tony Hawk's Pro Skater 3", region: 'NTSC-U', genre: 'Esporte / Skate', maxPlayers: 2 },
  'SLUS-00551': { title: 'Need for Speed III: Hot Pursuit', region: 'NTSC-U', genre: 'Corrida', maxPlayers: 2 },
  'SLUS-00826': { title: 'Need for Speed: High Stakes', region: 'NTSC-U', genre: 'Corrida', maxPlayers: 2 },
  'SLUS-01020': { title: 'Need for Speed: Porsche Unleashed', region: 'NTSC-U', genre: 'Corrida', maxPlayers: 2 },
  'SLUS-00664': { title: 'Marvel vs. Capcom: Clash of Super Heroes', region: 'NTSC-U', genre: 'Luta 2D', maxPlayers: 2 },
  'SLUS-00816': { title: 'Street Fighter Alpha 3', region: 'NTSC-U', genre: 'Luta 2D', maxPlayers: 2 },
  'SLUS-00232': { title: 'Mortal Kombat Trilogy', region: 'NTSC-U', genre: 'Luta 2D', maxPlayers: 2 },
  'SLUS-00462': { title: 'Mortal Kombat 4', region: 'NTSC-U', genre: 'Luta 3D', maxPlayers: 2 },
  'SLUS-00707B': { title: 'Bloody Roar 2', region: 'NTSC-U', genre: 'Luta 3D', maxPlayers: 2 },
  'SCUS-94401': { title: 'Bloody Roar', region: 'NTSC-U', genre: 'Luta 3D', maxPlayers: 2 },
  'SLUS-00506': { title: 'Dragon Ball Z: Ultimate Battle 22', region: 'NTSC-U', genre: 'Luta 2D', maxPlayers: 2 },
  'SLPS-01057': { title: 'Pepsiman', region: 'NTSC-J', genre: 'Ação Runner', maxPlayers: 1 },
  'SLUS-00875': { title: 'Yu-Gi-Oh! Forbidden Memories', region: 'NTSC-U', genre: 'Cartas RPG', maxPlayers: 2 },
  'SLUS-01411': { title: 'Yu-Gi-Oh! Forbidden Memories', region: 'NTSC-U', genre: 'Cartas RPG', maxPlayers: 2 },
  'SCUS-94181': { title: 'Spyro the Dragon', region: 'NTSC-U', genre: 'Plataforma 3D', maxPlayers: 1 },
  'SCUS-94425': { title: "Spyro 2: Ripto's Rage!", region: 'NTSC-U', genre: 'Plataforma 3D', maxPlayers: 1 },
  'SCUS-94467': { title: 'Spyro: Year of the Dragon', region: 'NTSC-U', genre: 'Plataforma 3D', maxPlayers: 1 },
  'SLUS-00465': { title: 'Final Fantasy VII (Disc 1)', region: 'NTSC-U', genre: 'RPG', maxPlayers: 1 },
  'SCUS-94163F': { title: 'Final Fantasy VII', region: 'NTSC-U', genre: 'RPG', maxPlayers: 1 },
  'SLUS-00892': { title: 'Final Fantasy VIII (Disc 1)', region: 'NTSC-U', genre: 'RPG', maxPlayers: 1 },
  'SLUS-01251': { title: 'Final Fantasy IX (Disc 1)', region: 'NTSC-U', genre: 'RPG', maxPlayers: 1 },
  'SLUS-00665': { title: 'Xenogears (Disc 1)', region: 'NTSC-U', genre: 'RPG', maxPlayers: 1 },
  'SLUS-01041': { title: 'Chrono Cross (Disc 1)', region: 'NTSC-U', genre: 'RPG', maxPlayers: 1 },
  'SLUS-00821': { title: 'Dino Crisis', region: 'NTSC-U', genre: 'Survival Horror', maxPlayers: 1 },
  'SLUS-01279': { title: 'Dino Crisis 2', region: 'NTSC-U', genre: 'Ação / Horror', maxPlayers: 1 },
  'SLUS-00922': { title: 'Medal of Honor', region: 'NTSC-U', genre: 'FPS', maxPlayers: 2 },
  'SLUS-01270': { title: 'Medal of Honor: Underground', region: 'NTSC-U', genre: 'FPS', maxPlayers: 2 },
  'SLUS-00865': { title: 'Spider-Man', region: 'NTSC-U', genre: 'Ação Aventura', maxPlayers: 1 },
  'SLUS-01378': { title: 'Spider-Man 2: Enter Electro', region: 'NTSC-U', genre: 'Ação Aventura', maxPlayers: 1 },
  'SLUS-00900': { title: 'Digimon World', region: 'NTSC-U', genre: 'RPG', maxPlayers: 2 },
  'SLUS-01328': { title: 'Digimon World 2', region: 'NTSC-U', genre: 'RPG', maxPlayers: 1 },
  'SLUS-01436': { title: 'Digimon World 3', region: 'NTSC-U', genre: 'RPG', maxPlayers: 1 },
  'SLUS-01193': { title: 'Digimon Rumble Arena', region: 'NTSC-U', genre: 'Luta Arena', maxPlayers: 2 },
  'SCUS-94240': { title: 'Twisted Metal 2', region: 'NTSC-U', genre: 'Combate Veicular', maxPlayers: 2 },
  'SCUS-94306': { title: 'Syphon Filter', region: 'NTSC-U', genre: 'Ação Tática', maxPlayers: 1 },
  'SCUS-94451': { title: 'Syphon Filter 2 (Disc 1)', region: 'NTSC-U', genre: 'Ação Tática', maxPlayers: 2 },
  'SLUS-00592': { title: 'Vigilante 8', region: 'NTSC-U', genre: 'Combate Veicular', maxPlayers: 2 },
  'SLUS-00868': { title: 'Vigilante 8: 2nd Offense', region: 'NTSC-U', genre: 'Combate Veicular', maxPlayers: 2 },
  'SLUS-00778': { title: 'Metal Slug X', region: 'NTSC-U', genre: 'Run and Gun', maxPlayers: 2 },
  'SLUS-00419': { title: 'Mega Man X4', region: 'NTSC-U', genre: 'Ação Plataforma', maxPlayers: 1 },
  'SLUS-01334': { title: 'Mega Man X5', region: 'NTSC-U', genre: 'Ação Plataforma', maxPlayers: 1 },
  'SLUS-01395': { title: 'Mega Man X6', region: 'NTSC-U', genre: 'Ação Plataforma', maxPlayers: 1 },
  'SLUS-00896': { title: 'Parasite Eve II (Disc 1)', region: 'NTSC-U', genre: 'Action RPG', maxPlayers: 1 },
  'SLUS-00662': { title: 'Parasite Eve (Disc 1)', region: 'NTSC-U', genre: 'Action RPG', maxPlayers: 1 },
  'SLUS-00680': { title: 'Tomb Raider III', region: 'NTSC-U', genre: 'Aventura', maxPlayers: 1 },
  'SLUS-00437': { title: 'Tomb Raider II', region: 'NTSC-U', genre: 'Aventura', maxPlayers: 1 },
  'SLUS-00152': { title: 'Tomb Raider', region: 'NTSC-U', genre: 'Aventura', maxPlayers: 1 },
  'SLUS-00721': { title: 'Legacy of Kain: Soul Reaver', region: 'NTSC-U', genre: 'Ação Aventura', maxPlayers: 1 },
  'SLUS-01053': { title: 'Vagrant Story', region: 'NTSC-U', genre: 'Action RPG', maxPlayers: 1 },
  'SLUS-00676': { title: 'Silent Bomber', region: 'NTSC-U', genre: 'Ação', maxPlayers: 2 },
  'SLUS-00956': { title: 'Jackie Chan Stuntmaster', region: 'NTSC-U', genre: 'Beat em Up', maxPlayers: 1 },
  'SLUS-00974': { title: 'WWF SmackDown! 2: Know Your Role', region: 'NTSC-U', genre: 'Wrestling', maxPlayers: 2 },
  'SLUS-00858': { title: 'CTR / Quake II', region: 'NTSC-U', genre: 'FPS', maxPlayers: 2 },
  'SLES-01090': { title: 'Resident Evil 2 (PAL)', region: 'PAL', genre: 'Survival Horror', maxPlayers: 1 },
  'SLES-01265': { title: 'Tekken 3 (PAL)', region: 'PAL', genre: 'Luta 3D', maxPlayers: 2 },
  'SCES-00344': { title: 'Crash Bandicoot (PAL)', region: 'PAL', genre: 'Plataforma 3D', maxPlayers: 1 },
  'SCES-01420': { title: 'Crash Bandicoot 3: Warped (PAL)', region: 'PAL', genre: 'Plataforma 3D', maxPlayers: 1 },
  'SCES-02105': { title: 'Crash Team Racing (PAL)', region: 'PAL', genre: 'Corrida Kart', maxPlayers: 2 },
  'SCES-00984': { title: 'Gran Turismo (PAL)', region: 'PAL', genre: 'Corrida Simulador', maxPlayers: 2 },
  'SCES-02380': { title: 'Gran Turismo 2 (PAL)', region: 'PAL', genre: 'Corrida Simulador', maxPlayers: 2 },
  'SLES-01506': { title: 'Metal Gear Solid (PAL)', region: 'PAL', genre: 'Stealth Action', maxPlayers: 1 },
  'SLES-01734': { title: 'Silent Hill (PAL)', region: 'PAL', genre: 'Survival Horror', maxPlayers: 1 },
  'SLES-00524': { title: 'Castlevania: Symphony of the Night (PAL)', region: 'PAL', genre: 'Ação RPG', maxPlayers: 1 },
  'SLES-02529': { title: 'Resident Evil 3: Nemesis (PAL)', region: 'PAL', genre: 'Survival Horror', maxPlayers: 1 },
  'SLUS-00797': { title: 'R4: Ridge Racer Type 4', region: 'NTSC-U', genre: 'Corrida Arcade', maxPlayers: 2 },
  'SCES-01706': { title: 'R4: Ridge Racer Type 4 (PAL)', region: 'PAL', genre: 'Corrida Arcade', maxPlayers: 2 },
  'SLPS-01800': { title: 'R4: Ridge Racer Type 4 (NTSC-J)', region: 'NTSC-J', genre: 'Corrida Arcade', maxPlayers: 2 },
  'SCUS-94300': { title: 'Ridge Racer', region: 'NTSC-U', genre: 'Corrida Arcade', maxPlayers: 1 },
  'SLUS-00214': { title: 'Ridge Racer Revolution', region: 'NTSC-U', genre: 'Corrida Arcade', maxPlayers: 2 },
  'SLUS-00403': { title: 'Rage Racer', region: 'NTSC-U', genre: 'Corrida Arcade', maxPlayers: 1 },
};

const FILENAME_HINTS: Array<{ match: RegExp; serial: string }> = [
  { match: /RIDGE\s*RACER\s*TYPE\s*4|\bR4\b/i, serial: 'SLUS-00797' },
  { match: /CRASH\s*TEAM\s*RACING|\bCTR\b/i, serial: 'SCUS-94426' },
  { match: /CRASH\s*BANDICOOT\s*3|WARPED/i, serial: 'SCUS-94244' },
  { match: /CRASH\s*BANDICOOT\s*2/i, serial: 'SCUS-94154' },
  { match: /CRASH\s*BANDICOOT/i, serial: 'SCUS-94900' },
  { match: /TEKKEN\s*3/i, serial: 'SLUS-00707' },
  { match: /GRAN\s*TURISMO\s*2/i, serial: 'SCUS-94455' },
  { match: /GRAN\s*TURISMO/i, serial: 'SCUS-94163' },
  { match: /RESIDENT\s*EVIL\s*3/i, serial: 'SLUS-00923' },
  { match: /RESIDENT\s*EVIL\s*2/i, serial: 'SLUS-00594' },
  { match: /SILENT\s*HILL/i, serial: 'SLUS-00704' },
  { match: /CASTLEVANIA|SYMPHONY\s*OF\s*THE\s*NIGHT/i, serial: 'SLUS-00402' },
  { match: /METAL\s*GEAR\s*SOLID/i, serial: 'SLUS-00776' },
  { match: /WINNING\s*ELEVEN\s*2002/i, serial: 'SLPM-87056' },
  { match: /WINNING\s*ELEVEN/i, serial: 'SLPM-86600' },
  { match: /TONY\s*HAWK.*2/i, serial: 'SLUS-01264' },
  { match: /DINO\s*CRISIS\s*2/i, serial: 'SLUS-01279' },
  { match: /PEPSIMAN/i, serial: 'SLPS-01057' },
  { match: /YU[- ]?GI[- ]?OH/i, serial: 'SLUS-00875' },
];

export function normalizePs1Serial(rawSerial: string): string {
  const m = rawSerial.toUpperCase().match(/([A-Z]{4})[_-]?(\d{3})\.?(\d{2})/);
  if (!m) return rawSerial.toUpperCase().trim();
  return `${m[1]}-${m[2]}${m[3]}`;
}

export function lookupPs1TitleBySerial(rawSerial: string, volumeLabel: string): RecognizedPs1Title {
  const normalized = normalizePs1Serial(rawSerial);
  const found = PS1_SERIAL_MAP[normalized];
  if (found) {
    return { serial: normalized, ...found };
  }

  const isContainer = /^(RAW-IMG|CHD-DISC|PBP-EBOOT|ZIP-PACK|7Z-PACK|RAR-PACK|ECM-PACK|PSX-EXE)$/.test(normalized);
  if (isContainer && volumeLabel) {
    const cleanLabel = volumeLabel.replace(/[_.-]+/g, ' ');
    for (const hint of FILENAME_HINTS) {
      if (hint.match.test(cleanLabel)) {
        const entry = PS1_SERIAL_MAP[hint.serial];
        if (entry) {
          return { serial: hint.serial, ...entry };
        }
      }
    }
  }

  let region: RecognizedPs1Title['region'] = 'Homebrew';
  if (/^(SCUS|SLUS|PAPX)/.test(normalized)) region = 'NTSC-U';
  else if (/^(SCES|SLES)/.test(normalized)) region = 'PAL';
  else if (/^(SCPS|SLPS|SLPM)/.test(normalized)) region = 'NTSC-J';

  const fallbackTitle = volumeLabel && volumeLabel !== 'PS1_DISC'
    ? volumeLabel.replace(/_/g, ' ')
    : normalized || 'PlayStation 1 ISO';

  return {
    serial: normalized || 'PSX-ISO',
    title: fallbackTitle,
    region,
    genre: 'Disco PS1 (ISO/BIN/CHD/PBP)',
    maxPlayers: 2,
  };
}
