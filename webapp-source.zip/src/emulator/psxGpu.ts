// PlayStation 1 GPU (1024x512 16-bit BGR555 VRAM + GP0/GP1 + Textured 4-bit/8-bit/15-bit CLUT + Gouraud)

const FONT_5X7: Record<string, number[]> = {
  ' ': [0, 0, 0, 0, 0, 0, 0],
  '!': [4, 4, 4, 4, 4, 0, 4],
  '-': [0, 0, 0, 31, 0, 0, 0],
  '.': [0, 0, 0, 0, 0, 0, 4],
  ':': [0, 4, 0, 0, 0, 4, 0],
  '/': [1, 2, 2, 4, 8, 8, 16],
  '(': [2, 4, 8, 8, 8, 4, 2],
  ')': [8, 4, 2, 2, 2, 4, 8],
  '0': [14, 17, 19, 21, 25, 17, 14],
  '1': [4, 12, 4, 4, 4, 4, 14],
  '2': [14, 17, 1, 6, 8, 16, 31],
  '3': [31, 2, 4, 2, 1, 17, 14],
  '4': [2, 6, 10, 18, 31, 2, 2],
  '5': [31, 16, 30, 1, 1, 17, 14],
  '6': [6, 8, 16, 30, 17, 17, 14],
  '7': [31, 1, 2, 4, 8, 8, 8],
  '8': [14, 17, 17, 14, 17, 17, 14],
  '9': [14, 17, 17, 15, 1, 2, 12],
  A: [14, 17, 17, 31, 17, 17, 17],
  B: [30, 17, 17, 30, 17, 17, 30],
  C: [14, 17, 16, 16, 16, 17, 14],
  D: [30, 17, 17, 17, 17, 17, 30],
  E: [31, 16, 16, 30, 16, 16, 31],
  F: [31, 16, 16, 30, 16, 16, 16],
  G: [14, 17, 16, 23, 17, 17, 15],
  H: [17, 17, 17, 31, 17, 17, 17],
  I: [14, 4, 4, 4, 4, 4, 14],
  J: [7, 2, 2, 2, 2, 18, 12],
  K: [17, 18, 20, 24, 20, 18, 17],
  L: [16, 16, 16, 16, 16, 16, 31],
  M: [17, 27, 21, 21, 17, 17, 17],
  N: [17, 25, 21, 19, 17, 17, 17],
  O: [14, 17, 17, 17, 17, 17, 14],
  P: [30, 17, 17, 30, 16, 16, 16],
  Q: [14, 17, 17, 17, 21, 18, 13],
  R: [30, 17, 17, 30, 20, 18, 17],
  S: [15, 16, 16, 14, 1, 1, 30],
  T: [31, 4, 4, 4, 4, 4, 4],
  U: [17, 17, 17, 17, 17, 17, 14],
  V: [17, 17, 17, 17, 17, 10, 4],
  W: [17, 17, 17, 21, 21, 27, 17],
  X: [17, 17, 10, 4, 10, 17, 17],
  Y: [17, 17, 10, 4, 4, 4, 4],
  Z: [31, 1, 2, 4, 8, 16, 31],
};

export class PsxGpu {
  readonly vram = new Uint16Array(1024 * 512);
  displayWidth = 320;
  displayHeight = 240;
  readonly rgbaFrame = new Uint8ClampedArray(320 * 240 * 4);

  vramWrites = 0;
  gpuStat = 0x1c000000;

  private dispX = 0;
  private dispY = 0;
  private dispEnabled = true;
  private drawX1 = 0;
  private drawY1 = 0;
  private drawX2 = 319;
  private drawY2 = 239;
  private offX = 0;
  private offY = 0;
  private texPageX = 0;
  private texPageY = 0;
  private texDepth = 0; // 0: 4-bit, 1: 8-bit, 2: 15-bit

  private fifo: number[] = [];
  private expectedWords = 0;
  private transferMode: 'none' | 'cpu_to_vram' = 'none';
  private txX = 0;
  private txY = 0;
  private txW = 0;
  private txH = 0;
  private txCursor = 0;

  private readX = 0;
  private readY = 0;
  private readW = 0;
  private readH = 0;
  private readCursor = 0;
  private readActive = false;

  reset(): void {
    this.vram.fill(0);
    this.rgbaFrame.fill(0);
    this.fifo = [];
    this.expectedWords = 0;
    this.transferMode = 'none';
    this.readActive = false;
    this.dispX = 0;
    this.dispY = 0;
    this.dispEnabled = true;
    this.drawX1 = 0;
    this.drawY1 = 0;
    this.drawX2 = 319;
    this.drawY2 = 239;
    this.offX = 0;
    this.offY = 0;
    this.texPageX = 0;
    this.texPageY = 0;
    this.texDepth = 0;
    this.vramWrites = 0;
    this.gpuStat = 0x1c000000;
  }

  private rgb24ToBgr555(rgb24: number): number {
    const r = (rgb24 & 0xff) >> 3;
    const g = ((rgb24 >> 8) & 0xff) >> 3;
    const b = ((rgb24 >> 16) & 0xff) >> 3;
    return r | (g << 5) | (b << 10);
  }

  private setVramPixel(x: number, y: number, bgr555: number): void {
    if (x < this.drawX1 || x > this.drawX2 || y < this.drawY1 || y > this.drawY2) return;
    if (x < 0 || x >= 1024 || y < 0 || y >= 512) return;
    this.vram[y * 1024 + x] = bgr555 & 0x7fff;
    this.vramWrites++;
  }

  private sampleTexel(u: number, v: number, tpage: number, clut: number): number {
    const pageX = (tpage & 0x0f) * 64;
    const pageY = ((tpage >> 4) & 0x01) * 256;
    const depth = (tpage >> 7) & 0x03;
    const clutX = (clut & 0x3f) * 16;
    const clutY = (clut >> 6) & 0x1ff;

    const uu = u & 0xff;
    const vv = v & 0xff;
    const vy = (pageY + vv) & 0x1ff;

    if (depth === 0) {
      // 4-bit CLUT
      const word = this.vram[vy * 1024 + ((pageX + (uu >> 2)) & 0x3ff)];
      const idx = (word >> ((uu & 3) * 4)) & 0x0f;
      return this.vram[clutY * 1024 + ((clutX + idx) & 0x3ff)];
    }
    if (depth === 1) {
      // 8-bit CLUT
      const word = this.vram[vy * 1024 + ((pageX + (uu >> 1)) & 0x3ff)];
      const idx = (word >> ((uu & 1) * 8)) & 0xff;
      return this.vram[clutY * 1024 + ((clutX + idx) & 0x3ff)];
    }
    // 15-bit direct
    return this.vram[vy * 1024 + ((pageX + uu) & 0x3ff)];
  }

  fillRectVram(x: number, y: number, w: number, h: number, rgb24: number): void {
    const col = this.rgb24ToBgr555(rgb24);
    const startX = Math.max(0, x & 0x3f0);
    const startY = Math.max(0, y & 0x1ff);
    const endX = Math.min(1024, startX + w);
    const endY = Math.min(512, startY + h);
    for (let py = startY; py < endY; py++) {
      const row = py * 1024;
      for (let px = startX; px < endX; px++) {
        this.vram[row + px] = col;
      }
    }
    this.vramWrites += Math.max(1, (endX - startX) * (endY - startY));
  }

  drawRect(x: number, y: number, w: number, h: number, rgb24: number): void {
    const col = this.rgb24ToBgr555(rgb24);
    const x0 = Math.max(this.drawX1, x + this.offX);
    const y0 = Math.max(this.drawY1, y + this.offY);
    const x1 = Math.min(this.drawX2 + 1, x + this.offX + w);
    const y1 = Math.min(this.drawY2 + 1, y + this.offY + h);
    for (let py = y0; py < y1; py++) {
      const row = py * 1024;
      for (let px = x0; px < x1; px++) {
        this.vram[row + px] = col;
      }
    }
    this.vramWrites += Math.max(1, (x1 - x0) * (y1 - y0));
  }

  drawTexturedRect(
    x: number,
    y: number,
    w: number,
    h: number,
    u0: number,
    v0: number,
    clut: number,
  ): void {
    const tpage = (this.texPageX / 64) | ((this.texPageY / 256) << 4) | (this.texDepth << 7);
    const sx = x + this.offX;
    const sy = y + this.offY;
    for (let py = 0; py < h; py++) {
      for (let px = 0; px < w; px++) {
        const texel = this.sampleTexel(u0 + px, v0 + py, tpage, clut);
        if (texel !== 0) {
          this.setVramPixel(sx + px, sy + py, texel);
        }
      }
    }
  }

  drawLine(x0: number, y0: number, x1: number, y1: number, rgb24: number): void {
    const col = this.rgb24ToBgr555(rgb24);
    let px0 = x0 + this.offX;
    let py0 = y0 + this.offY;
    const px1 = x1 + this.offX;
    const py1 = y1 + this.offY;
    const dx = Math.abs(px1 - px0);
    const dy = -Math.abs(py1 - py0);
    const sx = px0 < px1 ? 1 : -1;
    const sy = py0 < py1 ? 1 : -1;
    let err = dx + dy;
    let guard = 0;
    while (guard++ < 1024) {
      this.setVramPixel(px0, py0, col);
      if (px0 === px1 && py0 === py1) break;
      const e2 = 2 * err;
      if (e2 >= dy) {
        err += dy;
        px0 += sx;
      }
      if (e2 <= dx) {
        err += dx;
        py0 += sy;
      }
    }
  }

  drawTriangleShaded(
    x0: number, y0: number, c0: number,
    x1: number, y1: number, c1: number,
    x2: number, y2: number, c2: number,
  ): void {
    const px0 = x0 + this.offX;
    const py0 = y0 + this.offY;
    const px1 = x1 + this.offX;
    const py1 = y1 + this.offY;
    const px2 = x2 + this.offX;
    const py2 = y2 + this.offY;

    const minX = Math.max(this.drawX1, Math.min(px0, px1, px2));
    const maxX = Math.min(this.drawX2, Math.max(px0, px1, px2));
    const minY = Math.max(this.drawY1, Math.min(py0, py1, py2));
    const maxY = Math.min(this.drawY2, Math.max(py0, py1, py2));

    const area = (px1 - px0) * (py2 - py0) - (py1 - py0) * (px2 - px0);
    if (area === 0) return;

    const r0 = c0 & 0xff, g0 = (c0 >> 8) & 0xff, b0 = (c0 >> 16) & 0xff;
    const r1 = c1 & 0xff, g1 = (c1 >> 8) & 0xff, b1 = (c1 >> 16) & 0xff;
    const r2 = c2 & 0xff, g2 = (c2 >> 8) & 0xff, b2 = (c2 >> 16) & 0xff;

    for (let py = minY; py <= maxY; py++) {
      for (let px = minX; px <= maxX; px++) {
        const w0 = (px1 - px) * (py2 - py) - (py1 - py) * (px2 - px);
        const w1 = (px2 - px) * (py0 - py) - (py2 - py) * (px0 - px);
        const w2 = (px0 - px) * (py1 - py) - (py0 - py) * (px1 - px);
        const inside = area > 0 ? (w0 >= 0 && w1 >= 0 && w2 >= 0) : (w0 <= 0 && w1 <= 0 && w2 <= 0);
        if (inside) {
          const l0 = w0 / area;
          const l1 = w1 / area;
          const l2 = w2 / area;
          const rr = Math.min(255, Math.max(0, (r0 * l0 + r1 * l1 + r2 * l2) | 0)) >> 3;
          const gg = Math.min(255, Math.max(0, (g0 * l0 + g1 * l1 + g2 * l2) | 0)) >> 3;
          const bb = Math.min(255, Math.max(0, (b0 * l0 + b1 * l1 + b2 * l2) | 0)) >> 3;
          this.setVramPixel(px, py, rr | (gg << 5) | (bb << 10));
        }
      }
    }
  }

  drawTriangleTextured(
    x0: number, y0: number, u0: number, v0: number,
    x1: number, y1: number, u1: number, v1: number,
    x2: number, y2: number, u2: number, v2: number,
    tpage: number, clut: number,
  ): void {
    const px0 = x0 + this.offX, py0 = y0 + this.offY;
    const px1 = x1 + this.offX, py1 = y1 + this.offY;
    const px2 = x2 + this.offX, py2 = y2 + this.offY;

    const minX = Math.max(this.drawX1, Math.min(px0, px1, px2));
    const maxX = Math.min(this.drawX2, Math.max(px0, px1, px2));
    const minY = Math.max(this.drawY1, Math.min(py0, py1, py2));
    const maxY = Math.min(this.drawY2, Math.max(py0, py1, py2));

    const area = (px1 - px0) * (py2 - py0) - (py1 - py0) * (px2 - px0);
    if (area === 0) return;

    for (let py = minY; py <= maxY; py++) {
      for (let px = minX; px <= maxX; px++) {
        const w0 = (px1 - px) * (py2 - py) - (py1 - py) * (px2 - px);
        const w1 = (px2 - px) * (py0 - py) - (py2 - py) * (px0 - px);
        const w2 = (px0 - px) * (py1 - py) - (py0 - py) * (px1 - px);
        const inside = area > 0 ? (w0 >= 0 && w1 >= 0 && w2 >= 0) : (w0 <= 0 && w1 <= 0 && w2 <= 0);
        if (inside) {
          const l0 = w0 / area;
          const l1 = w1 / area;
          const l2 = w2 / area;
          const uu = (u0 * l0 + u1 * l1 + u2 * l2) | 0;
          const vv = (v0 * l0 + v1 * l1 + v2 * l2) | 0;
          const texel = this.sampleTexel(uu, vv, tpage, clut);
          if (texel !== 0) {
            this.setVramPixel(px, py, texel);
          }
        }
      }
    }
  }

  drawText(x: number, y: number, text: string, rgb24: number, scale = 1): void {
    const col = this.rgb24ToBgr555(rgb24);
    const upper = text.toUpperCase();
    let cx = x + this.offX;
    const cy = y + this.offY;
    for (let i = 0; i < upper.length; i++) {
      const glyph = FONT_5X7[upper[i]] ?? FONT_5X7[' '];
      for (let row = 0; row < 7; row++) {
        const bits = glyph[row];
        for (let bit = 0; bit < 5; bit++) {
          if (bits & (1 << (4 - bit))) {
            for (let sy = 0; sy < scale; sy++) {
              for (let sx = 0; sx < scale; sx++) {
                this.setVramPixel(cx + bit * scale + sx, cy + row * scale + sy, col);
              }
            }
          }
        }
      }
      cx += 6 * scale;
    }
  }

  readGpuData(): number {
    if (!this.readActive) return 0;
    const total = this.readW * this.readH;
    const x1 = (this.readX + (this.readCursor % this.readW)) & 0x3ff;
    const y1 = (this.readY + Math.floor(this.readCursor / this.readW)) & 0x1ff;
    const p1 = this.vram[y1 * 1024 + x1];
    this.readCursor++;

    let p2 = 0;
    if (this.readCursor < total) {
      const x2 = (this.readX + (this.readCursor % this.readW)) & 0x3ff;
      const y2 = (this.readY + Math.floor(this.readCursor / this.readW)) & 0x1ff;
      p2 = this.vram[y2 * 1024 + x2];
      this.readCursor++;
    }
    if (this.readCursor >= total) {
      this.readActive = false;
    }
    return ((p2 << 16) | p1) >>> 0;
  }

  writeGp0(word: number): void {
    word = word >>> 0;
    if (this.transferMode === 'cpu_to_vram') {
      const p1 = word & 0xffff;
      const p2 = (word >>> 16) & 0xffff;
      for (const px of [p1, p2]) {
        if (this.txCursor < this.txW * this.txH) {
          const x = (this.txX + (this.txCursor % this.txW)) & 0x3ff;
          const y = (this.txY + Math.floor(this.txCursor / this.txW)) & 0x1ff;
          this.vram[y * 1024 + x] = px & 0x7fff;
          this.txCursor++;
          this.vramWrites++;
        }
      }
      if (this.txCursor >= this.txW * this.txH) {
        this.transferMode = 'none';
      }
      return;
    }

    this.fifo.push(word);
    if (this.fifo.length === 1) {
      const cmd = (word >>> 24) & 0xff;
      this.expectedWords = this.getCommandLength(cmd);
    }

    if (this.fifo.length >= this.expectedWords) {
      this.executeGp0();
      this.fifo = [];
      this.expectedWords = 0;
    }
  }

  private getCommandLength(cmd: number): number {
    if (cmd === 0x00 || cmd === 0x01) return 1;
    if (cmd === 0x02) return 3;
    if (cmd === 0x20 || cmd === 0x22) return 4;
    if (cmd === 0x28 || cmd === 0x2a) return 5;
    if (cmd >= 0x24 && cmd <= 0x27) return 7;
    if (cmd >= 0x2c && cmd <= 0x2f) return 9;
    if (cmd === 0x30 || cmd === 0x32) return 6;
    if (cmd >= 0x34 && cmd <= 0x37) return 9;
    if (cmd === 0x38 || cmd === 0x3a) return 8;
    if (cmd >= 0x3c && cmd <= 0x3f) return 12;
    if (cmd === 0x40 || cmd === 0x42) return 3;
    if (cmd === 0x50 || cmd === 0x52) return 4;
    if (cmd === 0x60 || cmd === 0x62) return 3;
    if (cmd >= 0x64 && cmd <= 0x67) return 4;
    if (cmd === 0x68 || cmd === 0x70 || cmd === 0x78) return 2;
    if (cmd >= 0x74 && cmd <= 0x77) return 3;
    if (cmd >= 0x7c && cmd <= 0x7f) return 3;
    if (cmd === 0x80) return 4;
    if (cmd === 0xa0 || cmd === 0xc0) return 3;
    if (cmd >= 0xe1 && cmd <= 0xe6) return 1;
    return 1;
  }

  private signExtend11(val: number): number {
    val &= 0x7ff;
    return val & 0x400 ? val - 0x800 : val;
  }

  private executeGp0(): void {
    const w0 = this.fifo[0];
    const cmd = (w0 >>> 24) & 0xff;

    if (cmd === 0x02) {
      const x = this.fifo[1] & 0x3ff;
      const y = (this.fifo[1] >>> 16) & 0x1ff;
      const w = this.fifo[2] & 0x3ff;
      const h = (this.fifo[2] >>> 16) & 0x1ff;
      this.fillRectVram(x, y, w, h, w0 & 0xffffff);
    } else if (cmd === 0x20 || cmd === 0x22) {
      const col = w0 & 0xffffff;
      const x0 = this.signExtend11(this.fifo[1]), y0 = this.signExtend11(this.fifo[1] >>> 16);
      const x1 = this.signExtend11(this.fifo[2]), y1 = this.signExtend11(this.fifo[2] >>> 16);
      const x2 = this.signExtend11(this.fifo[3]), y2 = this.signExtend11(this.fifo[3] >>> 16);
      this.drawTriangleShaded(x0, y0, col, x1, y1, col, x2, y2, col);
    } else if (cmd >= 0x24 && cmd <= 0x27) {
      const x0 = this.signExtend11(this.fifo[1]), y0 = this.signExtend11(this.fifo[1] >>> 16);
      const u0 = this.fifo[2] & 0xff, v0 = (this.fifo[2] >>> 8) & 0xff, clut = (this.fifo[2] >>> 16) & 0xffff;
      const x1 = this.signExtend11(this.fifo[3]), y1 = this.signExtend11(this.fifo[3] >>> 16);
      const u1 = this.fifo[4] & 0xff, v1 = (this.fifo[4] >>> 8) & 0xff, tpage = (this.fifo[4] >>> 16) & 0xffff;
      const x2 = this.signExtend11(this.fifo[5]), y2 = this.signExtend11(this.fifo[5] >>> 16);
      const u2 = this.fifo[6] & 0xff, v2 = (this.fifo[6] >>> 8) & 0xff;
      this.drawTriangleTextured(x0, y0, u0, v0, x1, y1, u1, v1, x2, y2, u2, v2, tpage, clut);
    } else if (cmd === 0x28 || cmd === 0x2a) {
      const col = w0 & 0xffffff;
      const x0 = this.signExtend11(this.fifo[1]), y0 = this.signExtend11(this.fifo[1] >>> 16);
      const x1 = this.signExtend11(this.fifo[2]), y1 = this.signExtend11(this.fifo[2] >>> 16);
      const x2 = this.signExtend11(this.fifo[3]), y2 = this.signExtend11(this.fifo[3] >>> 16);
      const x3 = this.signExtend11(this.fifo[4]), y3 = this.signExtend11(this.fifo[4] >>> 16);
      this.drawTriangleShaded(x0, y0, col, x1, y1, col, x2, y2, col);
      this.drawTriangleShaded(x1, y1, col, x2, y2, col, x3, y3, col);
    } else if (cmd >= 0x2c && cmd <= 0x2f) {
      const x0 = this.signExtend11(this.fifo[1]), y0 = this.signExtend11(this.fifo[1] >>> 16);
      const u0 = this.fifo[2] & 0xff, v0 = (this.fifo[2] >>> 8) & 0xff, clut = (this.fifo[2] >>> 16) & 0xffff;
      const x1 = this.signExtend11(this.fifo[3]), y1 = this.signExtend11(this.fifo[3] >>> 16);
      const u1 = this.fifo[4] & 0xff, v1 = (this.fifo[4] >>> 8) & 0xff, tpage = (this.fifo[4] >>> 16) & 0xffff;
      const x2 = this.signExtend11(this.fifo[5]), y2 = this.signExtend11(this.fifo[5] >>> 16);
      const u2 = this.fifo[6] & 0xff, v2 = (this.fifo[6] >>> 8) & 0xff;
      const x3 = this.signExtend11(this.fifo[7]), y3 = this.signExtend11(this.fifo[7] >>> 16);
      const u3 = this.fifo[8] & 0xff, v3 = (this.fifo[8] >>> 8) & 0xff;
      this.drawTriangleTextured(x0, y0, u0, v0, x1, y1, u1, v1, x2, y2, u2, v2, tpage, clut);
      this.drawTriangleTextured(x1, y1, u1, v1, x2, y2, u2, v2, x3, y3, u3, v3, tpage, clut);
    } else if (cmd === 0x30 || cmd === 0x32) {
      const c0 = w0 & 0xffffff;
      const x0 = this.signExtend11(this.fifo[1]), y0 = this.signExtend11(this.fifo[1] >>> 16);
      const c1 = this.fifo[2] & 0xffffff;
      const x1 = this.signExtend11(this.fifo[3]), y1 = this.signExtend11(this.fifo[3] >>> 16);
      const c2 = this.fifo[4] & 0xffffff;
      const x2 = this.signExtend11(this.fifo[5]), y2 = this.signExtend11(this.fifo[5] >>> 16);
      this.drawTriangleShaded(x0, y0, c0, x1, y1, c1, x2, y2, c2);
    } else if (cmd === 0x38 || cmd === 0x3a) {
      const c0 = w0 & 0xffffff;
      const x0 = this.signExtend11(this.fifo[1]), y0 = this.signExtend11(this.fifo[1] >>> 16);
      const c1 = this.fifo[2] & 0xffffff;
      const x1 = this.signExtend11(this.fifo[3]), y1 = this.signExtend11(this.fifo[3] >>> 16);
      const c2 = this.fifo[4] & 0xffffff;
      const x2 = this.signExtend11(this.fifo[5]), y2 = this.signExtend11(this.fifo[5] >>> 16);
      const c3 = this.fifo[6] & 0xffffff;
      const x3 = this.signExtend11(this.fifo[7]), y3 = this.signExtend11(this.fifo[7] >>> 16);
      this.drawTriangleShaded(x0, y0, c0, x1, y1, c1, x2, y2, c2);
      this.drawTriangleShaded(x1, y1, c1, x2, y2, c2, x3, y3, c3);
    } else if (cmd === 0x40 || cmd === 0x42) {
      const x0 = this.signExtend11(this.fifo[1]), y0 = this.signExtend11(this.fifo[1] >>> 16);
      const x1 = this.signExtend11(this.fifo[2]), y1 = this.signExtend11(this.fifo[2] >>> 16);
      this.drawLine(x0, y0, x1, y1, w0 & 0xffffff);
    } else if (cmd === 0x50 || cmd === 0x52) {
      const x0 = this.signExtend11(this.fifo[1]), y0 = this.signExtend11(this.fifo[1] >>> 16);
      const x1 = this.signExtend11(this.fifo[3]), y1 = this.signExtend11(this.fifo[3] >>> 16);
      this.drawLine(x0, y0, x1, y1, w0 & 0xffffff);
    } else if (cmd === 0x60 || cmd === 0x62) {
      const x = this.signExtend11(this.fifo[1]);
      const y = this.signExtend11(this.fifo[1] >>> 16);
      const w = this.fifo[2] & 0x3ff;
      const h = (this.fifo[2] >>> 16) & 0x1ff;
      this.drawRect(x, y, w, h, w0 & 0xffffff);
    } else if (cmd >= 0x64 && cmd <= 0x67) {
      const x = this.signExtend11(this.fifo[1]), y = this.signExtend11(this.fifo[1] >>> 16);
      const u = this.fifo[2] & 0xff, v = (this.fifo[2] >>> 8) & 0xff, clut = (this.fifo[2] >>> 16) & 0xffff;
      const w = this.fifo[3] & 0x3ff, h = (this.fifo[3] >>> 16) & 0x1ff;
      this.drawTexturedRect(x, y, w, h, u, v, clut);
    } else if (cmd >= 0x74 && cmd <= 0x77) {
      const x = this.signExtend11(this.fifo[1]), y = this.signExtend11(this.fifo[1] >>> 16);
      const u = this.fifo[2] & 0xff, v = (this.fifo[2] >>> 8) & 0xff, clut = (this.fifo[2] >>> 16) & 0xffff;
      this.drawTexturedRect(x, y, 8, 8, u, v, clut);
    } else if (cmd >= 0x7c && cmd <= 0x7f) {
      const x = this.signExtend11(this.fifo[1]), y = this.signExtend11(this.fifo[1] >>> 16);
      const u = this.fifo[2] & 0xff, v = (this.fifo[2] >>> 8) & 0xff, clut = (this.fifo[2] >>> 16) & 0xffff;
      this.drawTexturedRect(x, y, 16, 16, u, v, clut);
    } else if (cmd === 0x80) {
      const sx = this.fifo[1] & 0x3ff, sy = (this.fifo[1] >>> 16) & 0x1ff;
      const dx = this.fifo[2] & 0x3ff, dy = (this.fifo[2] >>> 16) & 0x1ff;
      const w = this.fifo[3] & 0x3ff || 1024;
      const h = (this.fifo[3] >>> 16) & 0x1ff || 512;
      for (let py = 0; py < h; py++) {
        for (let px = 0; px < w; px++) {
          this.vram[((dy + py) & 0x1ff) * 1024 + ((dx + px) & 0x3ff)] =
            this.vram[((sy + py) & 0x1ff) * 1024 + ((sx + px) & 0x3ff)];
        }
      }
      this.vramWrites += w * h;
    } else if (cmd === 0xa0) {
      this.txX = this.fifo[1] & 0x3ff;
      this.txY = (this.fifo[1] >>> 16) & 0x1ff;
      this.txW = this.fifo[2] & 0x3ff || 1024;
      this.txH = (this.fifo[2] >>> 16) & 0x1ff || 512;
      this.txCursor = 0;
      this.transferMode = 'cpu_to_vram';
    } else if (cmd === 0xc0) {
      this.readX = this.fifo[1] & 0x3ff;
      this.readY = (this.fifo[1] >>> 16) & 0x1ff;
      this.readW = this.fifo[2] & 0x3ff || 1024;
      this.readH = (this.fifo[2] >>> 16) & 0x1ff || 512;
      this.readCursor = 0;
      this.readActive = true;
    } else if (cmd === 0xe1) {
      this.texPageX = (w0 & 0xf) * 64;
      this.texPageY = ((w0 >> 4) & 0x1) * 256;
      this.texDepth = (w0 >> 7) & 0x3;
    } else if (cmd === 0xe3) {
      this.drawX1 = w0 & 0x3ff;
      this.drawY1 = (w0 >>> 10) & 0x1ff;
    } else if (cmd === 0xe4) {
      this.drawX2 = w0 & 0x3ff;
      this.drawY2 = (w0 >>> 10) & 0x1ff;
    } else if (cmd === 0xe5) {
      this.offX = this.signExtend11(w0);
      this.offY = this.signExtend11(w0 >>> 11);
    }
  }

  writeGp1(word: number): void {
    const cmd = (word >>> 24) & 0xff;
    if (cmd === 0x00) {
      this.reset();
    } else if (cmd === 0x01) {
      this.fifo = [];
      this.expectedWords = 0;
      this.transferMode = 'none';
    } else if (cmd === 0x03) {
      this.dispEnabled = (word & 1) === 0;
    } else if (cmd === 0x05) {
      this.dispX = word & 0x3ff;
      this.dispY = (word >>> 10) & 0x1ff;
    }
  }

  renderToRgba(): Uint8ClampedArray {
    if (!this.dispEnabled) {
      this.rgbaFrame.fill(0);
      for (let i = 3; i < this.rgbaFrame.length; i += 4) {
        this.rgbaFrame[i] = 255;
      }
      return this.rgbaFrame;
    }

    const w = this.displayWidth;
    const h = this.displayHeight;
    let outIdx = 0;
    for (let y = 0; y < h; y++) {
      const vramRow = ((this.dispY + y) & 0x1ff) * 1024;
      for (let x = 0; x < w; x++) {
        const bgr = this.vram[vramRow + ((this.dispX + x) & 0x3ff)];
        const r = (bgr & 0x1f) << 3;
        const g = ((bgr >> 5) & 0x1f) << 3;
        const b = ((bgr >> 10) & 0x1f) << 3;
        this.rgbaFrame[outIdx++] = r | (r >> 5);
        this.rgbaFrame[outIdx++] = g | (g >> 5);
        this.rgbaFrame[outIdx++] = b | (b >> 5);
        this.rgbaFrame[outIdx++] = 255;
      }
    }
    return this.rgbaFrame;
  }
}
