import { RecognizedPs1Title } from './ps1SerialDb';

export const PSX_BTN = {
  SELECT: 1 << 0,
  L3: 1 << 1,
  R3: 1 << 2,
  START: 1 << 3,
  UP: 1 << 4,
  RIGHT: 1 << 5,
  DOWN: 1 << 6,
  LEFT: 1 << 7,
  L2: 1 << 8,
  R2: 1 << 9,
  L1: 1 << 10,
  R1: 1 << 11,
  TRIANGLE: 1 << 12,
  CIRCLE: 1 << 13,
  CROSS: 1 << 14,
  SQUARE: 1 << 15,
} as const;

export interface PsxPadState {
  /** 16-bit active-low PS1 button mask (0xFFFF = all released, bit=0 = pressed) */
  buttons: number;
  lx: number;
  ly: number;
  rx: number;
  ry: number;
}

export function createIdlePadState(): PsxPadState {
  return { buttons: 0xffff, lx: 128, ly: 128, rx: 128, ry: 128 };
}

export function mergePadStates(a: PsxPadState, b: PsxPadState): PsxPadState {
  return {
    buttons: a.buttons & b.buttons & 0xffff,
    lx: a.lx !== 128 ? a.lx : b.lx,
    ly: a.ly !== 128 ? a.ly : b.ly,
    rx: a.rx !== 128 ? a.rx : b.rx,
    ry: a.ry !== 128 ? a.ry : b.ry,
  };
}

export interface IsoMountInfo {
  filename: string;
  fileSizeBytes: number;
  sectorSize: 2048 | 2352 | 0;
  totalSectors: number;
  volumeLabel: string;
  bootExePath: string;
  serial: string;
  recognizedTitle: RecognizedPs1Title;
  systemCnfRaw: string;
  isDirectExe: boolean;
  exeLoadedBytes: number;
  pc0: number;
  gp0: number;
  sp0: number;
  tAddr: number;
  tSize: number;
  fileCount: number;
}

export interface EmulatorTelemetry {
  running: boolean;
  paused: boolean;
  fps: number;
  pc: number;
  sp: number;
  cycles: number;
  vramWrites: number;
  cdReads: number;
  pad1Mask: number;
  pad2Mask: number;
  biosMode: 'HLE_NO_BIOS';
  mountedDisc: IsoMountInfo | null;
  activeGameTitle: string;
  activeGameId: string;
  hleLogs: string[];
}
