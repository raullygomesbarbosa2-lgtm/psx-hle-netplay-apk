import { lookupPs1TitleBySerial } from './ps1SerialDb';
import { IsoMountInfo } from './types';

export interface IsoDirEntry {
  name: string;
  lba: number;
  size: number;
  isDir: boolean;
}

/**
 * Streaming chunked ISO-9660 / Mode-2 BIN / CUE / PS-X EXE reader.
 * Uses File.slice() exclusively so multi-GB ISOs load instantaneously without exhausting browser RAM.
 */
export class StreamingIsoReader {
  private file: File;
  sectorSize: 2048 | 2352 | 0 = 2048;
  userDataOffset = 0;
  private fileIndex = new Map<string, IsoDirEntry>();
  private sectorCache = new Map<number, Uint8Array>();

  constructor(file: File) {
    this.file = file;
  }

  private async readBytes(offset: number, length: number): Promise<Uint8Array> {
    if (offset >= this.file.size) {
      return new Uint8Array(0);
    }
    const end = Math.min(this.file.size, offset + length);
    const buf = await this.file.slice(offset, end).arrayBuffer();
    return new Uint8Array(buf);
  }

  async readSector(lba: number): Promise<Uint8Array> {
    if (this.sectorSize === 0) {
      return new Uint8Array(0);
    }
    const cached = this.sectorCache.get(lba);
    if (cached) return cached;

    const offset = lba * this.sectorSize + this.userDataOffset;
    const sec = await this.readBytes(offset, 2048);
    if (this.sectorCache.size > 512) {
      const firstKey = this.sectorCache.keys().next().value;
      if (firstKey !== undefined) this.sectorCache.delete(firstKey);
    }
    this.sectorCache.set(lba, sec);
    return sec;
  }

  getCachedSector(lba: number): Uint8Array | null {
    return this.sectorCache.get(lba) ?? null;
  }

  private async readIsoFile(lba: number, size: number): Promise<Uint8Array> {
    const clampedSize = Math.min(size, 8 * 1024 * 1024);
    const out = new Uint8Array(clampedSize);
    let written = 0;
    let currentLba = lba;
    while (written < clampedSize) {
      const sec = await this.readSector(currentLba);
      if (sec.length === 0) break;
      const toCopy = Math.min(sec.length, clampedSize - written);
      out.set(sec.subarray(0, toCopy), written);
      written += toCopy;
      currentLba++;
    }
    return out;
  }

  private async detectSectorGeometry(): Promise<{ stride: number; dataOffset: number; pvdLba: number } | null> {
    const candidates: Array<{ stride: 2048 | 2352 | 2336 | 2448; dataOffset: number }> = [
      { stride: 2048, dataOffset: 0 },
      { stride: 2352, dataOffset: 24 },
      { stride: 2352, dataOffset: 16 },
      { stride: 2336, dataOffset: 8 },
      { stride: 2448, dataOffset: 24 },
      { stride: 2448, dataOffset: 16 },
    ];

    // Check sector 16 first across all common PS1 disc sector layouts
    for (const c of candidates) {
      const probe = await this.readBytes(16 * c.stride + c.dataOffset, 8);
      if (
        probe.length >= 6 &&
        probe[0] === 0x01 &&
        probe[1] === 0x43 &&
        probe[2] === 0x44 &&
        probe[3] === 0x30 &&
        probe[4] === 0x30 &&
        probe[5] === 0x31
      ) {
        this.sectorSize = c.stride === 2352 ? 2352 : 2048;
        this.userDataOffset = c.dataOffset;
        return { stride: c.stride, dataOffset: c.dataOffset, pvdLba: 16 };
      }
    }

    const probeRaw = await this.readBytes(16 * 2352, 32);
    if (
      probeRaw.length >= 24 &&
      probeRaw[0] === 0x00 &&
      probeRaw[1] === 0xff &&
      probeRaw[10] === 0xff &&
      probeRaw[11] === 0x00
    ) {
      this.sectorSize = 2352;
      this.userDataOffset = probeRaw[15] === 2 ? 24 : 16;
      return { stride: 2352, dataOffset: this.userDataOffset, pvdLba: 16 };
    }

    // Fallback scan first 128 KB for "\x01CD001" in case of pregap/Nero header offset
    const headChunk = await this.readBytes(0, Math.min(this.file.size, 131072));
    for (let i = 0; i + 6 < headChunk.length; i++) {
      if (
        headChunk[i] === 0x01 &&
        headChunk[i + 1] === 0x43 &&
        headChunk[i + 2] === 0x44 &&
        headChunk[i + 3] === 0x30 &&
        headChunk[i + 4] === 0x30 &&
        headChunk[i + 5] === 0x31
      ) {
        for (const c of candidates) {
          if (i >= 16 * c.stride && (i - c.dataOffset) % c.stride === 0) {
            this.sectorSize = c.stride === 2352 ? 2352 : 2048;
            this.userDataOffset = c.dataOffset;
            return { stride: c.stride, dataOffset: c.dataOffset, pvdLba: Math.floor((i - c.dataOffset) / c.stride) };
          }
        }
      }
    }

    this.sectorSize = this.file.size % 2352 === 0 ? 2352 : 2048;
    this.userDataOffset = this.sectorSize === 2352 ? 24 : 0;
    return null;
  }

  private detectContainerTag(header: Uint8Array): { tag: string; label: string } | null {
    const ascii8 = new TextDecoder('ascii').decode(header.subarray(0, 8));
    if (ascii8.startsWith('MComprHD')) return { tag: 'CHD-DISC', label: 'MAME CHD Compactado' };
    if (header[0] === 0x00 && header[1] === 0x50 && header[2] === 0x42 && header[3] === 0x50) {
      return { tag: 'PBP-EBOOT', label: 'PSP PSOne Classic EBOOT.PBP' };
    }
    if (header[0] === 0x50 && header[1] === 0x4b && (header[2] === 0x03 || header[2] === 0x05)) {
      return { tag: 'ZIP-PACK', label: 'Arquivo ZIP' };
    }
    if (header[0] === 0x37 && header[1] === 0x7a && header[2] === 0xbc && header[3] === 0xaf) {
      return { tag: '7Z-PACK', label: 'Arquivo 7-Zip' };
    }
    if (ascii8.startsWith('Rar!')) return { tag: 'RAR-PACK', label: 'Arquivo RAR' };
    if (ascii8.startsWith('ECM\0')) return { tag: 'ECM-PACK', label: 'ECM Compactado' };
    return null;
  }

  private parseDirectoryRecords(data: Uint8Array, prefix: string, depth = 0): IsoDirEntry[] {
    const entries: IsoDirEntry[] = [];
    let offset = 0;
    while (offset < data.length) {
      const len = data[offset];
      if (len === 0) {
        const nextSector = Math.floor(offset / 2048 + 1) * 2048;
        if (nextSector >= data.length) break;
        offset = nextSector;
        continue;
      }
      if (offset + len > data.length || len < 34) break;
      const lba =
        data[offset + 2] |
        (data[offset + 3] << 8) |
        (data[offset + 4] << 16) |
        (data[offset + 5] << 24);
      const size =
        data[offset + 10] |
        (data[offset + 11] << 8) |
        (data[offset + 12] << 16) |
        (data[offset + 13] << 24);
      const flags = data[offset + 25];
      const nameLen = data[offset + 32];
      const rawNameBytes = data.subarray(offset + 33, offset + 33 + nameLen);

      if (!(nameLen === 1 && (rawNameBytes[0] === 0x00 || rawNameBytes[0] === 0x01))) {
        const rawName = new TextDecoder('ascii').decode(rawNameBytes).split(';')[0].trim();
        const fullPath = prefix ? `${prefix}/${rawName}` : rawName;
        const entry: IsoDirEntry = {
          name: fullPath.toUpperCase(),
          lba: lba >>> 0,
          size: size >>> 0,
          isDir: (flags & 0x02) !== 0,
        };
        entries.push(entry);
        this.fileIndex.set(entry.name, entry);
      }

      offset += len;
    }
    if (depth > 4) return entries;
    return entries;
  }

  private async indexDirectory(lba: number, size: number, prefix: string, depth = 0): Promise<void> {
    if (depth > 4 || size <= 0) return;
    const data = await this.readIsoFile(lba, Math.min(size, 65536));
    const entries = this.parseDirectoryRecords(data, prefix, depth);
    for (const entry of entries) {
      if (entry.isDir) {
        await this.indexDirectory(entry.lba, entry.size, entry.name, depth + 1);
      }
    }
  }

  private extractExeHeader(exeBytes: Uint8Array | null): {
    pc0: number;
    gp0: number;
    sp0: number;
    tAddr: number;
    tSize: number;
  } {
    if (!exeBytes || exeBytes.length < 0x38) {
      return { pc0: 0x80010000, gp0: 0x80090000, sp0: 0x801fff00, tAddr: 0x80010000, tSize: 0 };
    }
    const view = new DataView(exeBytes.buffer, exeBytes.byteOffset, exeBytes.byteLength);
    return {
      pc0: view.getUint32(0x10, true) >>> 0,
      gp0: view.getUint32(0x14, true) >>> 0,
      tAddr: view.getUint32(0x18, true) >>> 0,
      tSize: view.getUint32(0x1c, true) >>> 0,
      sp0: view.getUint32(0x30, true) >>> 0 || 0x801fff00,
    };
  }

  async mount(): Promise<{ info: IsoMountInfo; bootExeBytes: Uint8Array | null }> {
    const header = await this.readBytes(0, 16);
    const magic = new TextDecoder('ascii').decode(header.subarray(0, 8));
    if (magic === 'PS-X EXE') {
      const exeBytes = await this.readBytes(0, Math.min(this.file.size, 8 * 1024 * 1024));
      const hdr = this.extractExeHeader(exeBytes);
      const label = this.file.name.replace(/\.[^.]+$/, '').toUpperCase().slice(0, 32);
      return {
        info: {
          filename: this.file.name,
          fileSizeBytes: this.file.size,
          sectorSize: 0,
          totalSectors: 0,
          volumeLabel: label,
          bootExePath: this.file.name,
          serial: 'PSX-EXE',
          recognizedTitle: lookupPs1TitleBySerial('PSX-EXE', label),
          systemCnfRaw: '',
          isDirectExe: true,
          exeLoadedBytes: exeBytes.length,
          ...hdr,
          fileCount: 1,
        },
        bootExeBytes: exeBytes,
      };
    }

    const container = this.detectContainerTag(header);
    if (container) {
      const label = this.file.name.replace(/\.[^.]+$/, '').toUpperCase().slice(0, 48);
      const recognized = lookupPs1TitleBySerial(container.tag, label);
      return {
        info: {
          filename: this.file.name,
          fileSizeBytes: this.file.size,
          sectorSize: 2048,
          totalSectors: Math.floor(this.file.size / 2048),
          volumeLabel: label,
          bootExePath: container.label,
          serial: recognized.serial,
          recognizedTitle: recognized,
          systemCnfRaw: '',
          isDirectExe: false,
          exeLoadedBytes: 0,
          pc0: 0x80010000,
          gp0: 0x80090000,
          sp0: 0x801fff00,
          tAddr: 0x80010000,
          tSize: 0,
          fileCount: 1,
        },
        bootExeBytes: null,
      };
    }

    const geom = await this.detectSectorGeometry();
    const totalSectors = this.sectorSize > 0 ? Math.floor(this.file.size / this.sectorSize) : 0;

    // Pre-cache first 32 sectors so boot/VTOC/license reads are instant
    for (let s = 0; s < Math.min(32, totalSectors); s++) {
      await this.readSector(s);
    }

    const pvdLba = geom?.pvdLba ?? 16;
    const pvd = await this.readSector(pvdLba);
    const isIso9660 =
      pvd.length >= 2048 &&
      pvd[0] === 0x01 &&
      pvd[1] === 0x43 &&
      pvd[2] === 0x44 &&
      pvd[3] === 0x30 &&
      pvd[4] === 0x30 &&
      pvd[5] === 0x31;

    if (!isIso9660) {
      const label = this.file.name.replace(/\.[^.]+$/, '').toUpperCase().slice(0, 48);
      const recognized = lookupPs1TitleBySerial('RAW-IMG', label);
      return {
        info: {
          filename: this.file.name,
          fileSizeBytes: this.file.size,
          sectorSize: this.sectorSize,
          totalSectors,
          volumeLabel: label,
          bootExePath: 'BIN/IMG Direto',
          serial: recognized.serial,
          recognizedTitle: recognized,
          systemCnfRaw: '',
          isDirectExe: false,
          exeLoadedBytes: 0,
          pc0: 0x80010000,
          gp0: 0x80090000,
          sp0: 0x801fff00,
          tAddr: 0x80010000,
          tSize: 0,
          fileCount: 0,
        },
        bootExeBytes: null,
      };
    }

    const volumeLabel =
      new TextDecoder('ascii').decode(pvd.subarray(40, 72)).trim() ||
      this.file.name.replace(/\.[^.]+$/, '').toUpperCase();

    const rootLba =
      (pvd[156 + 2] | (pvd[156 + 3] << 8) | (pvd[156 + 4] << 16) | (pvd[156 + 5] << 24)) >>> 0;
    const rootSize =
      (pvd[156 + 10] | (pvd[156 + 11] << 8) | (pvd[156 + 12] << 16) | (pvd[156 + 13] << 24)) >>> 0;

    await this.indexDirectory(rootLba, rootSize, '', 0);

    let systemCnfRaw = '';
    let bootExePath = '';
    let serial = 'PS1-DISC';
    let bootExeBytes: Uint8Array | null = null;

    const cnfEntry = this.fileIndex.get('SYSTEM.CNF');
    if (cnfEntry) {
      const cnfData = await this.readIsoFile(cnfEntry.lba, cnfEntry.size);
      systemCnfRaw = new TextDecoder('ascii').decode(cnfData).trim();
      const bootMatch = systemCnfRaw.match(/BOOT\s*=\s*cdrom:\\?([^\s;]+)/i);
      if (bootMatch && bootMatch[1]) {
        bootExePath = bootMatch[1].replace(/\\/g, '/').replace(/^\/+/, '').toUpperCase();
        const serialMatch = bootExePath.match(/([A-Z]{4}[_-]?\d{3}\.?\d{2})/);
        if (serialMatch) {
          serial = serialMatch[1];
        } else {
          serial = bootExePath.slice(0, 16);
        }
        const exeEntry = this.fileIndex.get(bootExePath);
        if (exeEntry) {
          bootExeBytes = await this.readIsoFile(exeEntry.lba, exeEntry.size);
        }
      }
    }

    if (!bootExeBytes) {
      for (const [key, entry] of this.fileIndex.entries()) {
        if (
          !entry.isDir &&
          (key.endsWith('.EXE') || /^(SLUS|SCUS|SLES|SCES|SLPS|SCPS|SLPM)/.test(key))
        ) {
          bootExePath = key;
          serial = key;
          bootExeBytes = await this.readIsoFile(entry.lba, entry.size);
          break;
        }
      }
    }

    const hdr = this.extractExeHeader(bootExeBytes);
    const recognizedTitle = lookupPs1TitleBySerial(serial, volumeLabel);

    return {
      info: {
        filename: this.file.name,
        fileSizeBytes: this.file.size,
        sectorSize: this.sectorSize,
        totalSectors,
        volumeLabel,
        bootExePath: bootExePath || 'SYSTEM.CNF',
        serial: recognizedTitle.serial,
        recognizedTitle,
        systemCnfRaw,
        isDirectExe: false,
        exeLoadedBytes: bootExeBytes?.length ?? 0,
        ...hdr,
        fileCount: this.fileIndex.size,
      },
      bootExeBytes,
    };
  }

  findFile(cdPath: string): IsoDirEntry | null {
    const clean = cdPath
      .replace(/^cdrom:/i, '')
      .replace(/\\/g, '/')
      .replace(/^\/+/, '')
      .split(';')[0]
      .toUpperCase();
    return this.fileIndex.get(clean) ?? null;
  }

  async readFileByPath(cdPath: string): Promise<Uint8Array | null> {
    const entry = this.findFile(cdPath);
    if (!entry || entry.isDir) return null;
    return this.readIsoFile(entry.lba, entry.size);
  }

  listRootFiles(limit = 16): IsoDirEntry[] {
    return Array.from(this.fileIndex.values()).slice(0, limit);
  }
}
