import { useEffect, useRef, useState } from 'react';
import { createIdlePadState, PSX_BTN, PsxPadState } from '../emulator/types';

const KEY_MAP: Record<string, number> = {
  ArrowUp: PSX_BTN.UP,
  KeyW: PSX_BTN.UP,
  ArrowDown: PSX_BTN.DOWN,
  KeyS: PSX_BTN.DOWN,
  ArrowLeft: PSX_BTN.LEFT,
  KeyA: PSX_BTN.LEFT,
  ArrowRight: PSX_BTN.RIGHT,
  KeyD: PSX_BTN.RIGHT,
  KeyX: PSX_BTN.CROSS,
  KeyK: PSX_BTN.CROSS,
  KeyZ: PSX_BTN.SQUARE,
  KeyJ: PSX_BTN.SQUARE,
  KeyC: PSX_BTN.CIRCLE,
  KeyL: PSX_BTN.CIRCLE,
  KeyV: PSX_BTN.TRIANGLE,
  KeyI: PSX_BTN.TRIANGLE,
  KeyQ: PSX_BTN.L1,
  KeyE: PSX_BTN.R1,
  Digit1: PSX_BTN.L2,
  Digit3: PSX_BTN.R2,
  Enter: PSX_BTN.START,
  ShiftRight: PSX_BTN.SELECT,
  ShiftLeft: PSX_BTN.SELECT,
};

function clampByte(n: number): number {
  return Math.max(0, Math.min(255, Math.round(n)));
}

function axisToByte(v: number | undefined, deadzone = 0.14): number {
  if (typeof v !== 'number' || Number.isNaN(v)) return 128;
  if (Math.abs(v) < deadzone) return 128;
  return clampByte(128 + v * 127);
}

function readBluetoothGamepad(): {
  mask: number;
  lx: number;
  ly: number;
  rx: number;
  ry: number;
  name: string | null;
} {
  if (typeof navigator === 'undefined' || typeof navigator.getGamepads !== 'function') {
    return { mask: 0, lx: 128, ly: 128, rx: 128, ry: 128, name: null };
  }

  const pads = Array.from(navigator.getGamepads() ?? []).filter(
    (g): g is Gamepad => Boolean(g && g.connected),
  );
  if (pads.length === 0) {
    return { mask: 0, lx: 128, ly: 128, rx: 128, ry: 128, name: null };
  }

  let mask = 0;
  let lx = 128;
  let ly = 128;
  let rx = 128;
  let ry = 128;

  for (const gp of pads) {
    const btns = gp.buttons;
    const isPressed = (idx: number) =>
      Boolean(btns[idx] && (btns[idx].pressed || btns[idx].value > 0.35));

    if (gp.mapping === 'standard') {
      if (isPressed(0)) mask |= PSX_BTN.CROSS;
      if (isPressed(1)) mask |= PSX_BTN.CIRCLE;
      if (isPressed(2)) mask |= PSX_BTN.SQUARE;
      if (isPressed(3)) mask |= PSX_BTN.TRIANGLE;
      if (isPressed(4)) mask |= PSX_BTN.L1;
      if (isPressed(5)) mask |= PSX_BTN.R1;
      if (isPressed(6)) mask |= PSX_BTN.L2;
      if (isPressed(7)) mask |= PSX_BTN.R2;
      if (isPressed(8)) mask |= PSX_BTN.SELECT;
      if (isPressed(9)) mask |= PSX_BTN.START;
      if (isPressed(10)) mask |= PSX_BTN.L3;
      if (isPressed(11)) mask |= PSX_BTN.R3;
      if (isPressed(12)) mask |= PSX_BTN.UP;
      if (isPressed(13)) mask |= PSX_BTN.DOWN;
      if (isPressed(14)) mask |= PSX_BTN.LEFT;
      if (isPressed(15)) mask |= PSX_BTN.RIGHT;

      const glx = axisToByte(gp.axes[0]);
      const gly = axisToByte(gp.axes[1]);
      const grx = axisToByte(gp.axes[2]);
      const gry = axisToByte(gp.axes[3]);
      if (glx !== 128) lx = glx;
      if (gly !== 128) ly = gly;
      if (grx !== 128) rx = grx;
      if (gry !== 128) ry = gry;
    } else {
      // Universal fallback for generic Android Bluetooth HID gamepads (Ipega, Mocute, etc.)
      if (isPressed(0)) mask |= PSX_BTN.CROSS;
      if (isPressed(1)) mask |= PSX_BTN.CIRCLE;
      if (isPressed(2)) mask |= PSX_BTN.CIRCLE;
      if (isPressed(3)) mask |= PSX_BTN.SQUARE;
      if (isPressed(4)) mask |= PSX_BTN.TRIANGLE;
      if (isPressed(6)) mask |= PSX_BTN.L1;
      if (isPressed(7)) mask |= PSX_BTN.R1;
      if (isPressed(8)) mask |= PSX_BTN.L2;
      if (isPressed(9)) mask |= PSX_BTN.R2;
      if (isPressed(10)) mask |= PSX_BTN.SELECT;
      if (isPressed(11)) mask |= PSX_BTN.START;
      if (isPressed(12)) mask |= PSX_BTN.UP;
      if (isPressed(13)) mask |= PSX_BTN.L3;
      if (isPressed(14)) mask |= PSX_BTN.R3;

      const glx = axisToByte(gp.axes[0]);
      const gly = axisToByte(gp.axes[1]);
      const grx = axisToByte(gp.axes[2]);
      const gry = axisToByte(gp.axes.length >= 6 ? gp.axes[5] : gp.axes[3]);
      if (glx !== 128) lx = glx;
      if (gly !== 128) ly = gly;
      if (grx !== 128) rx = grx;
      if (gry !== 128) ry = gry;

      if (typeof gp.axes[6] === 'number' && Math.abs(gp.axes[6]) > 0.5) {
        mask |= gp.axes[6] < 0 ? PSX_BTN.LEFT : PSX_BTN.RIGHT;
      }
      if (typeof gp.axes[7] === 'number' && Math.abs(gp.axes[7]) > 0.5) {
        mask |= gp.axes[7] < 0 ? PSX_BTN.UP : PSX_BTN.DOWN;
      }
      if (typeof gp.axes[9] === 'number' && gp.axes[9] >= -1 && gp.axes[9] <= 1.2) {
        const hat = gp.axes[9];
        if (hat < -0.8) mask |= PSX_BTN.UP;
        else if (hat < -0.6) mask |= PSX_BTN.UP | PSX_BTN.RIGHT;
        else if (hat < -0.3) mask |= PSX_BTN.RIGHT;
        else if (hat < -0.05) mask |= PSX_BTN.RIGHT | PSX_BTN.DOWN;
        else if (hat < 0.25) mask |= PSX_BTN.DOWN;
        else if (hat < 0.55) mask |= PSX_BTN.DOWN | PSX_BTN.LEFT;
        else if (hat < 0.85) mask |= PSX_BTN.LEFT;
        else if (hat <= 1.05) mask |= PSX_BTN.LEFT | PSX_BTN.UP;
      }
    }
  }

  return {
    mask,
    lx,
    ly,
    rx,
    ry,
    name: pads[0].id.replace(/\s*\(.*?\)\s*/g, '').trim() || 'Controle Bluetooth',
  };
}

/**
 * Background hook that keeps Bluetooth Gamepads and keyboard bindings active
 * without rendering any static/example controller panel on screen.
 */
export function useHardwareGamepad(
  disabled: boolean,
  onChange: (state: PsxPadState) => void,
): string | null {
  const [btName, setBtName] = useState<string | null>(null);
  const keyMaskRef = useRef<number>(0);
  const lastEmittedRef = useRef<PsxPadState>(createIdlePadState());

  useEffect(() => {
    if (disabled) {
      keyMaskRef.current = 0;
      const idle = createIdlePadState();
      const prev = lastEmittedRef.current;
      if (
        prev.buttons !== idle.buttons ||
        prev.lx !== idle.lx ||
        prev.ly !== idle.ly ||
        prev.rx !== idle.rx ||
        prev.ry !== idle.ry
      ) {
        lastEmittedRef.current = idle;
        onChange(idle);
      }
      return;
    }

    const emit = (bt: ReturnType<typeof readBluetoothGamepad>) => {
      const combinedMask = keyMaskRef.current | bt.mask;
      const nextButtons = (~combinedMask) & 0xffff;
      const prev = lastEmittedRef.current;
      if (
        prev.buttons === nextButtons &&
        prev.lx === bt.lx &&
        prev.ly === bt.ly &&
        prev.rx === bt.rx &&
        prev.ry === bt.ry
      ) {
        return;
      }
      const nextState: PsxPadState = {
        buttons: nextButtons,
        lx: bt.lx,
        ly: bt.ly,
        rx: bt.rx,
        ry: bt.ry,
      };
      lastEmittedRef.current = nextState;
      onChange(nextState);
    };

    const onKeyDown = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement | null;
      if (
        target &&
        (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA' || target.tagName === 'SELECT')
      ) {
        return;
      }
      const bit = KEY_MAP[e.code];
      if (bit !== undefined) {
        e.preventDefault();
        if ((keyMaskRef.current & bit) === 0) {
          keyMaskRef.current |= bit;
          emit(readBluetoothGamepad());
        }
      }
    };

    const onKeyUp = (e: KeyboardEvent) => {
      const bit = KEY_MAP[e.code];
      if (bit !== undefined) {
        keyMaskRef.current &= ~bit;
        emit(readBluetoothGamepad());
      }
    };

    const onBlur = () => {
      keyMaskRef.current = 0;
      emit(readBluetoothGamepad());
    };

    window.addEventListener('keydown', onKeyDown);
    window.addEventListener('keyup', onKeyUp);
    window.addEventListener('blur', onBlur);

    let rafId = 0;
    const poll = () => {
      const bt = readBluetoothGamepad();
      setBtName((prev) => (prev === bt.name ? prev : bt.name));
      emit(bt);
      rafId = requestAnimationFrame(poll);
    };
    rafId = requestAnimationFrame(poll);

    return () => {
      cancelAnimationFrame(rafId);
      window.removeEventListener('keydown', onKeyDown);
      window.removeEventListener('keyup', onKeyUp);
      window.removeEventListener('blur', onBlur);
    };
  }, [disabled, onChange]);

  return btName;
}
