import { initializeApp } from 'firebase/app';
import { getAuth, User } from 'firebase/auth';
import {
  collection,
  deleteDoc,
  doc,
  getDoc,
  getDocFromServer,
  getFirestore,
  onSnapshot,
  query,
  serverTimestamp,
  setDoc,
  Timestamp,
  Unsubscribe,
  updateDoc,
  where,
} from 'firebase/firestore';
import firebaseConfig from '../../firebase-applet-config.json';

const app = initializeApp(firebaseConfig);
export const db = getFirestore(app, firebaseConfig.firestoreDatabaseId);
export const auth = getAuth(app);

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  };
}

export function handleFirestoreError(
  error: unknown,
  operationType: OperationType,
  path: string | null,
): never {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo:
        auth.currentUser?.providerData?.map((provider) => ({
          providerId: provider.providerId,
          email: provider.email,
        })) || [],
    },
    operationType,
    path,
  };
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

async function testConnection(): Promise<void> {
  try {
    await getDocFromServer(doc(db, 'test', 'connection'));
  } catch (error) {
    if (error instanceof Error && error.message.includes('the client is offline')) {
      console.error('Please check your Firebase configuration.');
    }
  }
}
testConnection();

export interface NetPlayRoomDoc {
  roomCode: string;
  hostUid: string;
  hostName: string;
  gameId: string;
  gameTitle: string;
  isoFilename: string;
  status: 'waiting' | 'approved' | 'playing' | 'closed';
  p2Uid: string;
  p2Name: string;
  p2AccessStatus: 'none' | 'pending' | 'approved' | 'denied';
  p2CanSelectCharacter: boolean;
  p1Character: string;
  p2Character: string;
  biosMode: 'HLE_NO_BIOS';
  createdAt?: Timestamp;
  updatedAt?: Timestamp;
}

export interface SaveSlotDoc {
  id: string;
  uid: string;
  gameId: string;
  gameTitle: string;
  slotIndex: number;
  label: string;
  memoryCardData: string;
  updatedAt?: Timestamp;
}

function clampString(val: string, maxLen: number, fallback = ''): string {
  const trimmed = (val || fallback).trim();
  return trimmed.slice(0, maxLen);
}

function sanitizeId(val: string, maxLen = 64): string {
  const clean = val.replace(/[^a-zA-Z0-9_\-]/g, '_').slice(0, maxLen);
  return clean || 'item';
}

export function generateRoomCode(): string {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let code = '';
  for (let i = 0; i < 6; i++) {
    code += chars[Math.floor(Math.random() * chars.length)];
  }
  return code;
}

export async function ensureVerifiedUserProfile(
  user: User,
  preferredDisplayName?: string,
): Promise<boolean> {
  const tokenResult = await user.getIdTokenResult(true);
  if (!user.emailVerified || tokenResult.claims.email_verified !== true) {
    return false;
  }
  // Allow Firestore's internal onIdTokenChanged listener to propagate the refreshed JWT
  await new Promise((resolve) => setTimeout(resolve, 250));

  const userPath = `users/${user.uid}`;
  const profilePath = `playerProfiles/${user.uid}`;
  const displayName = clampString(
    preferredDisplayName || user.displayName || user.email?.split('@')[0] || 'Jogador',
    40,
    'Jogador',
  );
  const safeName = displayName.length >= 2 ? displayName : 'Jogador PS1';
  const authProvider = user.providerData.some((p) => p.providerId === 'google.com')
    ? 'google'
    : 'password';
  const tokenEmail =
    typeof tokenResult.claims.email === 'string'
      ? tokenResult.claims.email
      : user.email || '';

  const userRef = doc(db, 'users', user.uid);
  let userExists = false;
  try {
    const snap = await getDoc(userRef);
    userExists = snap.exists();
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, userPath);
  }

  try {
    if (!userExists) {
      await setDoc(userRef, {
        uid: user.uid,
        displayName: safeName,
        email: clampString(tokenEmail, 120),
        authProvider,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
    } else {
      await updateDoc(userRef, {
        displayName: safeName,
        updatedAt: serverTimestamp(),
      });
    }
  } catch (error) {
    handleFirestoreError(error, userExists ? OperationType.UPDATE : OperationType.CREATE, userPath);
  }

  const profRef = doc(db, 'playerProfiles', user.uid);
  let profExists = false;
  try {
    const profSnap = await getDoc(profRef);
    profExists = profSnap.exists();
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, profilePath);
  }

  try {
    if (!profExists) {
      await setDoc(profRef, {
        uid: user.uid,
        gamerTag: safeName,
        preferredMode: 'netplay',
        updatedAt: serverTimestamp(),
      });
    } else {
      await updateDoc(profRef, {
        gamerTag: safeName,
        updatedAt: serverTimestamp(),
      });
    }
  } catch (error) {
    handleFirestoreError(
      error,
      profExists ? OperationType.UPDATE : OperationType.CREATE,
      profilePath,
    );
  }

  return true;
}

export async function createNetPlayRoom(params: {
  hostUid: string;
  hostName: string;
  gameId: string;
  gameTitle: string;
  isoFilename: string;
  p1Character: string;
  p2Character: string;
}): Promise<string> {
  const roomCode = generateRoomCode();
  const path = `rooms/${roomCode}`;
  try {
    await setDoc(doc(db, 'rooms', roomCode), {
      roomCode,
      hostUid: params.hostUid,
      hostName: clampString(params.hostName, 40, 'Host P1'),
      gameId: sanitizeId(params.gameId, 64),
      gameTitle: clampString(params.gameTitle, 80, 'ISO PS1'),
      isoFilename: clampString(params.isoFilename, 120, ''),
      status: 'waiting',
      p2Uid: '',
      p2Name: '',
      p2AccessStatus: 'none',
      p2CanSelectCharacter: true,
      p1Character: clampString(params.p1Character, 40, 'Player 1'),
      p2Character: clampString(params.p2Character, 40, 'Player 2'),
      biosMode: 'HLE_NO_BIOS',
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });
    return roomCode;
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
}

export async function getNetPlayRoom(roomCode: string): Promise<NetPlayRoomDoc | null> {
  const code = roomCode.toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 6);
  if (code.length !== 6) return null;
  const path = `rooms/${code}`;
  try {
    const snap = await getDoc(doc(db, 'rooms', code));
    return snap.exists() ? (snap.data() as NetPlayRoomDoc) : null;
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, path);
  }
}

export function subscribeNetPlayRoom(
  roomCode: string,
  onRoom: (room: NetPlayRoomDoc | null) => void,
  onError?: (err: Error) => void,
): Unsubscribe {
  const code = roomCode.toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 6);
  const path = `rooms/${code}`;
  return onSnapshot(
    doc(db, 'rooms', code),
    (snap) => {
      onRoom(snap.exists() ? (snap.data() as NetPlayRoomDoc) : null);
    },
    (error) => {
      try {
        handleFirestoreError(error, OperationType.GET, path);
      } catch (wrapped) {
        if (onError && wrapped instanceof Error) onError(wrapped);
      }
    },
  );
}

export function subscribeUserRooms(
  uid: string,
  onRooms: (rooms: NetPlayRoomDoc[]) => void,
): Unsubscribe {
  const path = 'rooms';
  const q = query(collection(db, 'rooms'), where('hostUid', '==', uid));
  return onSnapshot(
    q,
    (snap) => {
      const list = snap.docs
        .map((d) => d.data() as NetPlayRoomDoc)
        .filter((r) => r.status !== 'closed');
      onRooms(list);
    },
    (error) => {
      handleFirestoreError(error, OperationType.LIST, path);
    },
  );
}

export async function hostUpdateRoom(
  roomCode: string,
  patch: Partial<
    Pick<
      NetPlayRoomDoc,
      | 'gameId'
      | 'gameTitle'
      | 'isoFilename'
      | 'status'
      | 'p2Uid'
      | 'p2Name'
      | 'p2AccessStatus'
      | 'p2CanSelectCharacter'
      | 'p1Character'
      | 'p2Character'
    >
  >,
): Promise<void> {
  const code = roomCode.toUpperCase().slice(0, 6);
  const path = `rooms/${code}`;
  const cleanPatch: Record<string, unknown> = { updatedAt: serverTimestamp() };
  if (patch.gameId !== undefined) cleanPatch.gameId = sanitizeId(patch.gameId, 64);
  if (patch.gameTitle !== undefined) cleanPatch.gameTitle = clampString(patch.gameTitle, 80, 'PS1');
  if (patch.isoFilename !== undefined) cleanPatch.isoFilename = clampString(patch.isoFilename, 120, '');
  if (patch.status !== undefined) cleanPatch.status = patch.status;
  if (patch.p2Uid !== undefined) cleanPatch.p2Uid = clampString(patch.p2Uid, 128, '');
  if (patch.p2Name !== undefined) cleanPatch.p2Name = clampString(patch.p2Name, 40, '');
  if (patch.p2AccessStatus !== undefined) cleanPatch.p2AccessStatus = patch.p2AccessStatus;
  if (patch.p2CanSelectCharacter !== undefined) {
    cleanPatch.p2CanSelectCharacter = Boolean(patch.p2CanSelectCharacter);
  }
  if (patch.p1Character !== undefined) cleanPatch.p1Character = clampString(patch.p1Character, 40, 'P1');
  if (patch.p2Character !== undefined) cleanPatch.p2Character = clampString(patch.p2Character, 40, 'P2');

  try {
    await updateDoc(doc(db, 'rooms', code), cleanPatch);
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export async function guestRequestJoinRoom(
  roomCode: string,
  p2Uid: string,
  p2Name: string,
): Promise<void> {
  const code = roomCode.toUpperCase().slice(0, 6);
  const path = `rooms/${code}`;
  try {
    await updateDoc(doc(db, 'rooms', code), {
      p2Uid,
      p2Name: clampString(p2Name, 40, 'Convidado P2'),
      p2AccessStatus: 'pending',
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export async function guestUpdateCharacter(roomCode: string, p2Character: string): Promise<void> {
  const code = roomCode.toUpperCase().slice(0, 6);
  const path = `rooms/${code}`;
  try {
    await updateDoc(doc(db, 'rooms', code), {
      p2Character: clampString(p2Character, 40, 'P2'),
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export async function guestLeaveRoom(roomCode: string): Promise<void> {
  const code = roomCode.toUpperCase().slice(0, 6);
  const path = `rooms/${code}`;
  try {
    await updateDoc(doc(db, 'rooms', code), {
      p2Uid: '',
      p2Name: '',
      p2AccessStatus: 'none',
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export async function saveMemoryCardSlot(params: {
  uid: string;
  gameId: string;
  gameTitle: string;
  slotIndex: number;
  label: string;
  memoryCardData: string;
}): Promise<void> {
  const cleanGameId = sanitizeId(params.gameId, 64);
  const slot = Math.min(8, Math.max(1, Math.floor(params.slotIndex)));
  const saveId = sanitizeId(`${params.uid}_${cleanGameId}_slot${slot}`, 128);
  const path = `saveStates/${saveId}`;

  try {
    const ref = doc(db, 'saveStates', saveId);
    const existing = await getDoc(ref);
    if (existing.exists()) {
      await updateDoc(ref, {
        gameTitle: clampString(params.gameTitle, 80, 'PS1 Game'),
        label: clampString(params.label, 60, `Slot ${slot}`),
        memoryCardData: clampString(params.memoryCardData, 16384, 'EMPTY'),
        updatedAt: serverTimestamp(),
      });
    } else {
      await setDoc(ref, {
        uid: params.uid,
        gameId: cleanGameId,
        gameTitle: clampString(params.gameTitle, 80, 'PS1 Game'),
        slotIndex: slot,
        label: clampString(params.label, 60, `Slot ${slot}`),
        memoryCardData: clampString(params.memoryCardData, 16384, 'EMPTY'),
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
    }
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

export function subscribeUserSaveSlots(
  uid: string,
  onSaves: (saves: SaveSlotDoc[]) => void,
): Unsubscribe {
  const path = 'saveStates';
  const q = query(collection(db, 'saveStates'), where('uid', '==', uid));
  return onSnapshot(
    q,
    (snap) => {
      const saves = snap.docs.map((d) => ({
        id: d.id,
        ...(d.data() as Omit<SaveSlotDoc, 'id'>),
      }));
      onSaves(saves);
    },
    (error) => {
      handleFirestoreError(error, OperationType.LIST, path);
    },
  );
}

export async function deleteSaveSlot(saveId: string): Promise<void> {
  const path = `saveStates/${saveId}`;
  try {
    await deleteDoc(doc(db, 'saveStates', saveId));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
  }
}
