import React, { useCallback, useEffect, useRef, useState } from 'react';
import { RotateCcw, Settings2, SlidersHorizontal, X } from 'lucide-react';
import { createIdlePadState, PSX_BTN, PsxPadState } from '../emulator/types';

export type DpadMode = 'dpad' | 'analog' | 'both';
export type ActionPreset = 'ps1' | 'jp' | 'custom';
export type PadScale = 'sm' | 'md' | 'lg';
export type FaceActionKey = 'TRIANGLE' | 'SQUARE' | 'CIRCLE' | 'CROSS';

export interface VirtualGamepadConfig {
  dpadMode: DpadMode;
  actionPreset: ActionPreset;
  faceMapping: {
    top: FaceActionKey;
    left: FaceActionKey;
    right: FaceActionKey;
    bottom: FaceActionKey;
  };
  showShoulders: boolean;
  showStartSelect: boolean;
  showRightStick: boolean;
  showL3R3: boolean;
  opacity: number;
  scale: PadScale;
}

const STORAGE_KEY = 'psx_virtual_gamepad_config_v2';

const DEFAULT_CONFIG: VirtualGamepadConfig = {
  dpadMode: 'both',
  actionPreset: 'ps1',
  faceMapping: {
    top: 'TRIANGLE',
    left: 'SQUARE',
    right: 'CIRCLE',
    bottom: 'CROSS',
  },
  showShoulders: true,
  showStartSelect: true,
  showRightStick: true,
  showL3R3: false,
  opacity: 75,
  scale: 'md',
};

const FACE_META: Record<
  FaceActionKey,
  { bit: number; symbol: string; label: string; idleCls: string; activeCls: string }
> = {
  TRIANGLE: {
    bit: PSX_BTN.TRIANGLE,
    symbol: '△',
    label: 'Triângulo',
    idleCls: 'text-emerald-400 border-emerald-400/35 bg-[#0F1115]/85',
    activeCls: 'bg-emerald-500 text-white border-emerald-200 scale-95',
  },
  SQUARE: {
    bit: PSX_BTN.SQUARE,
    symbol: '□',
    label: 'Quadrado',
    idleCls: 'text-pink-400 border-pink-400/35 bg-[#0F1115]/85',
    activeCls: 'bg-pink-500 text-white border-pink-200 scale-95',
  },
  CIRCLE: {
    bit: PSX_BTN.CIRCLE,
    symbol: '○',
    label: 'Círculo',
    idleCls: 'text-red-400 border-red-400/35 bg-[#0F1115]/85',
    activeCls: 'bg-red-500 text-white border-red-200 scale-95',
  },
  CROSS: {
    bit: PSX_BTN.CROSS,
    symbol: '×',
    label: 'Cruz',
    idleCls: 'text-blue-400 border-blue-400/35 bg-[#0F1115]/85',
    activeCls: 'bg-blue-500 text-white border-blue-200 scale-95',
  },
};

const FACE_KEYS: FaceActionKey[] = ['TRIANGLE', 'SQUARE', 'CIRCLE', 'CROSS'];

function loadSavedConfig(): VirtualGamepadConfig {
  if (typeof window === 'undefined') return DEFAULT_CONFIG;
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) return DEFAULT_CONFIG;
    const parsed = JSON.parse(raw) as Partial<VirtualGamepadConfig>;
    return {
      ...DEFAULT_CONFIG,
      ...parsed,
      faceMapping: {
        ...DEFAULT_CONFIG.faceMapping,
        ...(parsed.faceMapping || {}),
      },
      opacity:
        typeof parsed.opacity === 'number'
          ? Math.max(25, Math.min(95, parsed.opacity))
          : DEFAULT_CONFIG.opacity,
    };
  } catch {
    return DEFAULT_CONFIG;
  }
}

function clampByte(n: number): number {
  return Math.max(0, Math.min(255, Math.round(n)));
}

function stopSurfaceEvent(e: React.SyntheticEvent): void {
  e.stopPropagation();
}

function blockAndPrevent(e: React.SyntheticEvent): void {
  e.preventDefault();
  e.stopPropagation();
}

interface OverlayStickProps {
  label: string;
  sizePx: number;
  disabled: boolean;
  valueX: number;
  valueY: number;
  onInteract?: () => void;
  onMove: (x: number, y: number) => void;
}

const OverlayStick: React.FC<OverlayStickProps> = ({
  label,
  sizePx,
  disabled,
  valueX,
  valueY,
  onInteract,
  onMove,
}) => {
  const baseRef = useRef<HTMLDivElement | null>(null);
  const pointerIdRef = useRef<number | null>(null);

  const updatePos = (clientX: number, clientY: number) => {
    const el = baseRef.current;
    if (!el || disabled) return;
    const rect = el.getBoundingClientRect();
    const cx = rect.left + rect.width / 2;
    const cy = rect.top + rect.height / 2;
    const maxRadius = rect.width * 0.36;
    let dx = clientX - cx;
    let dy = clientY - cy;
    const dist = Math.hypot(dx, dy);
    if (dist > maxRadius && dist > 0) {
      dx = (dx / dist) * maxRadius;
      dy = (dy / dist) * maxRadius;
    }
    const nx = maxRadius > 0 ? dx / maxRadius : 0;
    const ny = maxRadius > 0 ? dy / maxRadius : 0;
    onMove(clampByte(128 + nx * 127), clampByte(128 + ny * 127));
  };

  const travelPx = sizePx * 0.24;
  const knobX = ((valueX - 128) / 127) * travelPx;
  const knobY = ((valueY - 128) / 127) * travelPx;
  const knobSize = Math.round(sizePx * 0.44);

  return (
    <div
      ref={baseRef}
      style={{ width: sizePx, height: sizePx }}
      onPointerDown={(e) => {
        blockAndPrevent(e);
        if (disabled) return;
        onInteract?.();
        pointerIdRef.current = e.pointerId;
        try {
          e.currentTarget.setPointerCapture(e.pointerId);
        } catch {
          // Ignore pointer capture errors
        }
        updatePos(e.clientX, e.clientY);
      }}
      onPointerMove={(e) => {
        blockAndPrevent(e);
        if (pointerIdRef.current !== e.pointerId || disabled) return;
        updatePos(e.clientX, e.clientY);
      }}
      onPointerUp={(e) => {
        blockAndPrevent(e);
        if (pointerIdRef.current !== e.pointerId) return;
        pointerIdRef.current = null;
        onMove(128, 128);
      }}
      onPointerCancel={(e) => {
        blockAndPrevent(e);
        if (pointerIdRef.current !== e.pointerId) return;
        pointerIdRef.current = null;
        onMove(128, 128);
      }}
      onTouchStart={stopSurfaceEvent}
      onTouchMove={stopSurfaceEvent}
      onTouchEnd={stopSurfaceEvent}
      onMouseDown={stopSurfaceEvent}
      onClick={stopSurfaceEvent}
      onContextMenu={blockAndPrevent}
      aria-label={label}
      className="relative rounded-full bg-[#0F1115]/75 border border-white/20 backdrop-blur-[2px] flex items-center justify-center touch-none select-none pointer-events-auto shadow-lg"
    >
      <div
        style={{ width: Math.round(sizePx * 0.56), height: Math.round(sizePx * 0.56) }}
        className="rounded-full border border-white/10 pointer-events-none"
      />
      <div
        style={{
          width: knobSize,
          height: knobSize,
          transform: `translate(${knobX}px, ${knobY}px)`,
        }}
        className="absolute rounded-full bg-slate-200/25 border border-white/45 shadow pointer-events-none"
      />
      <span className="absolute bottom-1 text-[9px] font-mono text-slate-300/80 pointer-events-none">
        {label}
      </span>
    </div>
  );
};

export interface VirtualGamepadProps {
  visible: boolean;
  disabled?: boolean;
  onChange: (state: PsxPadState) => void;
  onUserInteract?: () => void;
  onToggleVisibility?: () => void;
}

export const VirtualGamepad: React.FC<VirtualGamepadProps> = ({
  visible,
  disabled = false,
  onChange,
  onUserInteract,
  onToggleVisibility,
}) => {
  const [config, setConfig] = useState<VirtualGamepadConfig>(loadSavedConfig);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [pressedMask, setPressedMask] = useState(0);
  const [axesUi, setAxesUi] = useState({ lx: 128, ly: 128, rx: 128, ry: 128 });

  // Active button bits per pointerId (supports true multi-touch + D-Pad slide)
  const pointerBitsRef = useRef<Map<number, number>>(new Map());
  const dpadPointerIdRef = useRef<number | null>(null);
  const dpadMaskRef = useRef<number>(0);
  const dpadSurfaceRef = useRef<HTMLDivElement | null>(null);
  const axesRef = useRef({ lx: 128, ly: 128, rx: 128, ry: 128 });
  const lastEmittedRef = useRef<PsxPadState>(createIdlePadState());

  useEffect(() => {
    try {
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(config));
    } catch {
      // Ignore storage quota errors
    }
  }, [config]);

  const flushState = useCallback(() => {
    let combined = 0;
    if (!disabled && visible) {
      combined |= dpadMaskRef.current;
      pointerBitsRef.current.forEach((bit) => {
        combined |= bit;
      });
    }

    const lx = !disabled && visible ? axesRef.current.lx : 128;
    const ly = !disabled && visible ? axesRef.current.ly : 128;
    const rx = !disabled && visible ? axesRef.current.rx : 128;
    const ry = !disabled && visible ? axesRef.current.ry : 128;

    const nextButtons = (~combined) & 0xffff;
    const prev = lastEmittedRef.current;

    if (
      prev.buttons === nextButtons &&
      prev.lx === lx &&
      prev.ly === ly &&
      prev.rx === rx &&
      prev.ry === ry
    ) {
      return;
    }

    const nextState: PsxPadState = { buttons: nextButtons, lx, ly, rx, ry };
    lastEmittedRef.current = nextState;
    setPressedMask(combined);
    setAxesUi({ lx, ly, rx, ry });
    onChange(nextState);
  }, [disabled, visible, onChange]);

  const resetAllInputs = useCallback(() => {
    pointerBitsRef.current.clear();
    dpadPointerIdRef.current = null;
    dpadMaskRef.current = 0;
    axesRef.current = { lx: 128, ly: 128, rx: 128, ry: 128 };
    flushState();
  }, [flushState]);

  useEffect(() => {
    if (disabled || !visible) {
      resetAllInputs();
    }
  }, [disabled, visible, resetAllInputs]);

  useEffect(() => {
    const onBlur = () => resetAllInputs();
    window.addEventListener('blur', onBlur);
    return () => window.removeEventListener('blur', onBlur);
  }, [resetAllInputs]);

  const computeDpadBitsFromPoint = (clientX: number, clientY: number): number => {
    const el = dpadSurfaceRef.current;
    if (!el) return 0;
    const rect = el.getBoundingClientRect();
    const cx = rect.left + rect.width / 2;
    const cy = rect.top + rect.height / 2;
    const dx = clientX - cx;
    const dy = clientY - cy;
    const dist = Math.hypot(dx, dy);
    const deadzone = rect.width * 0.1;
    if (dist < deadzone) return 0;

    // 8-way sector calculation (allows smooth diagonal movement)
    const angle = (Math.atan2(dy, dx) * 180) / Math.PI; // -180 .. 180 (0 = Right, 90 = Down)
    let mask = 0;
    if (angle >= -157.5 && angle <= -22.5) mask |= PSX_BTN.UP;
    if (angle >= 22.5 && angle <= 157.5) mask |= PSX_BTN.DOWN;
    if (angle >= -67.5 && angle <= 67.5) mask |= PSX_BTN.RIGHT;
    if (angle >= 112.5 || angle <= -112.5) mask |= PSX_BTN.LEFT;
    return mask;
  };

  const bindTouchButton = (bit: number) => ({
    onPointerDown: (e: React.PointerEvent<HTMLElement>) => {
      blockAndPrevent(e);
      if (disabled) return;
      onUserInteract?.();
      try {
        e.currentTarget.setPointerCapture(e.pointerId);
      } catch {
        // Ignore capture failures
      }
      pointerBitsRef.current.set(e.pointerId, bit);
      flushState();
    },
    onPointerUp: (e: React.PointerEvent<HTMLElement>) => {
      blockAndPrevent(e);
      pointerBitsRef.current.delete(e.pointerId);
      flushState();
    },
    onPointerCancel: (e: React.PointerEvent<HTMLElement>) => {
      blockAndPrevent(e);
      pointerBitsRef.current.delete(e.pointerId);
      flushState();
    },
    onTouchStart: stopSurfaceEvent,
    onTouchMove: stopSurfaceEvent,
    onTouchEnd: stopSurfaceEvent,
    onMouseDown: stopSurfaceEvent,
    onClick: stopSurfaceEvent,
    onContextMenu: blockAndPrevent,
  });

  if (!visible) return null;

  const isDown = (bit: number) => (pressedMask & bit) !== 0;
  const opacityStyle = { opacity: config.opacity / 100 };

  const dpadSize = config.scale === 'sm' ? 92 : config.scale === 'lg' ? 124 : 108;
  const actionWrapSize = config.scale === 'sm' ? 96 : config.scale === 'lg' ? 128 : 112;
  const faceBtnSize = config.scale === 'sm' ? 32 : config.scale === 'lg' ? 42 : 36;
  const stickSize = config.scale === 'sm' ? 76 : config.scale === 'lg' ? 98 : 88;
  const shoulderCls =
    config.scale === 'sm'
      ? 'px-2.5 py-1 text-[10px]'
      : config.scale === 'lg'
        ? 'px-3.5 py-1.5 text-xs'
        : 'px-3 py-1 text-[11px]';

  const topMeta = FACE_META[config.faceMapping.top];
  const leftMeta = FACE_META[config.faceMapping.left];
  const rightMeta = FACE_META[config.faceMapping.right];
  const bottomMeta = FACE_META[config.faceMapping.bottom];

  const applyPreset = (preset: ActionPreset) => {
    if (preset === 'ps1') {
      setConfig((prev) => ({
        ...prev,
        actionPreset: 'ps1',
        faceMapping: {
          top: 'TRIANGLE',
          left: 'SQUARE',
          right: 'CIRCLE',
          bottom: 'CROSS',
        },
      }));
    } else if (preset === 'jp') {
      setConfig((prev) => ({
        ...prev,
        actionPreset: 'jp',
        faceMapping: {
          top: 'TRIANGLE',
          left: 'SQUARE',
          right: 'CROSS',
          bottom: 'CIRCLE',
        },
      }));
    } else {
      setConfig((prev) => ({ ...prev, actionPreset: 'custom' }));
    }
  };

  const cycleCustomFaceSlot = (slot: keyof VirtualGamepadConfig['faceMapping']) => {
    setConfig((prev) => {
      const idx = FACE_KEYS.indexOf(prev.faceMapping[slot]);
      const nextKey = FACE_KEYS[(idx + 1) % FACE_KEYS.length];
      return {
        ...prev,
        actionPreset: 'custom',
        faceMapping: {
          ...prev.faceMapping,
          [slot]: nextKey,
        },
      };
    });
  };

  return (
    <div
      onPointerDownCapture={stopSurfaceEvent}
      onTouchStartCapture={stopSurfaceEvent}
      onMouseDownCapture={stopSurfaceEvent}
      onContextMenuCapture={blockAndPrevent}
      className="absolute inset-0 z-30 pointer-events-none select-none overflow-hidden"
    >
      {/* Top Bar: Shoulders (optional) + Overlay Config Trigger */}
      <div className="absolute top-2 inset-x-2 flex items-start justify-between gap-2">
        {/* Left Shoulders */}
        <div style={opacityStyle} className="flex items-center gap-1.5 pointer-events-none">
          {config.showShoulders && (
            <>
              <button
                type="button"
                disabled={disabled}
                {...bindTouchButton(PSX_BTN.L2)}
                className={`${shoulderCls} rounded-md border font-mono font-semibold backdrop-blur-[2px] touch-none pointer-events-auto transition-transform ${
                  isDown(PSX_BTN.L2)
                    ? 'bg-blue-600 border-blue-300 text-white scale-95'
                    : 'bg-[#0F1115]/80 border-white/20 text-slate-200'
                }`}
              >
                L2
              </button>
              <button
                type="button"
                disabled={disabled}
                {...bindTouchButton(PSX_BTN.L1)}
                className={`${shoulderCls} rounded-md border font-mono font-semibold backdrop-blur-[2px] touch-none pointer-events-auto transition-transform ${
                  isDown(PSX_BTN.L1)
                    ? 'bg-blue-600 border-blue-300 text-white scale-95'
                    : 'bg-[#0F1115]/80 border-white/20 text-slate-200'
                }`}
              >
                L1
              </button>
            </>
          )}
        </div>

        {/* Center Config & Hide Buttons */}
        <div className="flex items-center gap-1.5 pointer-events-auto">
          <button
            type="button"
            onPointerDown={(e) => {
              blockAndPrevent(e);
              onUserInteract?.();
              setSettingsOpen((o) => !o);
            }}
            onClick={stopSurfaceEvent}
            onContextMenu={blockAndPrevent}
            title="Configurar Gamepad Virtual"
            className="inline-flex items-center gap-1 px-2 py-1 rounded-md bg-[#0F1115]/80 hover:bg-[#1C212B]/90 border border-white/20 text-[10px] font-medium text-slate-200 backdrop-blur-[2px] touch-none"
          >
            <Settings2 className="w-3 h-3 text-blue-400" />
            <span className="hidden sm:inline">Configurar</span>
          </button>

          {onToggleVisibility && (
            <button
              type="button"
              onPointerDown={(e) => {
                blockAndPrevent(e);
                setSettingsOpen(false);
                onToggleVisibility();
              }}
              onClick={stopSurfaceEvent}
              onContextMenu={blockAndPrevent}
              title="Ocultar Gamepad Virtual"
              className="p-1 rounded-md bg-[#0F1115]/80 hover:bg-[#1C212B]/90 border border-white/20 text-slate-300 backdrop-blur-[2px] touch-none"
              aria-label="Ocultar Gamepad Virtual"
            >
              <X className="w-3 h-3" />
            </button>
          )}
        </div>

        {/* Right Shoulders */}
        <div style={opacityStyle} className="flex items-center gap-1.5 pointer-events-none">
          {config.showShoulders && (
            <>
              <button
                type="button"
                disabled={disabled}
                {...bindTouchButton(PSX_BTN.R1)}
                className={`${shoulderCls} rounded-md border font-mono font-semibold backdrop-blur-[2px] touch-none pointer-events-auto transition-transform ${
                  isDown(PSX_BTN.R1)
                    ? 'bg-blue-600 border-blue-300 text-white scale-95'
                    : 'bg-[#0F1115]/80 border-white/20 text-slate-200'
                }`}
              >
                R1
              </button>
              <button
                type="button"
                disabled={disabled}
                {...bindTouchButton(PSX_BTN.R2)}
                className={`${shoulderCls} rounded-md border font-mono font-semibold backdrop-blur-[2px] touch-none pointer-events-auto transition-transform ${
                  isDown(PSX_BTN.R2)
                    ? 'bg-blue-600 border-blue-300 text-white scale-95'
                    : 'bg-[#0F1115]/80 border-white/20 text-slate-200'
                }`}
              >
                R2
              </button>
            </>
          )}
        </div>
      </div>

      {/* Bottom Controls: Left (D-Pad / Analog L) | Center (SELECT/START/L3/R3) | Right (Action Buttons / Analog R) */}
      <div
        style={opacityStyle}
        className="absolute bottom-2.5 inset-x-2.5 flex items-end justify-between gap-2 pointer-events-none"
      >
        {/* Left Cluster: D-Pad and/or Left Analog Stick */}
        <div className="flex items-end gap-2 pointer-events-none">
          {(config.dpadMode === 'dpad' || config.dpadMode === 'both') && (
            <div
              ref={dpadSurfaceRef}
              style={{ width: dpadSize, height: dpadSize }}
              onPointerDown={(e) => {
                blockAndPrevent(e);
                if (disabled) return;
                onUserInteract?.();
                dpadPointerIdRef.current = e.pointerId;
                try {
                  e.currentTarget.setPointerCapture(e.pointerId);
                } catch {
                  // Ignore capture failures
                }
                dpadMaskRef.current = computeDpadBitsFromPoint(e.clientX, e.clientY);
                flushState();
              }}
              onPointerMove={(e) => {
                blockAndPrevent(e);
                if (dpadPointerIdRef.current !== e.pointerId || disabled) return;
                dpadMaskRef.current = computeDpadBitsFromPoint(e.clientX, e.clientY);
                flushState();
              }}
              onPointerUp={(e) => {
                blockAndPrevent(e);
                if (dpadPointerIdRef.current !== e.pointerId) return;
                dpadPointerIdRef.current = null;
                dpadMaskRef.current = 0;
                flushState();
              }}
              onPointerCancel={(e) => {
                blockAndPrevent(e);
                if (dpadPointerIdRef.current !== e.pointerId) return;
                dpadPointerIdRef.current = null;
                dpadMaskRef.current = 0;
                flushState();
              }}
              onTouchStart={stopSurfaceEvent}
              onTouchMove={stopSurfaceEvent}
              onTouchEnd={stopSurfaceEvent}
              onMouseDown={stopSurfaceEvent}
              onClick={stopSurfaceEvent}
              onContextMenu={blockAndPrevent}
              role="group"
              aria-label="D-Pad Virtual"
              className="relative rounded-full bg-[#0F1115]/45 border border-white/15 backdrop-blur-[2px] grid grid-cols-3 grid-rows-3 p-1 touch-none pointer-events-auto"
            >
              <div />
              <div
                className={`rounded-t-md border flex items-center justify-center text-xs font-bold pointer-events-none transition-colors ${
                  isDown(PSX_BTN.UP)
                    ? 'bg-white text-slate-900 border-white'
                    : 'bg-[#1B202A]/85 text-slate-200 border-white/20'
                }`}
              >
                ▲
              </div>
              <div />
              <div
                className={`rounded-l-md border flex items-center justify-center text-xs font-bold pointer-events-none transition-colors ${
                  isDown(PSX_BTN.LEFT)
                    ? 'bg-white text-slate-900 border-white'
                    : 'bg-[#1B202A]/85 text-slate-200 border-white/20'
                }`}
              >
                ◀
              </div>
              <div className="bg-[#12151C]/90 border border-white/10 flex items-center justify-center pointer-events-none">
                <div className="w-2.5 h-2.5 rounded-full bg-white/15" />
              </div>
              <div
                className={`rounded-r-md border flex items-center justify-center text-xs font-bold pointer-events-none transition-colors ${
                  isDown(PSX_BTN.RIGHT)
                    ? 'bg-white text-slate-900 border-white'
                    : 'bg-[#1B202A]/85 text-slate-200 border-white/20'
                }`}
              >
                ▶
              </div>
              <div />
              <div
                className={`rounded-b-md border flex items-center justify-center text-xs font-bold pointer-events-none transition-colors ${
                  isDown(PSX_BTN.DOWN)
                    ? 'bg-white text-slate-900 border-white'
                    : 'bg-[#1B202A]/85 text-slate-200 border-white/20'
                }`}
              >
                ▼
              </div>
              <div />
            </div>
          )}

          {(config.dpadMode === 'analog' || config.dpadMode === 'both') && (
            <OverlayStick
              label="L"
              sizePx={config.dpadMode === 'both' ? Math.round(stickSize * 0.88) : stickSize}
              disabled={disabled}
              valueX={axesUi.lx}
              valueY={axesUi.ly}
              onInteract={onUserInteract}
              onMove={(x, y) => {
                axesRef.current.lx = x;
                axesRef.current.ly = y;
                flushState();
              }}
            />
          )}
        </div>

        {/* Center Cluster: SELECT / START / L3 / R3 */}
        <div className="flex flex-col items-center gap-1.5 pb-0.5 pointer-events-none">
          {config.showL3R3 && (
            <div className="flex items-center gap-1.5">
              <button
                type="button"
                disabled={disabled}
                {...bindTouchButton(PSX_BTN.L3)}
                className={`px-2 py-0.5 text-[10px] font-mono rounded border backdrop-blur-[2px] touch-none pointer-events-auto ${
                  isDown(PSX_BTN.L3)
                    ? 'bg-blue-600 border-blue-300 text-white'
                    : 'bg-[#0F1115]/80 border-white/20 text-slate-200'
                }`}
              >
                L3
              </button>
              <button
                type="button"
                disabled={disabled}
                {...bindTouchButton(PSX_BTN.R3)}
                className={`px-2 py-0.5 text-[10px] font-mono rounded border backdrop-blur-[2px] touch-none pointer-events-auto ${
                  isDown(PSX_BTN.R3)
                    ? 'bg-blue-600 border-blue-300 text-white'
                    : 'bg-[#0F1115]/80 border-white/20 text-slate-200'
                }`}
              >
                R3
              </button>
            </div>
          )}

          {config.showStartSelect && (
            <div className="flex items-center gap-1.5">
              <button
                type="button"
                disabled={disabled}
                {...bindTouchButton(PSX_BTN.SELECT)}
                className={`px-2.5 py-1 text-[10px] font-mono font-semibold rounded border backdrop-blur-[2px] touch-none pointer-events-auto transition-transform ${
                  isDown(PSX_BTN.SELECT)
                    ? 'bg-white text-slate-900 border-white scale-95'
                    : 'bg-[#0F1115]/80 text-slate-200 border-white/20'
                }`}
              >
                SELECT
              </button>
              <button
                type="button"
                disabled={disabled}
                {...bindTouchButton(PSX_BTN.START)}
                className={`px-2.5 py-1 text-[10px] font-mono font-semibold rounded border backdrop-blur-[2px] touch-none pointer-events-auto transition-transform ${
                  isDown(PSX_BTN.START)
                    ? 'bg-white text-slate-900 border-white scale-95'
                    : 'bg-[#0F1115]/80 text-slate-200 border-white/20'
                }`}
              >
                START
              </button>
            </div>
          )}
        </div>

        {/* Right Cluster: Right Analog Stick (optional) + Configurable Action Buttons */}
        <div className="flex items-end gap-2 pointer-events-none">
          {config.showRightStick && (
            <OverlayStick
              label="R"
              sizePx={Math.round(stickSize * 0.88)}
              disabled={disabled}
              valueX={axesUi.rx}
              valueY={axesUi.ry}
              onInteract={onUserInteract}
              onMove={(x, y) => {
                axesRef.current.rx = x;
                axesRef.current.ry = y;
                flushState();
              }}
            />
          )}

          <div
            style={{ width: actionWrapSize, height: actionWrapSize }}
            className="relative pointer-events-none"
          >
            {/* Top Face Button */}
            <button
              type="button"
              disabled={disabled}
              aria-label={topMeta.label}
              style={{ width: faceBtnSize, height: faceBtnSize }}
              {...bindTouchButton(topMeta.bit)}
              className={`absolute top-0 left-1/2 -translate-x-1/2 rounded-full border backdrop-blur-[2px] font-bold text-sm flex items-center justify-center touch-none pointer-events-auto transition-transform ${
                isDown(topMeta.bit) ? topMeta.activeCls : topMeta.idleCls
              }`}
            >
              {topMeta.symbol}
            </button>

            {/* Left Face Button */}
            <button
              type="button"
              disabled={disabled}
              aria-label={leftMeta.label}
              style={{ width: faceBtnSize, height: faceBtnSize }}
              {...bindTouchButton(leftMeta.bit)}
              className={`absolute left-0 top-1/2 -translate-y-1/2 rounded-full border backdrop-blur-[2px] font-bold text-sm flex items-center justify-center touch-none pointer-events-auto transition-transform ${
                isDown(leftMeta.bit) ? leftMeta.activeCls : leftMeta.idleCls
              }`}
            >
              {leftMeta.symbol}
            </button>

            {/* Right Face Button */}
            <button
              type="button"
              disabled={disabled}
              aria-label={rightMeta.label}
              style={{ width: faceBtnSize, height: faceBtnSize }}
              {...bindTouchButton(rightMeta.bit)}
              className={`absolute right-0 top-1/2 -translate-y-1/2 rounded-full border backdrop-blur-[2px] font-bold text-sm flex items-center justify-center touch-none pointer-events-auto transition-transform ${
                isDown(rightMeta.bit) ? rightMeta.activeCls : rightMeta.idleCls
              }`}
            >
              {rightMeta.symbol}
            </button>

            {/* Bottom Face Button */}
            <button
              type="button"
              disabled={disabled}
              aria-label={bottomMeta.label}
              style={{ width: faceBtnSize, height: faceBtnSize }}
              {...bindTouchButton(bottomMeta.bit)}
              className={`absolute bottom-0 left-1/2 -translate-x-1/2 rounded-full border backdrop-blur-[2px] font-bold text-sm flex items-center justify-center touch-none pointer-events-auto transition-transform ${
                isDown(bottomMeta.bit) ? bottomMeta.activeCls : bottomMeta.idleCls
              }`}
            >
              {bottomMeta.symbol}
            </button>
          </div>
        </div>
      </div>

      {/* Inline Overlay Config Panel (isolated from emulator DOM) */}
      {settingsOpen && (
        <div
          onPointerDown={stopSurfaceEvent}
          onTouchStart={stopSurfaceEvent}
          onMouseDown={stopSurfaceEvent}
          onClick={stopSurfaceEvent}
          onContextMenu={blockAndPrevent}
          className="absolute inset-x-3 top-10 bottom-3 z-40 bg-[#0F1115]/95 border border-[#2E3543] rounded-xl p-3.5 overflow-y-auto pointer-events-auto shadow-2xl space-y-3"
        >
          <div className="flex items-center justify-between border-b border-[#262B36] pb-2">
            <div className="flex items-center gap-2 text-xs font-semibold text-white">
              <SlidersHorizontal className="w-3.5 h-3.5 text-blue-400" />
              Configurar Gamepad Virtual
            </div>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={(e) => {
                  stopSurfaceEvent(e);
                  setConfig(DEFAULT_CONFIG);
                }}
                className="inline-flex items-center gap-1 px-2 py-1 rounded bg-[#1A1F29] hover:bg-[#232A38] border border-[#2E3543] text-[11px] text-slate-300"
              >
                <RotateCcw className="w-3 h-3" />
                Padrão
              </button>
              <button
                type="button"
                onClick={(e) => {
                  stopSurfaceEvent(e);
                  setSettingsOpen(false);
                }}
                className="px-2.5 py-1 rounded bg-blue-600 hover:bg-blue-500 text-[11px] font-medium text-white"
              >
                Concluir
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
            {/* D-Pad Config */}
            <div className="space-y-1.5 bg-[#151820] border border-[#262B36] rounded-lg p-2.5">
              <div className="font-medium text-slate-200">Direcional (D-Pad / Analógico)</div>
              <div className="grid grid-cols-3 gap-1.5">
                {(
                  [
                    ['dpad', 'D-Pad 8-vias'],
                    ['both', 'D-Pad + L'],
                    ['analog', 'Analógico L'],
                  ] as const
                ).map(([mode, label]) => (
                  <button
                    key={mode}
                    type="button"
                    onClick={(e) => {
                      stopSurfaceEvent(e);
                      setConfig((p) => ({ ...p, dpadMode: mode }));
                    }}
                    className={`px-2 py-1.5 rounded border text-[11px] font-medium transition-colors ${
                      config.dpadMode === mode
                        ? 'bg-blue-600 border-blue-400 text-white'
                        : 'bg-[#0F1115] border-[#262B36] text-slate-300 hover:bg-[#1E232D]'
                    }`}
                  >
                    {label}
                  </button>
                ))}
              </div>
            </div>

            {/* Size & Opacity */}
            <div className="space-y-2 bg-[#151820] border border-[#262B36] rounded-lg p-2.5">
              <div className="flex items-center justify-between">
                <span className="font-medium text-slate-200">Tamanho</span>
                <div className="flex items-center gap-1">
                  {(
                    [
                      ['sm', 'P'],
                      ['md', 'M'],
                      ['lg', 'G'],
                    ] as const
                  ).map(([sz, label]) => (
                    <button
                      key={sz}
                      type="button"
                      onClick={(e) => {
                        stopSurfaceEvent(e);
                        setConfig((p) => ({ ...p, scale: sz }));
                      }}
                      className={`px-2 py-0.5 rounded border text-[11px] font-mono ${
                        config.scale === sz
                          ? 'bg-blue-600 border-blue-400 text-white'
                          : 'bg-[#0F1115] border-[#262B36] text-slate-300'
                      }`}
                    >
                      {label}
                    </button>
                  ))}
                </div>
              </div>

              <label className="flex items-center justify-between gap-3">
                <span className="font-medium text-slate-200">
                  Opacidade ({config.opacity}%)
                </span>
                <input
                  type="range"
                  min={25}
                  max={95}
                  value={config.opacity}
                  onChange={(e) =>
                    setConfig((p) => ({ ...p, opacity: Number(e.target.value) }))
                  }
                  className="w-28 accent-blue-500"
                />
              </label>
            </div>

            {/* Action Buttons Preset & Mapping */}
            <div className="space-y-2 bg-[#151820] border border-[#262B36] rounded-lg p-2.5">
              <div className="font-medium text-slate-200">Botões de Ação</div>
              <div className="grid grid-cols-3 gap-1.5">
                {(
                  [
                    ['ps1', 'PS1 △□○×'],
                    ['jp', 'Trocar ○/×'],
                    ['custom', 'Personalizar'],
                  ] as const
                ).map(([preset, label]) => (
                  <button
                    key={preset}
                    type="button"
                    onClick={(e) => {
                      stopSurfaceEvent(e);
                      applyPreset(preset);
                    }}
                    className={`px-2 py-1.5 rounded border text-[11px] font-medium ${
                      config.actionPreset === preset
                        ? 'bg-blue-600 border-blue-400 text-white'
                        : 'bg-[#0F1115] border-[#262B36] text-slate-300 hover:bg-[#1E232D]'
                    }`}
                  >
                    {label}
                  </button>
                ))}
              </div>

              <div className="grid grid-cols-4 gap-1.5 pt-1">
                {(
                  [
                    ['top', 'Topo'],
                    ['left', 'Esq'],
                    ['right', 'Dir'],
                    ['bottom', 'Baixo'],
                  ] as const
                ).map(([slot, slotLabel]) => {
                  const meta = FACE_META[config.faceMapping[slot]];
                  return (
                    <button
                      key={slot}
                      type="button"
                      onClick={(e) => {
                        stopSurfaceEvent(e);
                        cycleCustomFaceSlot(slot);
                      }}
                      className="px-1.5 py-1 rounded bg-[#0F1115] border border-[#262B36] hover:border-blue-500 text-center"
                    >
                      <div className="text-[9px] text-slate-400">{slotLabel}</div>
                      <div className="text-sm font-bold text-white">{meta.symbol}</div>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Extra Toggles */}
            <div className="space-y-1.5 bg-[#151820] border border-[#262B36] rounded-lg p-2.5">
              <div className="font-medium text-slate-200 mb-1">Botões Extras na Tela</div>
              {(
                [
                  ['showShoulders', 'Ombros (L1 / L2 / R1 / R2)'],
                  ['showStartSelect', 'SELECT e START'],
                  ['showRightStick', 'Analógico Direito (R)'],
                  ['showL3R3', 'Botões L3 e R3'],
                ] as const
              ).map(([key, label]) => (
                <label
                  key={key}
                  className="flex items-center justify-between gap-2 text-[11px] text-slate-300 cursor-pointer"
                >
                  <span>{label}</span>
                  <input
                    type="checkbox"
                    checked={config[key]}
                    onChange={(e) =>
                      setConfig((p) => ({ ...p, [key]: e.target.checked }))
                    }
                    className="rounded border-slate-600 bg-slate-900 text-blue-600"
                  />
                </label>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
