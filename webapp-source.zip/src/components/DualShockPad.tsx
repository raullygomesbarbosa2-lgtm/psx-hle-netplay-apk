import React, { useCallback, useEffect, useRef, useState } from 'react';
import { Bluetooth, Gamepad2 } from 'lucide-react';
import { PSX_BTN, PsxPadState } from '../emulator/types';

interface DualShockPadProps {
  portLabel: string;
  disabled?: boolean;
  onChange: (state: PsxPadState) => void;
}

const KEY_MAP: Record<string, number> = {
  ArrowUp: PSX_BTN.UP,
  KeyW: PSX_BTN.UP,
  ArrowDown: PSX_BTN.DOWN,
  KeyS: PSX_BTN.DOWN,
  ArrowLeft: PSX_BTN.LEFT,
  KeyA: PSX_BTN.LEFT,
  ArrowRight: PSX_BTN.RIGHT,
  KeyD: PSX_BTN.RIGHT,
  KeyX: PSX_BTN.CROSS,
  KeyK: PSX_BTN.CROSS,
  KeyZ: PSX_BTN.SQUARE,
  KeyJ: PSX_BTN.SQUARE,
  KeyC: PSX_BTN.CIRCLE,
  KeyL: PSX_BTN.CIRCLE,
  KeyV: PSX_BTN.TRIANGLE,
  KeyI: PSX_BTN.TRIANGLE,
  KeyQ: PSX_BTN.L1,
  KeyE: PSX_BTN.R1,
  Digit1: PSX_BTN.L2,
  Digit3: PSX_BTN.R2,
  Enter: PSX_BTN.START,
  ShiftRight: PSX_BTN.SELECT,
  ShiftLeft: PSX_BTN.SELECT,
};

function clampByte(n: number): number {
  return Math.max(0, Math.min(255, Math.round(n)));
}

function axisToByte(v: number | undefined, deadzone = 0.14): number {
  if (typeof v !== 'number' || Number.isNaN(v)) return 128;
  if (Math.abs(v) < deadzone) return 128;
  return clampByte(128 + v * 127);
}

function readBluetoothGamepad(): {
  mask: number;
  lx: number;
  ly: number;
  rx: number;
  ry: number;
  name: string | null;
} {
  if (typeof navigator === 'undefined' || typeof navigator.getGamepads !== 'function') {
    return { mask: 0, lx: 128, ly: 128, rx: 128, ry: 128, name: null };
  }

  const pads = Array.from(navigator.getGamepads() ?? []).filter(
    (g): g is Gamepad => Boolean(g && g.connected),
  );
  if (pads.length === 0) {
    return { mask: 0, lx: 128, ly: 128, rx: 128, ry: 128, name: null };
  }

  let mask = 0;
  let lx = 128;
  let ly = 128;
  let rx = 128;
  let ry = 128;

  // Merge all connected Bluetooth controllers so any controller works immediately
  for (const gp of pads) {
    const btns = gp.buttons;
    const isPressed = (idx: number) =>
      Boolean(btns[idx] && (btns[idx].pressed || btns[idx].value > 0.35));

    if (gp.mapping === 'standard') {
      if (isPressed(0)) mask |= PSX_BTN.CROSS;
      if (isPressed(1)) mask |= PSX_BTN.CIRCLE;
      if (isPressed(2)) mask |= PSX_BTN.SQUARE;
      if (isPressed(3)) mask |= PSX_BTN.TRIANGLE;
      if (isPressed(4)) mask |= PSX_BTN.L1;
      if (isPressed(5)) mask |= PSX_BTN.R1;
      if (isPressed(6)) mask |= PSX_BTN.L2;
      if (isPressed(7)) mask |= PSX_BTN.R2;
      if (isPressed(8)) mask |= PSX_BTN.SELECT;
      if (isPressed(9)) mask |= PSX_BTN.START;
      if (isPressed(10)) mask |= PSX_BTN.L3;
      if (isPressed(11)) mask |= PSX_BTN.R3;
      if (isPressed(12)) mask |= PSX_BTN.UP;
      if (isPressed(13)) mask |= PSX_BTN.DOWN;
      if (isPressed(14)) mask |= PSX_BTN.LEFT;
      if (isPressed(15)) mask |= PSX_BTN.RIGHT;

      const glx = axisToByte(gp.axes[0]);
      const gly = axisToByte(gp.axes[1]);
      const grx = axisToByte(gp.axes[2]);
      const gry = axisToByte(gp.axes[3]);
      if (glx !== 128) lx = glx;
      if (gly !== 128) ly = gly;
      if (grx !== 128) rx = grx;
      if (gry !== 128) ry = gry;
    } else {
      // Non-standard / Generic Android Bluetooth HID (Ipega, Mocute, generic gamepads)
      if (isPressed(0)) mask |= PSX_BTN.CROSS; // A
      if (isPressed(1)) mask |= PSX_BTN.CIRCLE; // B
      if (isPressed(2) || isPressed(3)) {
        if (isPressed(3)) mask |= PSX_BTN.SQUARE; // X on some Android HIDs
        if (isPressed(4)) mask |= PSX_BTN.TRIANGLE;
        if (isPressed(2)) mask |= PSX_BTN.CIRCLE;
      }
      if (isPressed(3)) mask |= PSX_BTN.SQUARE;
      if (isPressed(4)) mask |= PSX_BTN.TRIANGLE;
      if (isPressed(6)) mask |= PSX_BTN.L1;
      if (isPressed(7)) mask |= PSX_BTN.R1;
      if (isPressed(8)) mask |= PSX_BTN.L2;
      if (isPressed(9)) mask |= PSX_BTN.R2;
      if (isPressed(10)) mask |= PSX_BTN.SELECT;
      if (isPressed(11)) mask |= PSX_BTN.START;
      if (isPressed(12)) mask |= PSX_BTN.UP;
      if (isPressed(13)) mask |= PSX_BTN.L3;
      if (isPressed(14)) mask |= PSX_BTN.R3;

      const glx = axisToByte(gp.axes[0]);
      const gly = axisToByte(gp.axes[1]);
      const grx = axisToByte(gp.axes[2]);
      const gry = axisToByte(gp.axes.length >= 6 ? gp.axes[5] : gp.axes[3]);
      if (glx !== 128) lx = glx;
      if (gly !== 128) ly = gly;
      if (grx !== 128) rx = grx;
      if (gry !== 128) ry = gry;

      // Android D-Pad HAT switch (often axes[6]/[7] or axes[9])
      if (typeof gp.axes[6] === 'number' && Math.abs(gp.axes[6]) > 0.5) {
        mask |= gp.axes[6] < 0 ? PSX_BTN.LEFT : PSX_BTN.RIGHT;
      }
      if (typeof gp.axes[7] === 'number' && Math.abs(gp.axes[7]) > 0.5) {
        mask |= gp.axes[7] < 0 ? PSX_BTN.UP : PSX_BTN.DOWN;
      }
      if (typeof gp.axes[9] === 'number' && gp.axes[9] >= -1 && gp.axes[9] <= 1.2) {
        // Android HID HAT encoding (-1.0 N, -0.43 E, +0.14 S, +0.71 W)
        const hat = gp.axes[9];
        if (hat < -0.8) mask |= PSX_BTN.UP;
        else if (hat < -0.6) mask |= PSX_BTN.UP | PSX_BTN.RIGHT;
        else if (hat < -0.3) mask |= PSX_BTN.RIGHT;
        else if (hat < -0.05) mask |= PSX_BTN.RIGHT | PSX_BTN.DOWN;
        else if (hat < 0.25) mask |= PSX_BTN.DOWN;
        else if (hat < 0.55) mask |= PSX_BTN.DOWN | PSX_BTN.LEFT;
        else if (hat < 0.85) mask |= PSX_BTN.LEFT;
        else if (hat <= 1.05) mask |= PSX_BTN.LEFT | PSX_BTN.UP;
      }
    }
  }

  return {
    mask,
    lx,
    ly,
    rx,
    ry,
    name: pads[0].id.replace(/\s*\(.*?\)\s*/g, '').trim() || 'Controle Bluetooth',
  };
}

interface AnalogStickProps {
  label: string;
  disabled?: boolean;
  valueX: number;
  valueY: number;
  onMove: (x: number, y: number) => void;
}

const AnalogStick: React.FC<AnalogStickProps> = ({
  label,
  disabled = false,
  valueX,
  valueY,
  onMove,
}) => {
  const padRef = useRef<HTMLDivElement | null>(null);
  const pointerIdRef = useRef<number | null>(null);

  const updateFromClient = (clientX: number, clientY: number) => {
    const el = padRef.current;
    if (!el || disabled) return;
    const rect = el.getBoundingClientRect();
    const cx = rect.left + rect.width / 2;
    const cy = rect.top + rect.height / 2;
    const maxRadius = rect.width * 0.36;
    let dx = clientX - cx;
    let dy = clientY - cy;
    const dist = Math.hypot(dx, dy);
    if (dist > maxRadius && dist > 0) {
      dx = (dx / dist) * maxRadius;
      dy = (dy / dist) * maxRadius;
    }
    const nx = dx / maxRadius;
    const ny = dy / maxRadius;
    onMove(clampByte(128 + nx * 127), clampByte(128 + ny * 127));
  };

  const knobX = ((valueX - 128) / 127) * 26;
  const knobY = ((valueY - 128) / 127) * 26;

  return (
    <div className="flex flex-col items-center gap-1.5">
      <div
        ref={padRef}
        onPointerDown={(e) => {
          if (disabled) return;
          e.preventDefault();
          pointerIdRef.current = e.pointerId;
          try {
            e.currentTarget.setPointerCapture(e.pointerId);
          } catch {
            // Ignore capture errors
          }
          updateFromClient(e.clientX, e.clientY);
        }}
        onPointerMove={(e) => {
          if (pointerIdRef.current !== e.pointerId || disabled) return;
          e.preventDefault();
          updateFromClient(e.clientX, e.clientY);
        }}
        onPointerUp={(e) => {
          if (pointerIdRef.current !== e.pointerId) return;
          pointerIdRef.current = null;
          onMove(128, 128);
        }}
        onPointerCancel={(e) => {
          if (pointerIdRef.current !== e.pointerId) return;
          pointerIdRef.current = null;
          onMove(128, 128);
        }}
        className={`relative w-[92px] h-[92px] rounded-full bg-[#0F1115] border border-[#2E3543] flex items-center justify-center touch-none select-none ${
          disabled ? 'opacity-50' : 'cursor-grab active:cursor-grabbing'
        }`}
        aria-label={label}
      >
        <div className="w-12 h-12 rounded-full border border-[#222834] pointer-events-none" />
        <div
          style={{ transform: `translate(${knobX}px, ${knobY}px)` }}
          className="absolute w-10 h-10 rounded-full bg-[#2A3140] border border-slate-500 shadow-md pointer-events-none transition-transform duration-75"
        />
      </div>
      <span className="text-[11px] font-mono text-slate-400">{label}</span>
    </div>
  );
};

export const DualShockPad: React.FC<DualShockPadProps> = ({
  portLabel,
  disabled = false,
  onChange,
}) => {
  const touchMaskRef = useRef<number>(0);
  const keyMaskRef = useRef<number>(0);
  const btMaskRef = useRef<number>(0);
  const touchAxesRef = useRef({ lx: 128, ly: 128, rx: 128, ry: 128 });
  const btAxesRef = useRef({ lx: 128, ly: 128, rx: 128, ry: 128 });
  const lastEmittedRef = useRef<PsxPadState>({ buttons: 0xffff, lx: 128, ly: 128, rx: 128, ry: 128 });

  const [pressedMask, setPressedMask] = useState<number>(0);
  const [axesUi, setAxesUi] = useState({ lx: 128, ly: 128, rx: 128, ry: 128 });
  const [btName, setBtName] = useState<string | null>(null);

  const flushPadState = useCallback(() => {
    const combinedMask = disabled
      ? 0
      : touchMaskRef.current | keyMaskRef.current | btMaskRef.current;

    const lx =
      touchAxesRef.current.lx !== 128 ? touchAxesRef.current.lx : btAxesRef.current.lx;
    const ly =
      touchAxesRef.current.ly !== 128 ? touchAxesRef.current.ly : btAxesRef.current.ly;
    const rx =
      touchAxesRef.current.rx !== 128 ? touchAxesRef.current.rx : btAxesRef.current.rx;
    const ry =
      touchAxesRef.current.ry !== 128 ? touchAxesRef.current.ry : btAxesRef.current.ry;

    const nextButtons = (~combinedMask) & 0xffff;
    const prev = lastEmittedRef.current;

    if (
      prev.buttons === nextButtons &&
      prev.lx === lx &&
      prev.ly === ly &&
      prev.rx === rx &&
      prev.ry === ry
    ) {
      return;
    }

    const nextState: PsxPadState = { buttons: nextButtons, lx, ly, rx, ry };
    lastEmittedRef.current = nextState;
    setPressedMask(combinedMask);
    setAxesUi({ lx, ly, rx, ry });
    onChange(nextState);
  }, [disabled, onChange]);

  const pressBtn = useCallback(
    (bit: number) => {
      if (disabled) return;
      touchMaskRef.current |= bit;
      flushPadState();
    },
    [disabled, flushPadState],
  );

  const releaseBtn = useCallback(
    (bit: number) => {
      touchMaskRef.current &= ~bit;
      flushPadState();
    },
    [flushPadState],
  );

  useEffect(() => {
    if (disabled) {
      touchMaskRef.current = 0;
      keyMaskRef.current = 0;
      btMaskRef.current = 0;
      touchAxesRef.current = { lx: 128, ly: 128, rx: 128, ry: 128 };
      btAxesRef.current = { lx: 128, ly: 128, rx: 128, ry: 128 };
      flushPadState();
      return;
    }

    const onKeyDown = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement | null;
      if (
        target &&
        (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA' || target.tagName === 'SELECT')
      ) {
        return;
      }
      const bit = KEY_MAP[e.code];
      if (bit !== undefined) {
        e.preventDefault();
        if ((keyMaskRef.current & bit) === 0) {
          keyMaskRef.current |= bit;
          flushPadState();
        }
      }
    };

    const onKeyUp = (e: KeyboardEvent) => {
      const bit = KEY_MAP[e.code];
      if (bit !== undefined) {
        keyMaskRef.current &= ~bit;
        flushPadState();
      }
    };

    const onBlur = () => {
      keyMaskRef.current = 0;
      touchMaskRef.current = 0;
      touchAxesRef.current = { lx: 128, ly: 128, rx: 128, ry: 128 };
      flushPadState();
    };

    window.addEventListener('keydown', onKeyDown);
    window.addEventListener('keyup', onKeyUp);
    window.addEventListener('blur', onBlur);

    // Bluetooth Gamepad polling loop (supports PS4, PS5, Xbox, Ipega, 8BitDo & generic Android HID pads)
    let rafId = 0;
    const pollGamepads = () => {
      const bt = readBluetoothGamepad();
      setBtName((prev) => (prev === bt.name ? prev : bt.name));
      btMaskRef.current = bt.mask;
      btAxesRef.current = { lx: bt.lx, ly: bt.ly, rx: bt.rx, ry: bt.ry };
      flushPadState();
      rafId = requestAnimationFrame(pollGamepads);
    };
    rafId = requestAnimationFrame(pollGamepads);

    return () => {
      cancelAnimationFrame(rafId);
      window.removeEventListener('keydown', onKeyDown);
      window.removeEventListener('keyup', onKeyUp);
      window.removeEventListener('blur', onBlur);
    };
  }, [disabled, flushPadState]);

  const isDown = (bit: number) => (pressedMask & bit) !== 0;

  const btnBind = (bit: number) => ({
    onPointerDown: (e: React.PointerEvent) => {
      e.preventDefault();
      pressBtn(bit);
    },
    onPointerUp: () => releaseBtn(bit),
    onPointerLeave: () => releaseBtn(bit),
    onPointerCancel: () => releaseBtn(bit),
  });

  return (
    <div className="bg-[#171A21] border border-[#262B36] rounded-xl p-4 select-none space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-[#262B36]">
        <div className="flex flex-wrap items-center gap-2 text-xs text-slate-300">
          <Gamepad2 className="w-4 h-4 text-blue-400" />
          <span className="font-semibold text-white">{portLabel}</span>
          <span aria-hidden="true" className="text-slate-600">·</span>
          <span className="text-slate-400">DualShock Analógico</span>
        </div>

        <div className="flex items-center gap-2 text-xs font-mono">
          <Bluetooth className={`w-3.5 h-3.5 ${btName ? 'text-emerald-400' : 'text-slate-500'}`} />
          <span className={btName ? 'text-emerald-400' : 'text-slate-400'}>
            {btName ? btName : 'Bluetooth: pronto (pareie e aperte um botão)'}
          </span>
        </div>
      </div>

      {/* Shoulder L2/L1 & R1/R2 */}
      <div className="flex items-center justify-between gap-4">
        <div className="flex items-center gap-2">
          <button
            type="button"
            disabled={disabled}
            {...btnBind(PSX_BTN.L2)}
            className={`min-w-[46px] h-9 px-3 text-xs font-mono font-medium rounded-md border transition-colors touch-none ${
              isDown(PSX_BTN.L2)
                ? 'bg-blue-600 border-blue-400 text-white'
                : 'bg-[#0F1115] border-[#2B313E] text-slate-300 hover:bg-[#1E232D]'
            }`}
          >
            L2
          </button>
          <button
            type="button"
            disabled={disabled}
            {...btnBind(PSX_BTN.L1)}
            className={`min-w-[46px] h-9 px-3 text-xs font-mono font-medium rounded-md border transition-colors touch-none ${
              isDown(PSX_BTN.L1)
                ? 'bg-blue-600 border-blue-400 text-white'
                : 'bg-[#0F1115] border-[#2B313E] text-slate-300 hover:bg-[#1E232D]'
            }`}
          >
            L1
          </button>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            disabled={disabled}
            {...btnBind(PSX_BTN.R1)}
            className={`min-w-[46px] h-9 px-3 text-xs font-mono font-medium rounded-md border transition-colors touch-none ${
              isDown(PSX_BTN.R1)
                ? 'bg-blue-600 border-blue-400 text-white'
                : 'bg-[#0F1115] border-[#2B313E] text-slate-300 hover:bg-[#1E232D]'
            }`}
          >
            R1
          </button>
          <button
            type="button"
            disabled={disabled}
            {...btnBind(PSX_BTN.R2)}
            className={`min-w-[46px] h-9 px-3 text-xs font-mono font-medium rounded-md border transition-colors touch-none ${
              isDown(PSX_BTN.R2)
                ? 'bg-blue-600 border-blue-400 text-white'
                : 'bg-[#0F1115] border-[#2B313E] text-slate-300 hover:bg-[#1E232D]'
            }`}
          >
            R2
          </button>
        </div>
      </div>

      {/* Main Pad Layout: D-Pad | Select/Start | Face Buttons */}
      <div className="flex flex-wrap items-center justify-between gap-4">
        {/* D-Pad */}
        <div className="grid grid-cols-3 gap-1.5 w-[134px]">
          <div />
          <button
            type="button"
            disabled={disabled}
            aria-label="Cima"
            {...btnBind(PSX_BTN.UP)}
            className={`h-11 rounded-md border text-sm font-bold transition-transform active:scale-95 touch-none ${
              isDown(PSX_BTN.UP)
                ? 'bg-slate-200 text-slate-900 border-white'
                : 'bg-[#20242E] text-slate-200 border-[#2E3543] hover:bg-[#2A303D]'
            }`}
          >
            ▲
          </button>
          <div />
          <button
            type="button"
            disabled={disabled}
            aria-label="Esquerda"
            {...btnBind(PSX_BTN.LEFT)}
            className={`h-11 rounded-md border text-sm font-bold transition-transform active:scale-95 touch-none ${
              isDown(PSX_BTN.LEFT)
                ? 'bg-slate-200 text-slate-900 border-white'
                : 'bg-[#20242E] text-slate-200 border-[#2E3543] hover:bg-[#2A303D]'
            }`}
          >
            ◀
          </button>
          <div className="h-11 rounded-md bg-[#12151B] border border-[#222732]" />
          <button
            type="button"
            disabled={disabled}
            aria-label="Direita"
            {...btnBind(PSX_BTN.RIGHT)}
            className={`h-11 rounded-md border text-sm font-bold transition-transform active:scale-95 touch-none ${
              isDown(PSX_BTN.RIGHT)
                ? 'bg-slate-200 text-slate-900 border-white'
                : 'bg-[#20242E] text-slate-200 border-[#2E3543] hover:bg-[#2A303D]'
            }`}
          >
            ▶
          </button>
          <div />
          <button
            type="button"
            disabled={disabled}
            aria-label="Baixo"
            {...btnBind(PSX_BTN.DOWN)}
            className={`h-11 rounded-md border text-sm font-bold transition-transform active:scale-95 touch-none ${
              isDown(PSX_BTN.DOWN)
                ? 'bg-slate-200 text-slate-900 border-white'
                : 'bg-[#20242E] text-slate-200 border-[#2E3543] hover:bg-[#2A303D]'
            }`}
          >
            ▼
          </button>
          <div />
        </div>

        {/* Select & Start */}
        <div className="flex items-center gap-2.5">
          <button
            type="button"
            disabled={disabled}
            {...btnBind(PSX_BTN.SELECT)}
            className={`px-3 py-2 text-xs font-mono rounded-md border transition-colors whitespace-nowrap shrink-0 touch-none ${
              isDown(PSX_BTN.SELECT)
                ? 'bg-slate-200 text-slate-900 border-white'
                : 'bg-[#0F1115] text-slate-300 border-[#2B313E] hover:bg-[#1E232D]'
            }`}
          >
            SELECT
          </button>
          <button
            type="button"
            disabled={disabled}
            {...btnBind(PSX_BTN.START)}
            className={`px-3 py-2 text-xs font-mono rounded-md border transition-colors whitespace-nowrap shrink-0 touch-none ${
              isDown(PSX_BTN.START)
                ? 'bg-slate-200 text-slate-900 border-white'
                : 'bg-[#0F1115] text-slate-300 border-[#2B313E] hover:bg-[#1E232D]'
            }`}
          >
            START
          </button>
        </div>

        {/* Action Face Buttons */}
        <div className="grid grid-cols-3 gap-1.5 w-[134px]">
          <div />
          <button
            type="button"
            disabled={disabled}
            aria-label="Triângulo"
            {...btnBind(PSX_BTN.TRIANGLE)}
            className={`h-11 rounded-full border text-sm font-bold transition-transform active:scale-95 touch-none ${
              isDown(PSX_BTN.TRIANGLE)
                ? 'bg-emerald-500 text-white border-emerald-300'
                : 'bg-[#20242E] text-emerald-400 border-[#2E3543] hover:bg-[#2A303D]'
            }`}
          >
            △
          </button>
          <div />
          <button
            type="button"
            disabled={disabled}
            aria-label="Quadrado"
            {...btnBind(PSX_BTN.SQUARE)}
            className={`h-11 rounded-full border text-sm font-bold transition-transform active:scale-95 touch-none ${
              isDown(PSX_BTN.SQUARE)
                ? 'bg-pink-500 text-white border-pink-300'
                : 'bg-[#20242E] text-pink-400 border-[#2E3543] hover:bg-[#2A303D]'
            }`}
          >
            □
          </button>
          <div />
          <button
            type="button"
            disabled={disabled}
            aria-label="Círculo"
            {...btnBind(PSX_BTN.CIRCLE)}
            className={`h-11 rounded-full border text-sm font-bold transition-transform active:scale-95 touch-none ${
              isDown(PSX_BTN.CIRCLE)
                ? 'bg-red-500 text-white border-red-300'
                : 'bg-[#20242E] text-red-400 border-[#2E3543] hover:bg-[#2A303D]'
            }`}
          >
            ○
          </button>
          <div />
          <button
            type="button"
            disabled={disabled}
            aria-label="Cruz"
            {...btnBind(PSX_BTN.CROSS)}
            className={`h-11 rounded-full border text-sm font-bold transition-transform active:scale-95 touch-none ${
              isDown(PSX_BTN.CROSS)
                ? 'bg-blue-500 text-white border-blue-300'
                : 'bg-[#20242E] text-blue-400 border-[#2E3543] hover:bg-[#2A303D]'
            }`}
          >
            ×
          </button>
          <div />
        </div>
      </div>

      {/* On-Screen Dual Analog Sticks + L3/R3 */}
      <div className="pt-3 border-t border-[#262B36] flex flex-wrap items-center justify-around gap-6">
        <div className="flex items-center gap-3">
          <AnalogStick
            label="Analógico L"
            disabled={disabled}
            valueX={axesUi.lx}
            valueY={axesUi.ly}
            onMove={(x, y) => {
              touchAxesRef.current.lx = x;
              touchAxesRef.current.ly = y;
              flushPadState();
            }}
          />
          <button
            type="button"
            disabled={disabled}
            {...btnBind(PSX_BTN.L3)}
            className={`px-2.5 py-1.5 text-xs font-mono rounded-md border touch-none ${
              isDown(PSX_BTN.L3)
                ? 'bg-blue-600 border-blue-400 text-white'
                : 'bg-[#0F1115] border-[#2B313E] text-slate-300'
            }`}
          >
            L3
          </button>
        </div>

        <div className="flex items-center gap-3">
          <button
            type="button"
            disabled={disabled}
            {...btnBind(PSX_BTN.R3)}
            className={`px-2.5 py-1.5 text-xs font-mono rounded-md border touch-none ${
              isDown(PSX_BTN.R3)
                ? 'bg-blue-600 border-blue-400 text-white'
                : 'bg-[#0F1115] border-[#2B313E] text-slate-300'
            }`}
          >
            R3
          </button>
          <AnalogStick
            label="Analógico R"
            disabled={disabled}
            valueX={axesUi.rx}
            valueY={axesUi.ry}
            onMove={(x, y) => {
              touchAxesRef.current.rx = x;
              touchAxesRef.current.ry = y;
              flushPadState();
            }}
          />
        </div>
      </div>
    </div>
  );
};
