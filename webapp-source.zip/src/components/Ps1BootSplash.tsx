import React from 'react';
import { IsoMountInfo } from '../emulator/types';

interface Ps1BootSplashProps {
  iso: IsoMountInfo;
  phase: 'sce' | 'ps';
}

export const Ps1BootSplash: React.FC<Ps1BootSplashProps> = ({ iso, phase }) => {
  if (phase === 'sce') {
    return (
      <div className="absolute inset-0 z-20 bg-[#F4F5F7] flex flex-col items-center justify-center p-6 select-none">
        <svg viewBox="0 0 120 120" className="w-24 h-24 mb-4" aria-hidden="true">
          <polygon points="60,8 112,60 60,112 8,60" fill="#F59E0B" />
          <polygon points="60,22 98,60 60,98 22,60" fill="#DC2626" />
          <polygon points="60,36 84,60 60,84 36,60" fill="#F59E0B" />
        </svg>
        <div className="font-display text-lg font-extrabold tracking-[0.22em] text-[#1E293B] uppercase">
          PSX HLE SYSTEM
        </div>
        <div className="mt-1 text-[11px] font-mono tracking-widest text-slate-500 uppercase">
          High-Level BIOS · {iso.recognizedTitle.region}
        </div>
      </div>
    );
  }

  return (
    <div className="absolute inset-0 z-20 bg-[#040508] flex flex-col items-center justify-center p-6 select-none">
      {/* Classic PlayStation stylized geometric emblem */}
      <svg viewBox="0 0 160 110" className="w-36 h-24 mb-4" aria-hidden="true">
        {/* Stylized 'P' stem & loop */}
        <path d="M68 14 L68 92 L82 96 L82 32 L98 37 C106 40 106 54 98 56 L86 53 L86 67 L102 71 C120 75 123 33 102 25 L68 14 Z" fill="#E11D48" />
        {/* Stylized 'S' sweep left/right */}
        <path d="M28 73 C14 78 16 90 34 94 L64 84 L64 73 L38 82 C31 84 30 79 37 77 L64 68 L64 57 L28 73 Z" fill="#2563EB" />
        <path d="M96 78 L128 67 C144 62 146 76 128 83 L92 95 L92 84 L120 75 C127 72 125 68 118 70 L96 78 Z" fill="#10B981" />
        <path d="M88 73 L118 63 L118 53 L88 63 Z" fill="#FACC15" />
      </svg>

      <div className="font-display text-xl sm:text-2xl font-bold tracking-[0.16em] text-white uppercase text-center">
        PlayStation
      </div>
      <div className="mt-2 text-xs font-mono text-slate-300 text-center max-w-sm truncate">
        {iso.recognizedTitle.title} · {iso.serial}
      </div>
      <div className="mt-1 text-[10px] font-mono tracking-widest text-slate-500 uppercase">
        Licensed HLE Mode · {iso.recognizedTitle.region}
      </div>
    </div>
  );
};
