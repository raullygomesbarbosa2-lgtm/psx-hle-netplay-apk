import React, { useEffect, useState } from 'react';
import { User } from 'firebase/auth';
import { Disc, Gamepad2, HardDrive, Trash2, Users } from 'lucide-react';
import { IsoMountInfo } from '../emulator/types';
import {
  deleteSaveSlot,
  SaveSlotDoc,
  subscribeUserSaveSlots,
} from '../firebase/firebaseClient';

interface GameCatalogViewProps {
  user: User;
  recentIsos: IsoMountInfo[];
  onGoSolo: () => void;
  onOpenNetPlay: () => void;
}

export const GameCatalogView: React.FC<GameCatalogViewProps> = ({
  user,
  recentIsos,
  onGoSolo,
  onOpenNetPlay,
}) => {
  const [saves, setSaves] = useState<SaveSlotDoc[]>([]);

  useEffect(() => {
    const unsub = subscribeUserSaveSlots(user.uid, setSaves);
    return () => unsub();
  }, [user.uid]);

  return (
    <div className="max-w-6xl mx-auto px-6 py-8 space-y-8">
      <div className="space-y-1">
        <h2 className="font-display text-2xl font-bold text-white">
          Discos Montados e Memory Card
        </h2>
        <p className="text-sm text-slate-400">
          Nenhum jogo de exemplo é exibido. Os títulos reconhecidos a partir das suas ISOs (.iso, .bin, .img, .chd, .pbp, .zip, .7z, .exe) e seus saves do Memory Card aparecem aqui.
        </p>
      </div>

      {/* Mounted / Recognized ISOs */}
      <div className="bg-[#171A21] border border-[#262B36] rounded-xl p-6 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <Disc className="w-4 h-4 text-blue-400" />
            <h3 className="font-display text-lg font-semibold text-white">
              ISOs Reconhecidas na Sessão
            </h3>
          </div>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onGoSolo}
              className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium bg-blue-600 hover:bg-blue-500 text-white rounded-lg transition-colors whitespace-nowrap shrink-0"
            >
              <Gamepad2 className="w-3.5 h-3.5" />
              Abrir Leitor Solo
            </button>
            <button
              type="button"
              onClick={onOpenNetPlay}
              className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium bg-[#20242E] hover:bg-[#2A303D] text-slate-200 border border-[#2E3543] rounded-lg transition-colors whitespace-nowrap shrink-0"
            >
              <Users className="w-3.5 h-3.5" />
              Ir para NetPlay
            </button>
          </div>
        </div>

        {recentIsos.length === 0 ? (
          <p className="text-sm text-slate-400">
            Nenhuma ISO carregada nesta sessão. Vá em <span className="text-white font-medium">Solo</span> ou{' '}
            <span className="text-white font-medium">NetPlay</span> para selecionar um arquivo `.iso`, `.bin`, `.img`, `.chd`, `.pbp`, `.zip` ou `.exe` baixado no seu aparelho.
          </p>
        ) : (
          <div className="divide-y divide-[#262B36]">
            {recentIsos.map((iso) => (
              <div
                key={`${iso.serial}-${iso.filename}`}
                className="py-3.5 flex flex-wrap items-center justify-between gap-4 text-sm"
              >
                <div className="space-y-0.5">
                  <div className="font-semibold text-white">{iso.recognizedTitle.title}</div>
                  <div className="text-xs text-slate-400 font-mono">
                    {iso.serial} · {iso.recognizedTitle.region} · {iso.recognizedTitle.genre} ·{' '}
                    {(iso.fileSizeBytes / (1024 * 1024)).toFixed(1)} MB · {iso.bootExePath}
                  </div>
                </div>
                <span className="text-xs font-mono text-emerald-400">{iso.filename}</span>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Saved Memory Card Blocks */}
      <div className="bg-[#171A21] border border-[#262B36] rounded-xl p-6 space-y-4">
        <div className="flex items-center gap-2">
          <HardDrive className="w-4 h-4 text-blue-400" />
          <h3 className="font-display text-lg font-semibold text-white">
            Memory Card Virtual na Nuvem
          </h3>
        </div>

        {saves.length === 0 ? (
          <p className="text-sm text-slate-400">
            Nenhum save gravado até o momento. Carregue uma ISO no modo Solo e clique em "Salvar Slot 1".
          </p>
        ) : (
          <div className="divide-y divide-[#262B36]">
            {saves.map((s) => (
              <div
                key={s.id}
                className="py-3 flex flex-wrap items-center justify-between gap-4 text-sm"
              >
                <div>
                  <div className="font-medium text-white">{s.label}</div>
                  <div className="text-xs text-slate-400 font-mono">
                    {s.gameTitle} · Slot {s.slotIndex}
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => deleteSaveSlot(s.id)}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs text-red-300 hover:text-red-200 bg-[#0F1115] border border-[#262B36] rounded-md"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  Remover
                </button>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
