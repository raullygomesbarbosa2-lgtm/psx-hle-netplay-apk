import React, { useState } from 'react';
import { Code2, Download } from 'lucide-react';

const MAIN_ACTIVITY_SNIPPET = `package com.psxhle.netplay

import android.net.Uri
import android.os.Bundle
import android.view.SurfaceView
import android.widget.Button
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import com.psxhle.netplay.core.PsxHleSurfaceController

/**
 * Activity nativa Android SDK (ZERO WebView).
 * Abre ISOs/ROMs baixadas pelo navegador direto da pasta Downloads via SAF (OpenDocument)
 * e renderiza no SurfaceView via ANativeWindow C++.
 */
class MainActivity : ComponentActivity() {

    private lateinit var surfaceController: PsxHleSurfaceController
    private lateinit var surfaceView: SurfaceView

    private val openRomLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            surfaceController.mountIsoAnySize(uri)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        surfaceView = SurfaceView(this)
        surfaceController = PsxHleSurfaceController(this)
        surfaceController.attachToSurfaceView(surfaceView)

        setContentView(surfaceView)

        // Abre o seletor nativo do Android (Downloads / Armazenamento Interno) sem WebView
        openRomLauncher.launch(arrayOf("*/*"))
    }
}`;

const KOTLIN_ENGINE_SNIPPET = `package com.psxhle.netplay.core

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.view.Surface
import android.view.SurfaceHolder
import android.view.SurfaceView

/**
 * Motor PS1 HLE nativo em Android SDK (Zero WebView / Zero BIOS externa).
 * Renderiza direto via SurfaceView (ANativeWindow) e AudioTrack PCM 44.1kHz.
 */
class PsxHleSurfaceController(private val context: Context) : SurfaceHolder.Callback {

    external fun nativeInitHle(biosMode: String): Long
    external fun nativeAttachSurface(handle: Long, surface: Surface)
    external fun nativeMountIsoFd(handle: Long, fd: Int, fileSizeBytes: Long): Boolean
    external fun nativeSetPadState(handle: Long, port: Int, buttonsMask: Int)
    external fun nativeStepFrame(handle: Long): ByteArray
    external fun nativeDestroy(handle: Long)

    private var engineHandle: Long = 0L
    private var isoPfd: ParcelFileDescriptor? = null

    fun attachToSurfaceView(surfaceView: SurfaceView) {
        surfaceView.holder.addCallback(this)
    }

    fun mountIsoAnySize(uri: Uri): Boolean {
        isoPfd?.close()
        isoPfd = context.contentResolver.openFileDescriptor(uri, "r") ?: return false
        val fd = isoPfd!!.fd
        val size = isoPfd!!.statSize
        return nativeMountIsoFd(engineHandle, fd, size)
    }

    override fun surfaceCreated(holder: SurfaceHolder) {
        engineHandle = nativeInitHle("HLE_NO_BIOS")
        nativeAttachSurface(engineHandle, holder.surface)
    }

    override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {}

    override fun surfaceDestroyed(holder: SurfaceHolder) {
        nativeDestroy(engineHandle)
        isoPfd?.close()
    }

    companion object {
        init { System.loadLibrary("psx_hle_native") }
    }
}`;

const CPP_JNI_SNIPPET = `#include <jni.h>
#include <android/native_window_jni.h>
#include <unistd.h>
#include <cstdint>
#include <vector>

struct PsxHleCore {
    ANativeWindow* window = nullptr;
    int isoFd = -1;
    int64_t isoBytes = 0;
    uint16_t pad1 = 0xFFFF;
    uint16_t pad2 = 0xFFFF;
    uint32_t vram[1024 * 512]{};

    // Streaming pread64() por LBA: lê ISOs de 700MB ou 4GB+ direto do FileDescriptor do Android
    bool readIsoSector(uint32_t lba, uint8_t* out2048, uint32_t sectorSize, uint32_t dataOff) {
        if (isoFd < 0) return false;
        off64_t offset = static_cast<off64_t>(lba) * sectorSize + dataOff;
        return pread64(isoFd, out2048, 2048, offset) == 2048;
    }
};

extern "C" JNIEXPORT jlong JNICALL
Java_com_psxhle_netplay_core_PsxHleSurfaceController_nativeInitHle(JNIEnv*, jobject, jstring) {
    return reinterpret_cast<jlong>(new PsxHleCore());
}

extern "C" JNIEXPORT void JNICALL
Java_com_psxhle_netplay_core_PsxHleSurfaceController_nativeAttachSurface(
        JNIEnv* env, jobject, jlong handle, jobject surface) {
    auto* core = reinterpret_cast<PsxHleCore*>(handle);
    if (core->window) ANativeWindow_release(core->window);
    core->window = ANativeWindow_fromSurface(env, surface);
    ANativeWindow_setBuffersGeometry(core->window, 320, 240, WINDOW_FORMAT_RGBA_8888);
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_psxhle_netplay_core_PsxHleSurfaceController_nativeMountIsoFd(
        JNIEnv*, jobject, jlong handle, jint fd, jlong sizeBytes) {
    auto* core = reinterpret_cast<PsxHleCore*>(handle);
    core->isoFd = dup(fd);
    core->isoBytes = sizeBytes;
    return core->isoFd >= 0 ? JNI_TRUE : JNI_FALSE;
}`;

const CMAKE_SNIPPET = `cmake_minimum_required(VERSION 3.22.1)
project("psx_hle_native")

add_library(psx_hle_native SHARED psx_hle_jni.cpp)

find_library(android-lib android)
find_library(log-lib log)

target_link_libraries(psx_hle_native \${android-lib} \${log-lib})`;

export const AndroidHleSdkView: React.FC = () => {
  const [tab, setTab] = useState<'activity' | 'kotlin' | 'cpp' | 'cmake'>('activity');

  const downloadBundle = () => {
    const bundle = [
      '=== MainActivity.kt (Seletor de ROMs Downloads + SurfaceView sem WebView) ===',
      MAIN_ACTIVITY_SNIPPET,
      '',
      '=== PsxHleSurfaceController.kt ===',
      KOTLIN_ENGINE_SNIPPET,
      '',
      '=== psx_hle_jni.cpp ===',
      CPP_JNI_SNIPPET,
      '',
      '=== CMakeLists.txt ===',
      CMAKE_SNIPPET,
    ].join('\n');
    const blob = new Blob([bundle], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'psx-hle-android-sdk.txt';
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
  };

  const activeSnippet =
    tab === 'activity'
      ? MAIN_ACTIVITY_SNIPPET
      : tab === 'kotlin'
        ? KOTLIN_ENGINE_SNIPPET
        : tab === 'cpp'
          ? CPP_JNI_SNIPPET
          : CMAKE_SNIPPET;

  return (
    <div className="max-w-5xl mx-auto px-6 py-8 space-y-6">
      <div className="bg-[#171A21] border border-[#262B36] rounded-xl p-6 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="space-y-1">
            <h2 className="font-display text-2xl font-bold text-white">
              SDK Nativo Android HLE (Sem WebView / Sem BIOS)
            </h2>
            <p className="text-sm text-slate-400">
              O ambiente do AI Studio executa aplicativos Web em navegador (Canvas + WebAssembly + WebAudio, sem WebView/iframe). Para gerar um APK nativo sem navegador no Android Studio, baixe os fontes Kotlin + NDK C++ abaixo com seletor SAF para ROMs baixadas na pasta Downloads.
            </p>
          </div>
          <button
            type="button"
            onClick={downloadBundle}
            className="inline-flex items-center gap-2 px-4 py-2.5 text-sm font-medium bg-blue-600 hover:bg-blue-500 text-white rounded-lg transition-colors whitespace-nowrap shrink-0"
          >
            <Download className="w-4 h-4" />
            Baixar Pacote SDK Android
          </button>
        </div>

        <div className="flex flex-wrap items-center gap-1 p-1 bg-[#0F1115] border border-[#262B36] rounded-lg w-fit">
          <button
            type="button"
            onClick={() => setTab('activity')}
            className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
              tab === 'activity' ? 'bg-[#232834] text-white' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            MainActivity.kt
          </button>
          <button
            type="button"
            onClick={() => setTab('kotlin')}
            className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
              tab === 'kotlin' ? 'bg-[#232834] text-white' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            PsxHleSurfaceController.kt
          </button>
          <button
            type="button"
            onClick={() => setTab('cpp')}
            className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
              tab === 'cpp' ? 'bg-[#232834] text-white' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            psx_hle_jni.cpp
          </button>
          <button
            type="button"
            onClick={() => setTab('cmake')}
            className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
              tab === 'cmake' ? 'bg-[#232834] text-white' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            CMakeLists.txt
          </button>
        </div>

        <div className="bg-[#0F1115] border border-[#262B36] rounded-lg overflow-hidden">
          <div className="flex items-center justify-between px-4 py-2.5 border-b border-[#262B36] text-xs text-slate-400">
            <span className="inline-flex items-center gap-2 font-mono">
              <Code2 className="w-3.5 h-3.5 text-blue-400" />
              {tab === 'activity'
                ? 'Android SDK · OpenDocument (Downloads) + SurfaceView'
                : tab === 'kotlin'
                  ? 'Android SDK · Kotlin SurfaceView + ParcelFileDescriptor'
                  : tab === 'cpp'
                    ? 'Android NDK · C++ JNI ANativeWindow + pread64'
                    : 'CMake · Biblioteca nativa libpsx_hle_native.so'}
            </span>
            <span>Zero WebView</span>
          </div>
          <pre className="p-4 text-xs font-mono text-slate-200 overflow-x-auto leading-relaxed">
            {activeSnippet}
          </pre>
        </div>
      </div>
    </div>
  );
};
