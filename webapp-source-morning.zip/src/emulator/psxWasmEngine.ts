import { installGlobalAudioTap } from './psxAudioTap';
import { IsoMountInfo, PSX_BTN, PsxPadState } from './types';

const EJS_DATA_PATH = 'https://cdn.emulatorjs.org/stable/data/';

export interface WasmSafetyCheckResult {
  blockedReason: string | null;
  requiresStreamingPrompt: boolean;
  hardBlockWasm: boolean;
  sizeMb: number;
  limitMb: number;
  hardLimitMb: number;
  isMobile: boolean;
}

export function checkBrowserWasmMemorySafety(info: IsoMountInfo): WasmSafetyCheckResult {
  const sizeMb = info.fileSizeBytes / (1024 * 1024);
  const isCompressedArchive =
    info.serial === 'ZIP-PACK' || info.serial === '7Z-PACK' || info.serial === 'RAR-PACK';

  const ua = typeof navigator !== 'undefined' ? navigator.userAgent : '';
  const isTouchDevice =
    typeof navigator !== 'undefined' &&
    typeof window !== 'undefined' &&
    navigator.maxTouchPoints > 1 &&
    Math.min(window.screen.width, window.screen.height) <= 1024;
  const isMobile = /Android|iPhone|iPad|iPod|Mobile/i.test(ua) || isTouchDevice;

  if (info.serial === 'ECM-PACK') {
    return {
      blockedReason:
        'Arquivo .ECM detectado. Descompacte primeiro para .BIN/.ISO antes de carregar no emulador.',
      requiresStreamingPrompt: false,
      hardBlockWasm: true,
      sizeMb,
      limitMb: 0,
      hardLimitMb: 0,
      isMobile,
    };
  }

  const archiveMaxMb = isMobile ? 16 : 64;
  if (isCompressedArchive && sizeMb > archiveMaxMb) {
    return {
      blockedReason: `Arquivo compactado (${sizeMb.toFixed(1)} MB) em ${info.serial} excede o limite de descompressão na memória do ${isMobile ? 'celular' : 'navegador'} (${archiveMaxMb} MB). Extraia para .BIN, .ISO ou .CHD antes de abrir para evitar queda da aba ("Aw, Snap!").`,
      requiresStreamingPrompt: false,
      hardBlockWasm: true,
      sizeMb,
      limitMb: archiveMaxMb,
      hardLimitMb: archiveMaxMb,
      isMobile,
    };
  }

  // Mobile Chrome renderer tabs inside iframes crash ("Aw, Snap!") when MEMFS duplicates > ~48 MB alongside WASM linear memory
  const limitMb = isMobile ? 28 : 350;
  const hardLimitMb = isMobile ? 48 : 580;

  return {
    blockedReason: null,
    requiresStreamingPrompt: sizeMb > limitMb,
    hardBlockWasm: sizeMb > hardLimitMb,
    sizeMb,
    limitMb,
    hardLimitMb,
    isMobile,
  };
}

interface EjsGameManager {
  FS: {
    readFile: (path: string) => Uint8Array;
    writeFile: (path: string, data: Uint8Array) => void;
    analyzePath: (path: string) => { exists: boolean };
  };
  Module: {
    abort?: () => void;
    pauseMainLoop?: () => void;
    AL?: {
      currentCtx?: {
        sources?: Array<{ gain?: { context?: AudioContext } }>;
      };
    };
  };
  functions: {
    restart: () => void;
    simulateInput: (player: number, index: number, value: number) => void;
    toggleMainLoop: (playing: number) => void;
    getSaveFilePath: () => string;
    saveSaveFiles: () => void;
    loadSaveFiles: () => void;
    getFrameNum: () => number;
    setKeyboardEnabled?: (enabled: number) => void;
  };
  toggleMainLoop: (playing: number) => void;
  restart: () => void;
  getState: () => Uint8Array;
  loadState: (state: Uint8Array) => void;
}

interface EjsInstance {
  started: boolean;
  paused: boolean;
  failedToStart?: boolean;
  canvas?: HTMLCanvasElement;
  elements?: {
    parent?: HTMLElement;
    menu?: HTMLElement;
    contextmenu?: HTMLElement;
  };
  menu?: {
    open: (force?: boolean) => void;
    close: () => void;
    toggle?: () => void;
    failedToStart?: () => void;
  };
  startGameError?: (message: string) => void;
  gameManager?: EjsGameManager;
  gamepadSelection?: string[];
  controls?: Record<string, unknown>;
  on: (event: string, cb: () => void) => void;
  setVolume: (vol: number) => void;
  toggleFullscreen: (force?: boolean) => void;
}

declare global {
  interface Window {
    EmulatorJS?: new (selector: string, config: Record<string, unknown>) => EjsInstance;
    EJS_GameManager?: {
      prototype: {
        getRetroArchCfg?: () => string;
        writeFile?: (path: string, data: string | Uint8Array) => void;
      };
    };
    EJS_emulator?: EjsInstance;
    __psxWebglPatched?: boolean;
    __psxWakeLockPatched?: boolean;
    __psxRetroArchLocked?: boolean;
    __psxGmTrapInstalled?: boolean;
  }
}

let ejsAssetsPromise: Promise<void> | null = null;
let allowCaptureForNextCanvas = false;

function patchWakeLockPermissionsPolicy(): void {
  if (typeof window === 'undefined' || window.__psxWakeLockPatched) return;
  window.__psxWakeLockPatched = true;

  const dummySentinel = {
    released: false,
    type: 'screen',
    release: async () => {},
    addEventListener: () => {},
    removeEventListener: () => {},
    dispatchEvent: () => false,
    onrelease: null,
  };

  try {
    const nav = navigator;
    if (nav.wakeLock && typeof nav.wakeLock.request === 'function') {
      const origRequest = nav.wakeLock.request.bind(nav.wakeLock);
      const safeRequest = async (type: WakeLockType = 'screen'): Promise<WakeLockSentinel> => {
        try {
          return await origRequest(type);
        } catch {
          return dummySentinel as unknown as WakeLockSentinel;
        }
      };
      try {
        nav.wakeLock.request = safeRequest;
      } catch {
        try {
          Object.defineProperty(nav, 'wakeLock', {
            configurable: true,
            value: { request: safeRequest },
          });
        } catch {
          // Handled by unhandledrejection fallback below
        }
      }
    }
  } catch {
    // Ignore restricted navigator environments
  }

  window.addEventListener('unhandledrejection', (ev) => {
    const msg =
      ev.reason instanceof Error
        ? ev.reason.message
        : typeof ev.reason === 'string'
          ? ev.reason
          : '';
    if (/WakeLock|wake-lock|Permissions policy/i.test(msg)) {
      ev.preventDefault();
    }
  });
}

const RETROARCH_LOCKOUT_CFG = [
  'menu_driver = "null"',
  'rgui_show_start_screen = "false"',
  'menu_enable_widgets = "false"',
  'menu_show_load_core = "false"',
  'menu_show_load_content = "false"',
  'menu_show_online_updater = "false"',
  'menu_show_quit_retroarch = "false"',
  'menu_show_restart_retroarch = "false"',
  'menu_show_configurations = "false"',
  'menu_show_information = "false"',
  'menu_pause_libretro = "false"',
  'video_font_enable = "false"',
  'video_message_pos_x = "-10"',
  'video_message_pos_y = "-10"',
  'stdin_cmd_enable = "false"',
  'config_save_on_exit = "false"',
  'input_menu_toggle = "nul"',
  'input_menu_toggle_btn = "nul"',
  'input_menu_toggle_axis = "nul"',
  'input_menu_toggle_gamepad_combo = "0"',
  'input_quit_gamepad_combo = "0"',
  'input_enable_hotkey = "nul"',
  'input_enable_hotkey_btn = "nul"',
  'input_exit_emulator = "nul"',
  'input_reset = "nul"',
  'input_pause_toggle = "nul"',
  'input_save_state = "nul"',
  'input_load_state = "nul"',
  'input_toggle_fast_forward = "nul"',
  'input_rewind = "nul"',
  'notification_show_autoconfig = "false"',
  'notification_show_cheats_applied = "false"',
  'notification_show_config_override_load = "false"',
  'notification_show_core_unsupported = "false"',
  'notification_show_netplay_extra = "false"',
  'notification_show_patch_applied = "false"',
  'notification_show_remap_load = "false"',
  'notification_show_screenshot = "false"',
  'notification_show_set_initial_disk = "false"',
  'notification_show_when_menu_is_alive = "false"',
  'suspend_screensaver_enable = "false"',
].join('\n');

function sanitizeRetroArchCfgText(cfg: string): string {
  const cleaned = cfg
    .replace(/^\s*menu_driver\s*=.*$/gim, '')
    .replace(/^\s*rgui_show_start_screen\s*=.*$/gim, '')
    .replace(/^\s*input_menu_toggle(_gamepad_combo)?\s*=.*$/gim, '');
  return `${cleaned}\n${RETROARCH_LOCKOUT_CFG}\n`;
}

function applyRetroArchProtoLock(gmClass: NonNullable<Window['EJS_GameManager']>): void {
  const proto = gmClass?.prototype;
  if (!proto || (proto as Record<string, unknown>).__psxPatched) return;
  (proto as Record<string, unknown>).__psxPatched = true;

  if (typeof proto.getRetroArchCfg === 'function') {
    const origGetCfg = proto.getRetroArchCfg;
    proto.getRetroArchCfg = function (...args: unknown[]) {
      const baseCfg = origGetCfg.apply(this, args as []);
      return sanitizeRetroArchCfgText(baseCfg);
    };
  }

  if (typeof proto.writeFile === 'function') {
    const origWriteFile = proto.writeFile;
    proto.writeFile = function (path: string, data: string | Uint8Array) {
      if (typeof path === 'string' && typeof data === 'string') {
        if (path.endsWith('retroarch.cfg')) {
          return origWriteFile.call(this, path, sanitizeRetroArchCfgText(data));
        }
        if (path.endsWith('retroarch-core-options.cfg') || path.endsWith('.opt')) {
          const corePatched =
            data
              .replace(/^\s*pcsx_rearmed_show_bios_bootlogo\s*=.*$/gim, '')
              .replace(/^\s*pcsx_rearmed_bios\s*=.*$/gim, '') +
            '\npcsx_rearmed_bios = "HLE"\npcsx_rearmed_show_bios_bootlogo = "disabled"\npcsx_rearmed_pad1type = "analog"\npcsx_rearmed_pad2type = "analog"\n';
          return origWriteFile.call(this, path, corePatched);
        }
      }
      return origWriteFile.call(this, path, data);
    };
  }

  window.__psxRetroArchLocked = true;
}

function patchRetroArchLockout(): void {
  if (typeof window === 'undefined') return;
  if (window.EJS_GameManager) {
    applyRetroArchProtoLock(window.EJS_GameManager);
    return;
  }
  if (window.__psxGmTrapInstalled) return;
  window.__psxGmTrapInstalled = true;

  let currentGm: Window['EJS_GameManager'] | undefined = window.EJS_GameManager;
  try {
    Object.defineProperty(window, 'EJS_GameManager', {
      configurable: true,
      enumerable: true,
      get() {
        return currentGm;
      },
      set(nextVal: Window['EJS_GameManager']) {
        currentGm = nextVal;
        if (nextVal) {
          applyRetroArchProtoLock(nextVal);
        }
      },
    });
  } catch {
    // Fallback if property cannot be redefined
  }
}

function neutralizeEmulatorUiSafely(inst?: EjsInstance | null): void {
  if (!inst) return;
  inst.gamepadSelection = ['', '', '', ''];
  inst.controls = {};
  if (inst.menu) {
    const origClose = typeof inst.menu.close === 'function' ? inst.menu.close.bind(inst.menu) : () => {};
    const origFailed =
      typeof inst.menu.failedToStart === 'function'
        ? inst.menu.failedToStart.bind(inst.menu)
        : () => {};
    inst.menu.open = () => {};
    inst.menu.toggle = () => {};
    inst.menu.close = origClose;
    inst.menu.failedToStart = origFailed;
  }
}

function patchCanvasForCapture(): void {
  if (window.__psxWebglPatched) return;
  window.__psxWebglPatched = true;

  const origGetContext = HTMLCanvasElement.prototype.getContext;
  // Only enable preserveDrawingBuffer when NetPlay P1 frame streaming is active to conserve mobile GPU RAM
  HTMLCanvasElement.prototype.getContext = function (
    this: HTMLCanvasElement,
    contextId: string,
    options?: unknown,
  ) {
    if (
      allowCaptureForNextCanvas &&
      (contextId === 'webgl2' || contextId === 'webgl' || contextId === 'experimental-webgl') &&
      this.classList.contains('ejs_canvas')
    ) {
      const merged = Object.assign({}, (options as Record<string, unknown>) || {}, {
        preserveDrawingBuffer: true,
      });
      return origGetContext.call(this, contextId as 'webgl2', merged as WebGLContextAttributes);
    }
    return origGetContext.call(this, contextId as '2d', options as CanvasRenderingContext2DSettings);
  } as typeof HTMLCanvasElement.prototype.getContext;
}

export function loadEjsRuntime(): Promise<void> {
  patchWakeLockPermissionsPolicy();
  patchRetroArchLockout();
  if (window.EmulatorJS) {
    return Promise.resolve();
  }
  if (ejsAssetsPromise) {
    return ejsAssetsPromise;
  }

  ejsAssetsPromise = new Promise<void>((resolve, reject) => {
    patchCanvasForCapture();
    installGlobalAudioTap();

    if (!document.querySelector('link[data-ejs-css="1"]')) {
      const link = document.createElement('link');
      link.rel = 'stylesheet';
      link.href = `${EJS_DATA_PATH}emulator.min.css`;
      link.setAttribute('data-ejs-css', '1');
      document.head.appendChild(link);
    }

    const script = document.createElement('script');
    script.src = `${EJS_DATA_PATH}emulator.min.js`;
    script.async = true;
    script.onload = () => {
      if (window.EmulatorJS) {
        patchRetroArchLockout();
        resolve();
      } else {
        ejsAssetsPromise = null;
        reject(new Error('Núcleo EmulatorJS PS1 não inicializou corretamente.'));
      }
    };
    script.onerror = () => {
      ejsAssetsPromise = null;
      reject(
        new Error(
          'Não foi possível baixar o núcleo PCSX-ReARMed WASM. Verifique sua conexão com a internet.',
        ),
      );
    };
    document.body.appendChild(script);
  });

  return ejsAssetsPromise;
}

const BIT_TO_EJS_INDEX: Array<[number, number]> = [
  [PSX_BTN.CROSS, 0],
  [PSX_BTN.SQUARE, 1],
  [PSX_BTN.SELECT, 2],
  [PSX_BTN.START, 3],
  [PSX_BTN.UP, 4],
  [PSX_BTN.DOWN, 5],
  [PSX_BTN.LEFT, 6],
  [PSX_BTN.RIGHT, 7],
  [PSX_BTN.CIRCLE, 8],
  [PSX_BTN.TRIANGLE, 9],
  [PSX_BTN.L1, 10],
  [PSX_BTN.R1, 11],
  [PSX_BTN.L2, 12],
  [PSX_BTN.R2, 13],
  [PSX_BTN.L3, 14],
  [PSX_BTN.R3, 15],
];

export class PsxWasmEngine {
  private instance: EjsInstance | null = null;
  private container: HTMLElement | null = null;
  private started = false;
  private lastPadMask: [number, number] = [0xffff, 0xffff];
  private lastAxes: [[number, number, number, number], [number, number, number, number]] = [
    [128, 128, 128, 128],
    [128, 128, 128, 128],
  ];
  private keyGuardHandler: ((e: KeyboardEvent) => void) | null = null;
  private contextGuardHandler: ((e: MouseEvent) => void) | null = null;
  private audioEnabled = true;

  async mountDisc(params: {
    container: HTMLElement;
    containerId: string;
    file: File;
    audioEnabled: boolean;
    enableFrameCapture?: boolean;
    onReady?: () => void;
    onGameStart?: () => void;
  }): Promise<void> {
    this.destroy();
    this.container = params.container;
    this.audioEnabled = params.audioEnabled;
    this.started = false;
    this.lastPadMask = [0xffff, 0xffff];
    this.lastAxes = [
      [128, 128, 128, 128],
      [128, 128, 128, 128],
    ];

    await loadEjsRuntime();
    patchRetroArchLockout();
    if (!window.EmulatorJS) {
      throw new Error('Runtime PCSX-ReARMed WASM indisponível.');
    }

    allowCaptureForNextCanvas = Boolean(params.enableFrameCapture);

    // Block RetroArch hotkeys (F1..F12, ScrollLock, Pause, Backquote) & context menu inside emulator surface
    this.keyGuardHandler = (e: KeyboardEvent) => {
      if (
        /^F([1-9]|1[0-2])$/.test(e.code) ||
        e.code === 'ScrollLock' ||
        e.code === 'Pause' ||
        e.code === 'Backquote'
      ) {
        e.preventDefault();
        e.stopImmediatePropagation();
      }
    };
    this.contextGuardHandler = (e: MouseEvent) => {
      e.preventDefault();
      e.stopPropagation();
    };
    window.addEventListener('keydown', this.keyGuardHandler, true);
    params.container.addEventListener('contextmenu', this.contextGuardHandler, true);

    // Ensure container has exact id selector and clean DOM
    params.container.id = params.containerId;
    params.container.innerHTML = '';

    // PCSX-ReARMed core lists ["bin","cue","img","mdf","pbp","toc","cbn","m3u","ccd"];
    // aliasing .iso -> .img (zero-copy Blob ref) prevents RetroArch from rejecting .iso and dropping into its internal menu.
    const mountFile = /\.iso$/i.test(params.file.name)
      ? new File([params.file], params.file.name.replace(/\.iso$/i, '.img'), {
          type: params.file.type || 'application/octet-stream',
        })
      : params.file;

    const config: Record<string, unknown> = {
      gameUrl: mountFile,
      gameName: params.file.name,
      dataPath: EJS_DATA_PATH,
      system: 'psx',
      // No external BIOS -> uses PCSX-ReARMed built-in HLE BIOS
      biosUrl: undefined,
      color: '#2563EB',
      backgroundColor: '#090B10',
      startOnLoad: true,
      disableCue: true,
      hideSettings: true,
      noAutoFocus: true,
      VirtualGamepad: false,
      cacheLimit: 0,
      disableDatabases: true,
      volume: params.audioEnabled ? 0.75 : 0,
      language: 'pt-BR',
      defaultControllers: { 0: {}, 1: {}, 2: {}, 3: {} },
      virtualGamepadSettings: [],
      buttonOpts: {
        playPause: false,
        restart: false,
        mute: false,
        settings: false,
        fullscreen: false,
        saveState: false,
        loadState: false,
        screenRecord: false,
        gamepad: false,
        cheat: false,
        volume: false,
        saveSavFiles: false,
        loadSavFiles: false,
        quickSave: false,
        quickLoad: false,
        screenshot: false,
        cacheManager: false,
        exitEmulation: false,
        rightClick: false,
      },
      defaultOptions: {
        shader: 'disabled',
        'psx-bios': 'hle',
        'pcsx_rearmed_bios': 'HLE',
        'pcsx_rearmed_show_bios_bootlogo': 'disabled',
        'pcsx_rearmed_pad1type': 'analog',
        'pcsx_rearmed_pad2type': 'analog',
        keyboardInput: 'disabled',
      },
    };

    const inst = new window.EmulatorJS(`#${params.containerId}`, config);
    this.instance = inst;
    window.EJS_emulator = inst;
    neutralizeEmulatorUiSafely(inst);

    await new Promise<void>((resolve, reject) => {
      let settled = false;
      let startWatcherId: number | null = null;
      let timeoutId: number | null = null;

      const cleanupWatchers = () => {
        if (startWatcherId !== null) {
          window.clearInterval(startWatcherId);
          startWatcherId = null;
        }
        if (timeoutId !== null) {
          window.clearTimeout(timeoutId);
          timeoutId = null;
        }
      };

      const finishSuccess = () => {
        if (settled) return;
        settled = true;
        cleanupWatchers();
        this.started = true;
        neutralizeEmulatorUiSafely(inst);
        inst.setVolume(this.audioEnabled ? 0.75 : 0);
        try {
          inst.gameManager?.functions.setKeyboardEnabled?.(0);
        } catch {
          // Ignore if unavailable
        }
        params.onGameStart?.();
        resolve();
      };

      const finishError = (msg: string) => {
        if (settled) return;
        settled = true;
        cleanupWatchers();
        this.destroy();
        reject(new Error(msg));
      };

      const origStartGameError =
        typeof inst.startGameError === 'function' ? inst.startGameError.bind(inst) : null;
      inst.startGameError = (message: string) => {
        if (origStartGameError) {
          try {
            origStartGameError(message);
          } catch {
            // Ignore internal UI errors when failing early
          }
        }
        finishError(
          `Não foi possível iniciar "${params.file.name}" no núcleo PS1 (${message || 'erro de inicialização'}).`,
        );
      };

      inst.on('ready', () => {
        neutralizeEmulatorUiSafely(inst);
        params.onReady?.();
      });

      inst.on('start', () => {
        finishSuccess();
      });

      inst.on('exit', () => {
        if (!this.started && !settled) {
          finishError(
            'Não foi possível iniciar esta imagem diretamente no núcleo PS1. Tente formato .BIN/.CUE, .IMG, .CHD ou Modo Streaming.',
          );
        }
      });

      // Poll inst.started / failedToStart in case synchronous or custom build missed event hook
      startWatcherId = window.setInterval(() => {
        if (settled) return;
        if (inst.started) {
          finishSuccess();
          return;
        }
        const errElem = params.container.querySelector('.ejs_error_text');
        if (inst.failedToStart || (errElem && errElem.textContent?.trim())) {
          const txt = errElem?.textContent?.trim() || 'erro de vídeo/imagem';
          finishError(`Falha ao iniciar o disco PS1 (${txt}).`);
        }
      }, 200);

      timeoutId = window.setTimeout(() => {
        if (!settled) {
          if (inst.started) {
            finishSuccess();
          } else {
            finishError(
              'Tempo esgotado ao inicializar a ISO no navegador. Use o Modo Seguro Streaming ou um arquivo .BIN/.IMG/.CHD menor.',
            );
          }
        }
      }, 35000);
    });
  }

  resumeAudio(): void {
    try {
      const sources = this.instance?.gameManager?.Module?.AL?.currentCtx?.sources;
      sources?.forEach((src) => {
        const ctx = src.gain?.context;
        if (ctx && ctx.state === 'suspended') {
          void ctx.resume();
        }
      });
    } catch {
      // Ignore
    }
  }

  isRunning(): boolean {
    return Boolean(this.instance && this.started);
  }

  getFrameCount(): number {
    try {
      return this.instance?.gameManager?.functions.getFrameNum() ?? 0;
    } catch {
      return 0;
    }
  }

  private pushAxisPair(
    gm: EjsGameManager,
    port: 0 | 1,
    posIdx: number,
    negIdx: number,
    byteVal: number,
  ): void {
    // Convert 0..255 (128 center) -> -1..+1 -> 0..0x7fff
    const norm = (byteVal - 128) / 127;
    const pos = norm > 0.05 ? Math.min(0x7fff, Math.round(norm * 0x7fff)) : 0;
    const neg = norm < -0.05 ? Math.min(0x7fff, Math.round(-norm * 0x7fff)) : 0;
    try {
      gm.functions.simulateInput(port, posIdx, pos);
      gm.functions.simulateInput(port, negIdx, neg);
    } catch {
      // Ignore transient axis errors
    }
  }

  applyPadState(port: 0 | 1, state: PsxPadState): void {
    const gm = this.instance?.gameManager;
    if (!gm || !this.started) return;

    const prev = this.lastPadMask[port];
    const next = state.buttons & 0xffff;
    if (prev !== next) {
      this.lastPadMask[port] = next;
      for (const [bit, idx] of BIT_TO_EJS_INDEX) {
        const wasPressed = (prev & bit) === 0;
        const isPressed = (next & bit) === 0;
        if (wasPressed !== isPressed) {
          try {
            gm.functions.simulateInput(port, idx, isPressed ? 1 : 0);
          } catch {
            // Ignore transient input errors during core reset
          }
        }
      }
    }

    const [plx, ply, prx, pry] = this.lastAxes[port];
    if (plx !== state.lx) {
      this.lastAxes[port][0] = state.lx;
      this.pushAxisPair(gm, port, 16, 17, state.lx);
    }
    if (ply !== state.ly) {
      this.lastAxes[port][1] = state.ly;
      this.pushAxisPair(gm, port, 18, 19, state.ly);
    }
    if (prx !== state.rx) {
      this.lastAxes[port][2] = state.rx;
      this.pushAxisPair(gm, port, 20, 21, state.rx);
    }
    if (pry !== state.ry) {
      this.lastAxes[port][3] = state.ry;
      this.pushAxisPair(gm, port, 22, 23, state.ry);
    }
  }

  setPaused(paused: boolean): void {
    const gm = this.instance?.gameManager;
    if (!gm || !this.started) return;
    try {
      gm.toggleMainLoop(paused ? 0 : 1);
      const sources = gm.Module?.AL?.currentCtx?.sources;
      sources?.forEach((src) => {
        const ctx = src.gain?.context;
        if (ctx) {
          if (paused && ctx.state === 'running') void ctx.suspend();
          if (!paused && ctx.state === 'suspended') void ctx.resume();
        }
      });
    } catch {
      // Ignore audio/loop state errors
    }
  }

  setMuted(muted: boolean): void {
    this.audioEnabled = !muted;
    try {
      this.instance?.setVolume(muted ? 0 : 0.75);
    } catch {
      // Ignore volume errors
    }
  }

  restart(): void {
    try {
      this.instance?.gameManager?.restart();
    } catch {
      // Ignore restart errors
    }
  }

  getCanvasElement(): HTMLCanvasElement | null {
    const canvas =
      this.instance?.canvas ??
      (this.container?.querySelector('canvas.ejs_canvas') as HTMLCanvasElement | null);
    if (!canvas || canvas.width === 0 || canvas.height === 0) return null;
    return canvas;
  }

  captureFrameDataUrl(offscreen: HTMLCanvasElement): string | null {
    const canvas = this.getCanvasElement();
    if (!canvas) return null;
    const ctx = offscreen.getContext('2d');
    if (!ctx) return null;
    try {
      ctx.imageSmoothingEnabled = false;
      ctx.drawImage(canvas, 0, 0, offscreen.width, offscreen.height);
      return offscreen.toDataURL('image/jpeg', 0.62);
    } catch {
      return null;
    }
  }

  exportMemoryCardSram(): string | null {
    const gm = this.instance?.gameManager;
    if (!gm || !this.started) return null;
    try {
      gm.functions.saveSaveFiles();
      const savePath = gm.functions.getSaveFilePath();
      if (!savePath || !gm.FS.analyzePath(savePath).exists) {
        return null;
      }
      const bytes = gm.FS.readFile(savePath);
      if (bytes.length === 0 || bytes.length > 650_000) return null;
      let bin = '';
      for (let i = 0; i < bytes.length; i++) {
        bin += String.fromCharCode(bytes[i]);
      }
      return btoa(bin);
    } catch {
      return null;
    }
  }

  importMemoryCardSram(encoded: string): boolean {
    const gm = this.instance?.gameManager;
    if (!gm || !this.started) return false;
    try {
      const bin = atob(encoded);
      const bytes = new Uint8Array(bin.length);
      for (let i = 0; i < bin.length; i++) {
        bytes[i] = bin.charCodeAt(i);
      }
      const savePath = gm.functions.getSaveFilePath();
      if (!savePath) return false;
      gm.FS.writeFile(savePath, bytes);
      gm.functions.loadSaveFiles();
      return true;
    } catch {
      return false;
    }
  }

  destroy(): void {
    const inst = this.instance;
    this.started = false;
    this.instance = null;
    if (this.keyGuardHandler) {
      window.removeEventListener('keydown', this.keyGuardHandler, true);
      this.keyGuardHandler = null;
    }
    if (this.contextGuardHandler && this.container) {
      this.container.removeEventListener('contextmenu', this.contextGuardHandler, true);
    }
    this.contextGuardHandler = null;
    if (inst) {
      try {
        inst.gameManager?.toggleMainLoop(0);
      } catch {
        // Ignore
      }
      try {
        const sources = inst.gameManager?.Module?.AL?.currentCtx?.sources;
        sources?.forEach((src) => {
          void src.gain?.context?.close?.();
        });
      } catch {
        // Ignore
      }
      try {
        inst.gameManager?.Module?.abort?.();
      } catch {
        // Ignore
      }
      try {
        inst.elements?.parent?.remove();
      } catch {
        // Ignore
      }
    }
    if (this.container) {
      this.container.innerHTML = '';
      this.container = null;
    }
    if (window.EJS_emulator === inst) {
      window.EJS_emulator = undefined;
    }
  }
}
